//#include <windows.h>
//#include <winuser.h>
#include "StdAfx.h"
//#include "../winheaders.h"
#include "Display.h"

//#include "../global/LogFile.h"
//#include "../global/DebugInfo.h"

#define	LT_ENGLISH		0
#define LT_CHINESE		1

#define CPU_MMX			1
#define CPU_SSE2		2
#pragma comment(lib,"dxguid.lib")
#pragma warning(disable:4244)
extern char m_mmxcap;	//mmx capability
extern short c128[8];

#ifndef SM_CMONITORS
#define SM_CMONITORS            80
#endif

void GetMmxCap();

#define INIT_DIRECTDRAW_STRUCT(x) (ZeroMemory(&x, sizeof(x)), x.dwSize=sizeof(x))
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

//yfli add:2006/09/22
extern BYTE				*pAscFrontSource;//ASC�ֿ�
extern BYTE				*pHZKFrontSource;//�����ֿ�

#define IMAGE_NULL_FLAG      55553


// ��ʼ������������InitDDraw()ʱֻ��ʼ��һ��
void InitRGB16Dither();

char g_InitRGB16Dither = FALSE;

// RGB24������
static long int crv_tab[256];
static long int cbu_tab[256];
static long int cgu_tab[256];
static long int cgv_tab[256];
static long int tab_76309[256];
static UCHAR orig_clp[1024];
static UCHAR* clp;

short red_cr[] = {179, 179, 179, 179, 179, 179, 179, 179};
short green_cr[] = {-91, -91, -91, -91, -91, -91, -91, -91};
short green_cb[] = {-44, -44, -44, -44, -44, -44, -44, -44};
short blue_cb[] = {227, 227 ,227, 227, 227, 227 ,227, 227};

int L_tab[1024], Cr_r_tab[1024], Cr_g_tab[1024], Cb_g_tab[1024], Cb_b_tab[1024];
long r_2_pix_alloc[3072];
long g_2_pix_alloc[3072];
long b_2_pix_alloc[3072];

long *r_2_pix;
long *g_2_pix;
long *b_2_pix;

int number_of_bits_set (unsigned long a)
{
	if (!a)
		return 0;
	if (a & 1)
		return 1 + number_of_bits_set (a >> 1);
	return (number_of_bits_set (a >> 1));
}

/* Shift the 0s in the least significant end out of the longword. Low
 * performance, do not call often. */
unsigned long shifted_down (unsigned long a)
{
	if (!a)
		return 0;
	if (a & 1)
		return a;
	return a >> 1;
}

/* How many 0 bits are there at most significant end of longword. Low
 * performance, do not call often. */
int free_bits_at_top (unsigned long a)
{
	/* assume char is 8 bits */
	if (!a)
		return sizeof (unsigned long) * 8;
	/* assume twos complement */
	if (((long) a) < 0l)
		return 0;
	return 1 + free_bits_at_top (a << 1);
}

/* How many 0 bits are there at least significant end of longword. Low
 * performance, do not call often. */
int free_bits_at_bottom (unsigned long a)
{
	/* assume char is 8 bits */
	if (!a)
		return sizeof (unsigned long) * 8;
	if (((long) a) & 1l)
		return 0;
	return 1 + free_bits_at_bottom (a >> 1);
}

void InitRGB16Dither()
{
	static BOOL init_color16 = 0;
	if(init_color16)
		return;

	init_color16 = 1;
	unsigned long red_mask = 0xf800;//0xff0000;
	unsigned long green_mask = 0x07e0;//0xff00;
	unsigned long blue_mask = 0x001f;//0xff;

	int CR, CB, i;

	for (i = 0; i < 256; i++)
	{
		L_tab[i] = i;
		CB = CR = i;

		{
		  CB -= 128;
		  CR -= 128;
		}
		/* was Cr_r_tab[i] =  1.596 * CR; Cr_g_tab[i] = -0.813 * CR;
		 * Cb_g_tab[i] = -0.391 * CB;   Cb_b_tab[i] =  2.018 * CB; but they
		 * were just messed up. Then was (_Video Deymstified_): Cr_r_tab[i] =
		 * 1.366 * CR; Cr_g_tab[i] = -0.700 * CR; Cb_g_tab[i] = -0.334 * CB;
		 * Cb_b_tab[i] =  1.732 * CB; but really should be: (from ITU-R
		 * BT.470-2 System B, G and SMPTE 170M ) */
		Cr_r_tab[i] = (0.419 / 0.299) * CR;
		Cr_g_tab[i] = -(0.299 / 0.419) * CR;
		Cb_g_tab[i] = -(0.114 / 0.331) * CB;
		Cb_b_tab[i] = (0.587 / 0.331) * CB;

		/* though you could argue for: SMPTE 240M Cr_r_tab[i] =  (0.445/0.212) *
		* CR; Cr_g_tab[i] = -(0.212/0.445) * CR; Cb_g_tab[i] = -(0.087/0.384) *
		* CB; Cb_b_tab[i] =  (0.701/0.384) * CB; FCC Cr_r_tab[i] =
		* (0.421/0.30) * CR; Cr_g_tab[i] = -(0.30/0.421) * CR; Cb_g_tab[i] =
		* -(0.11/0.331) * CB; Cb_b_tab[i] =  (0.59/0.331) * CB; ITU-R BT.709
		* Cr_r_tab[i] =  (0.454/0.2125) * CR; Cr_g_tab[i] = -(0.2125/0.454) *
		* CR; Cb_g_tab[i] = -(0.0721/0.386) * CB; Cb_b_tab[i] =
		* (0.7154/0.386) * CB; */
	}

	int a = number_of_bits_set (red_mask);
	int b = free_bits_at_bottom (red_mask);
	int c = number_of_bits_set (green_mask);
	int d = free_bits_at_bottom (green_mask);
	int e = number_of_bits_set (blue_mask);
	int f = free_bits_at_bottom (blue_mask);
	/* Set up entries 0-255 in rgb-to-pixel value tables. */

	for (i = 0; i < 256; i++)
	{
		r_2_pix_alloc[i + 256] = i >> (8 - number_of_bits_set (red_mask));
		r_2_pix_alloc[i + 256] <<= free_bits_at_bottom (red_mask);
		g_2_pix_alloc[i + 256] = i >> (8 - number_of_bits_set (green_mask));
		g_2_pix_alloc[i + 256] <<= free_bits_at_bottom (green_mask);
		b_2_pix_alloc[i + 256] = i >> (8 - number_of_bits_set (blue_mask));
		b_2_pix_alloc[i + 256] <<= free_bits_at_bottom (blue_mask);
	}

	/* Spread out the values we have to the rest of the array so that we do
	* not need to check for overflow. */
	for (i = 0; i < 256; i++)
	{
		r_2_pix_alloc[i] = r_2_pix_alloc[256];
		r_2_pix_alloc[i + 512] = r_2_pix_alloc[511];
		g_2_pix_alloc[i] = g_2_pix_alloc[256];
		g_2_pix_alloc[i + 512] = g_2_pix_alloc[511];
		b_2_pix_alloc[i] = b_2_pix_alloc[256];
		b_2_pix_alloc[i + 512] = b_2_pix_alloc[511];
	}

	r_2_pix = r_2_pix_alloc + 256;
	g_2_pix = g_2_pix_alloc + 256;
	b_2_pix = b_2_pix_alloc + 256;

	// ��ʼ��RGB24������
	long int crv, cbu, cgu, cgv;
	crv = 104597;
	cbu = 132201;                 /* fra matrise i global.h */
	cgu = 25675;
	cgv = 53279;
	
	for (i = 0; i < 256; i++)
	{
		crv_tab[i] = (i - 128) * crv;
		cbu_tab[i] = (i - 128) * cbu;
		cgu_tab[i] = (i - 128) * cgu;
		cgv_tab[i] = (i - 128) * cgv;
		tab_76309[i] = 76309 * (i - 16);
	}
	
	clp = orig_clp + 384;
	for (i = -384; i < 640; i++)
		clp[i] = (i < 0) ? 0 : ((i > 255) ? 255 : i);
	
}

///////////////////////////////////////////////////////////////////////////////////////////
static void __declspec(naked) asm_blend_row_clippedO(BYTE *dst, BYTE *src, int w, int srcpitch) {
	__asm {
		push	ebp
			push	edi
			push	esi
			push	ebx
			
			mov		edi,[esp+20]
			mov		esi,[esp+24]
			sub		edi,esi
			mov		ebp,[esp+28]
			mov		edx,[esp+32]
			
xloop:
			mov		cx,[esi]
			mov		ax,0fefeh
//			mov		ax,0EEEEh
			
			mov		bx,[esi+edx]
			and		ax,cx
			
			shr		ax,1
			and		bx,0fefeh
			
			shr		bx,1
			add		esi,2
			
			add		ax,bx
			dec		ebp
			
			mov		[edi+esi-2],ax
			jnz		xloop
			
			pop		ebx
			pop		esi
			pop		edi
			pop		ebp
			ret
	};
}

static void __declspec(naked) asm_blend_rowO(BYTE *dst, BYTE *src, int w, int srcpitch) {
	__asm {
		push	ebp
			push	edi
			push	esi
			push	ebx
			
			mov		edi,[esp+20]
			mov		esi,[esp+24]
			sub		edi,esi
			mov		ebp,[esp+28]
			mov		edx,[esp+32]
			
xloop:
			mov		cx,[esi]
			mov		ax,0FCFCh
			
			mov		bx,[esi+edx]
			and		ax,cx
			
			and		bx,0FEFEh
			mov		cx,[esi+edx*2]
			
			shr		bx,1
			and		cx,0FCFCh
			
			shr		ax,2
			shr		cx,2
			
			add		ax,bx
			add		esi,2
			
			add		ax,cx
			dec		ebp
			
			mov		[edi+esi-2],ax
			jnz		xloop
			
			pop		ebx
			pop		esi
			pop		edi
			pop		ebp
			ret
	};
}

//ZJX/20101018/˫��֧��
static void YUY2_to_RGB16(unsigned char *yuvBuf, unsigned short *pRgbBuf, int nWidth, int nHeight)
{
	// ���Ǵ����ʽ��yuv4:2:2-->rgb24����
	short R, G, B, y, u, v;
	long r = 0, p = 0;// row
	
	long rdif, invgdif, bdif;
	
	// ��ͼ����������
	for (r = 0; r < nHeight; r++)// bpboy 2008-4-15 (575*720+0)*2
	{
		for (p=0; p<nWidth; p+=2)
		{
			// ��ʱyuvԴ��Ҫָ��(r*nWidth+p)*2
			long pYUVIndex = (r*nWidth+p)*2;
			
			y = yuvBuf[pYUVIndex];
			u = yuvBuf[pYUVIndex+1] - 128;
			v = yuvBuf[pYUVIndex+3] - 128;
			
			rdif = v + ((v * 103) >> 8);
			invgdif = ((u * 88) >> 8) +((v * 183) >> 8);
			bdif = u +( (u*198) >> 8);
			
			R = y + rdif;
			G = y - invgdif;
			B = y + bdif;
			
			R = max (0, min (255, R));
			G = max (0, min (255, G));
			B = max (0, min (255, B));
			
			// ����ʱ�� rgbԴ��Ҫָ�� (nHeight-1-r+p)*3
			long pRGBIndex = ((nHeight-r-1)*nWidth+p)*3;
			
			// ע��:rgb24������˳���������� b g r
			//			pRgbBuf[pRGBIndex+0]=B;
			//			pRgbBuf[pRGBIndex+1]=G;
			//			pRgbBuf[pRGBIndex+2]=R;
			*pRgbBuf++ = (((WORD)R>>3)<<11) | (((WORD)G>>2)<<5) | (((WORD)B>>3)<<0);
			
			y = yuvBuf[pYUVIndex+2];
			
			R = y + rdif;
			G = y - invgdif;
			B = y + bdif;
			
			R = max (0, min (255, R));
			G = max (0, min (255, G));
			B = max (0, min (255, B));
			
			//			pRgbBuf[pRGBIndex+3]=B;//˳����������bgr
			//			pRgbBuf[pRGBIndex+4]=G;
			//			pRgbBuf[pRGBIndex+5]=R;
			*pRgbBuf++ = (((WORD)R>>3)<<11) | (((WORD)G>>2)<<5) | (((WORD)B>>3)<<0);
		}		
	}
}

void CDDrawDisplay::YV12RGB16Ex(UCHAR *lum, UCHAR *cr, UCHAR *cb, UCHAR *rgb, int width, int height)
{
	YUY2_to_RGB16(lum, (unsigned short *)rgb, width, height);
}

void CDDrawDisplay::YV12RGB16(UCHAR *lum, UCHAR *cr, UCHAR *cb, UCHAR *rgb, int width, int height)
{
	int y=0;

	if(m_mmxcap == CPU_SSE2 && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	{
		__asm
		{
		mov esi, [lum];
		mov edi, [rgb];
		mov eax, [cr];
		mov ebx, [cb];
		mov edx, width;

yuv2rgb_col:
		xor ecx, ecx;

yuv2rgb_row:
		movups xmm0, [eax];
		movups xmm2, [ebx];
		pxor xmm4, xmm4;
		punpcklbw xmm0, xmm4;		// 0: cr 4 word
		punpcklbw xmm2, xmm4;		// 2: cb 4 word

		movups xmm3, [c128];
		psubw xmm0, xmm3;			// cr - 128
		psubw xmm2, xmm3;			// cb - 128

		movaps xmm1, xmm0;
		movups xmm3, [red_cr];
		pmullw xmm0, xmm3;
		psraw xmm0, 7;			// 0: Cr_r_tab[CR]

		movups xmm3, [green_cr];
		pmullw xmm1, xmm3;
		movups xmm5, xmm2;
		movups xmm3, [green_cb];
		pmullw xmm5, xmm3;
		paddw xmm1, xmm5;
		psraw xmm1, 7;			// 1: Cr_g_tab[CR] + Cb_g_tab[CB]

		movups xmm3, [blue_cb];
		pmullw xmm2, xmm3;
		psraw xmm2, 7;			// 2: Cb_b_tab[CB]

	/////////////////////// first
		movups xmm3, [esi];		// lum
		punpcklbw xmm3, xmm4;

		// arange data
		movups xmm5, xmm0;
		punpcklwd xmm5, xmm5;
		punpckldq xmm5, xmm5;
		paddw xmm5, xmm3;			// 0: R = L + cr_r

		movups xmm6, xmm1;
		punpcklwd xmm6, xmm6;
		punpckldq xmm6, xmm6;
		paddw xmm6, xmm3;			// 1: G = L + cr_g + cb_g;

		movups xmm7, xmm2;
		punpcklwd xmm7, xmm7;
		punpckldq xmm7, xmm7;
		paddw xmm7, xmm3;			// 2: B = L + cb_b

		// compute Red
		packuswb xmm5, xmm5;
		punpcklbw xmm5, xmm4;

		psrlw xmm5, 3;
		psllw xmm5, 11;

		// compute Green
		packuswb xmm6, xmm6;
		punpcklbw xmm6, xmm4;

		psrlw xmm6, 2;
		psllw xmm6, 5;

		// compute Blue
		packuswb xmm7, xmm7;
		punpcklbw xmm7, xmm4;

		psrlw xmm7, 3;

		por xmm5, xmm6;
		por xmm5, xmm7;
		movups [edi], xmm5;

	/////////////////////////// second
		movups xmm3, [esi+8];		// lum
		punpcklbw xmm3, xmm4;

		// arange data
		movups xmm5, xmm0;
		punpcklwd xmm5, xmm5;
		punpckhdq xmm5, xmm5;
		paddw xmm5, xmm3;			// 0: R = L + cr_r

		movups xmm6, xmm1;
		punpcklwd xmm6, xmm6;
		punpckhdq xmm6, xmm6;
		paddw xmm6, xmm3;			// 1: G = L + cr_g + cb_g;

		movups xmm7, xmm2;
		punpcklwd xmm7, xmm7;
		punpckhdq xmm7, xmm7;
		paddw xmm7, xmm3;			// 2: B = L + cb_b

		// compute Red
		packuswb xmm5, xmm5;
		punpcklbw xmm5, xmm4;

		psrlw xmm5, 3;
		psllw xmm5, 11;

		// compute Green
		packuswb xmm6, xmm6;
		punpcklbw xmm6, xmm4;

		psrlw xmm6, 2;
		psllw xmm6, 5;

		// compute Blue
		packuswb xmm7, xmm7;
		punpcklbw xmm7, xmm4;

		psrlw xmm7, 3;

		por xmm5, xmm6;
		por xmm5, xmm7;
		movups [edi+16], xmm5;

	////////////////////////// third
		movups xmm3, [esi+edx];		// lum
		punpcklbw xmm3, xmm4;

		// arange data
		movups xmm5, xmm0;
		punpckhwd xmm5, xmm5;
		punpckldq xmm5, xmm5;
		paddw xmm5, xmm3;			// 0: R = L + cr_r

		movups xmm6, xmm1;
		punpckhwd xmm6, xmm6;
		punpckldq xmm6, xmm6;
		paddw xmm6, xmm3;			// 1: G = L + cr_g + cb_g;

		movups xmm7, xmm2;
		punpckhwd xmm7, xmm7;
		punpckldq xmm7, xmm7;
		paddw xmm7, xmm3;			// 2: B = L + cb_b

		// compute Red
		packuswb xmm5, xmm5;
		punpcklbw xmm5, xmm4;

		psrlw xmm5, 3;
		psllw xmm5, 11;

		// compute Green
		packuswb xmm6, xmm6;
		punpcklbw xmm6, xmm4;

		psrlw xmm6, 2;
		psllw xmm6, 5;

		// compute Blue
		packuswb xmm7, xmm7;
		punpcklbw xmm7, xmm4;

		psrlw xmm7, 3;

		por xmm5, xmm6;
		por xmm5, xmm7;
		add edi, edx;
		movups [edi+edx], xmm5;

	//////////////////////////// fourth
		movups xmm3, [esi+edx+8];		// lum
		punpcklbw xmm3, xmm4;

		// arange data
		punpckhwd xmm0, xmm0;
		punpckhdq xmm0, xmm0;
		paddw xmm0, xmm3;			// 0: R = L + cr_r

		punpckhwd xmm1, xmm1;
		punpckhdq xmm1, xmm1;
		paddw xmm1, xmm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd xmm2, xmm2;
		punpckhdq xmm2, xmm2;
		paddw xmm2, xmm3;			// 2: B = L + cb_b

		// compute Red
		packuswb xmm0, xmm0;
		punpcklbw xmm0, xmm4;

		psrlw xmm0, 3;
		psllw xmm0, 11;

		// compute Green
		packuswb xmm1, xmm1;
		punpcklbw xmm1, xmm4;

		psrlw xmm1, 2;
		psllw xmm1, 5;

		// compute Blue
		packuswb xmm2, xmm2;
		punpcklbw xmm2, xmm4;

		psrlw xmm2, 3;

		por xmm0, xmm1;
		por xmm0, xmm2;
		movups [edi+edx+16], xmm0;
		sub edi, edx;

		add eax, 8;
		add ebx, 8;
		add esi, 16;
		add edi, 32;

		add ecx, 16;
		cmp ecx, edx;
		jne yuv2rgb_row;

		add esi, edx;
		add edi, edx;
		add edi, edx;

		mov ecx, y;
		add ecx, 2;
		mov y, ecx;
		cmp ecx, height;
		jne yuv2rgb_col;
		}
	}
	else if(m_mmxcap == CPU_MMX && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	{
		__asm
		{
		mov esi, [lum];
		mov edi, [rgb];
		mov eax, [cr];
		mov ebx, [cb];
		mov edx, width;


yuv2rgb_mmx_col:
		xor ecx, ecx;

yuv2rgb_mmx_row:
		movd mm0, [eax];
		movd mm2, [ebx];
		pxor mm3, mm3;
		punpcklbw mm0, mm3;		// 0: cr 4 word
		punpcklbw mm2, mm3;		// 2: cb 4 word

		movq mm4, [c128];
		psubw mm0, mm4;
		psubw mm2, mm4;

		movq mm1, mm0;
		pmullw mm0, [red_cr];
		psraw mm0, 7;			// 0: Cr_r_tab[CR]
//		movq [data], mm0;

		pmullw mm1, [green_cr];
		movq mm5, mm2;
		pmullw mm5, [green_cb];
		paddw mm1, mm5;
		psraw mm1, 7;			// 1: Cr_g_tab[CR] + Cb_g_tab[CB]
//		movq [data+8], mm1;

		pmullw mm2, [blue_cb];
		psraw mm2, 7;			// 2: Cb_b_tab[CB]
//		movq [data+16], mm2;


	/////////////////////// first
		movd mm3, [esi];		// lum
		pxor mm4, mm4;
		punpcklbw mm3, mm4;

		// arange data
		movq mm5, mm0;
		punpcklwd mm5, mm5;
		punpckldq mm5, mm5;
		paddw mm5, mm3;			// 0: R = L + cr_r

		movq mm6, mm1;
		punpcklwd mm6, mm6;
		punpckldq mm6, mm6;
		paddw mm6, mm3;			// 1: G = L + cr_g + cb_g;

		movq mm7, mm2;
		punpcklwd mm7, mm7;
		punpckldq mm7, mm7;
		paddw mm7, mm3;			// 2: B = L + cb_b

		// compute Red
		packuswb mm5, mm5;
		punpcklbw mm5, mm4;

		psrlw mm5, 3;
		psllw mm5, 11;

		// compute Green
		packuswb mm6, mm6;
		punpcklbw mm6, mm4;

		psrlw mm6, 2;
		psllw mm6, 5;

		// compute Blue
		packuswb mm7, mm7;
		punpcklbw mm7, mm4;

		psrlw mm7, 3;

		por mm5, mm6;
		por mm5, mm7;
		movq [edi], mm5;

	/////////////////////////// second
		movd mm3, [esi+4];		// lum
		punpcklbw mm3, mm4;

		// arange data
		movq mm5, mm0;
		punpcklwd mm5, mm5;
		punpckhdq mm5, mm5;
		paddw mm5, mm3;			// 0: R = L + cr_r

		movq mm6, mm1;
		punpcklwd mm6, mm6;
		punpckhdq mm6, mm6;
		paddw mm6, mm3;			// 1: G = L + cr_g + cb_g;

		movq mm7, mm2;
		punpcklwd mm7, mm7;
		punpckhdq mm7, mm7;
		paddw mm7, mm3;			// 2: B = L + cb_b

		// compute Red
		packuswb mm5, mm5;
		punpcklbw mm5, mm4;

		psrlw mm5, 3;
		psllw mm5, 11;

		// compute Green
		packuswb mm6, mm6;
		punpcklbw mm6, mm4;

		psrlw mm6, 2;
		psllw mm6, 5;

		// compute Blue
		packuswb mm7, mm7;
		punpcklbw mm7, mm4;

		psrlw mm7, 3;

		por mm5, mm6;
		por mm5, mm7;
		movq [edi+8], mm5;

	////////////////////////// third
		movd mm3, [esi+edx];		// lum
		punpcklbw mm3, mm4;

		// arange data
		movq mm5, mm0;
		punpckhwd mm5, mm5;
		punpckldq mm5, mm5;
		paddw mm5, mm3;			// 0: R = L + cr_r

		movq mm6, mm1;
		punpckhwd mm6, mm6;
		punpckldq mm6, mm6;
		paddw mm6, mm3;			// 1: G = L + cr_g + cb_g;

		movq mm7, mm1;
		punpckhwd mm7, mm7;
		punpckldq mm7, mm7;
		paddw mm7, mm3;			// 2: B = L + cb_b

		// compute Red
		// Round to 0-255
		packuswb mm5, mm5;
		punpcklbw mm5, mm4;

		psrlw mm5, 3;
		psllw mm5, 11;

		// compute Green
		packuswb mm6, mm6;
		punpcklbw mm6, mm4;

		psrlw mm6, 2;
		psllw mm6, 5;

		// compute Blue
		packuswb mm7, mm7;
		punpcklbw mm7, mm4;

		psrlw mm7, 3;

		por mm5, mm6;
		por mm5, mm7;
		add edi, edx;
		movq [edi+edx], mm5;

	//////////////////////////// fourth
		movd mm3, [esi+edx+4];		// lum
		punpcklbw mm3, mm4;

		// arange data
		punpckhwd mm0, mm0;
		punpckhdq mm0, mm0;
		paddw mm0, mm3;			// 0: R = L + cr_r

		punpckhwd mm1, mm1;
		punpckhdq mm1, mm1;
		paddw mm1, mm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd mm2, mm2;
		punpckhdq mm2, mm2;
		paddw mm2, mm3;			// 2: B = L + cb_b

		// compute Red
		packuswb mm0, mm0;
		punpcklbw mm0, mm4;

		psrlw mm0, 3;
		psllw mm0, 11;

		// compute Green
		packuswb mm1, mm1;
		punpcklbw mm1, mm4;

		psrlw mm1, 2;
		psllw mm1, 5;

		// compute Blue
		packuswb mm2, mm2;
		punpcklbw mm2, mm4;

		psrlw mm2, 3;

		por mm0, mm1;
		por mm0, mm2;
		movq [edi+edx+8], mm0;
		sub edi, edx;

		add eax, 4;
		add ebx, 4;
		add esi, 8;
		add edi, 16;

		add ecx, 8;
		cmp ecx, edx;
		jne yuv2rgb_mmx_row;

		add esi, edx;
		add edi, edx;
		add edi, edx;

		mov ecx, y;
		add ecx, 2;
		mov y, ecx;
		cmp ecx, height;
		jne yuv2rgb_mmx_col;

		emms;
		}
	}
	else
	{
		int L, CR, CB;
		unsigned short *row1, *row2;
		UCHAR *lum2;
		int x, y;
		int cr_r;
		int cr_g;
		int cb_g;
		int cb_b;
		int cols_2;

		cols_2 = width >> 1;
		row1 = (unsigned short *)rgb;
		row2 = row1 + width;
		lum2 = lum + width;

		for (y = 0; y < height; y += 2)
		{
			for (x = 0; x < cols_2; x++)
			{
				int R, G, B;

				CR = *cr++;
				CB = *cb++;
				cr_r = Cr_r_tab[CR];
				cr_g = Cr_g_tab[CR];
				cb_g = Cb_g_tab[CB];
				cb_b = Cb_b_tab[CB];

				L = L_tab[(int) *lum++];

				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;

				*row1++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);

				L = L_tab[(int) *lum++];

				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;

				*row1++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);

				L = L_tab[(int) *lum2++];
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;

				*row2++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);

				L = L_tab[(int) *lum2++];
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;

				*row2++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);
			}

			lum += width;
			lum2 += width;
			row1 += width;
			row2 += width;
		}
	}
}

void CDDrawDisplay::YUV2AdjRGB16(UCHAR *lum, UCHAR *cr, UCHAR *cb, UCHAR *rgb, int width, int height)
{
	int x, y=0;
	short data[64];

	char* pContrast = (char*)mmx_contrast;
	char* pBright = (char*)mmx_bright;
	char* pSaturation = (char*)mmx_saturation;
	char* pHue = (char*)mmx_hue;

	if(m_mmxcap == CPU_SSE2 && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	{
		__asm
		{
		mov esi, [lum];
		mov edi, [rgb];
		mov eax, [cr];
		mov ebx, [cb];
		mov edx, width;

		movups xmm4, [c128];
		mov ecx, [pContrast]
		movups xmm6, [ecx];
		mov ecx, [pBright]
		movups xmm7, [ecx];

yuv2rgb_col:
		xor ecx, ecx;

yuv2rgb_row:
		push ecx;
		movups xmm0, [eax];
		movups xmm2, [ebx];
		pxor xmm3, xmm3;
		punpcklbw xmm0, xmm3;		// 0: cr 4 word
		punpcklbw xmm2, xmm3;		// 2: cb 4 word
		mov ecx, [pHue]
		movups xmm3, [ecx];
		paddw xmm0, xmm3;			// cr + m_hue
		psubw xmm2, xmm3;			// cb - m_hue
		psubw xmm0, xmm4;			// cr - 128
		psubw xmm2, xmm4;			// cb - 128
		mov ecx, [pSaturation]
		movups xmm3, [ecx];
		pmullw xmm0, xmm3;		// cr * m_saturation
		pmullw xmm2, xmm3;		// cb * m_saturation
		psraw xmm0, 7;			// cr >> 7;
		psraw xmm2, 7;			// cb >> 7;
		pop ecx;

		movaps xmm1, xmm0;
		movups xmm3, [red_cr];
		pmullw xmm0, mm3;
		psraw xmm0, 7;			// 0: Cr_r_tab[CR]
		movups [data], xmm0;

		movups xmm3, [green_cr];
		pmullw xmm1, xmm3;
		movups xmm5, xmm2;
		movups xmm3, [green_cb];
		pmullw xmm5, xmm3;
		paddw xmm1, xmm5;
		psraw xmm1, 7;			// 1: Cr_g_tab[CR] + Cb_g_tab[CB]
		movups [data+16], xmm1;

		movups xmm3, [blue_cb];
		pmullw xmm2, xmm3;
		psraw xmm2, 7;			// 2: Cb_b_tab[CB]
		movups [data+32], xmm2;


	/////////////////////// first
		movups xmm3, [esi];		// lum
		pxor xmm5, xmm5;
		punpcklbw xmm3, xmm5;
		psubw xmm3, xmm4;			// L - 128

		// arange data
		punpcklwd xmm0, xmm0;
		punpckldq xmm0, xmm0;
		paddw xmm0, xmm3;			// 0: R = L + cr_r

		punpcklwd xmm1, xmm1;
		punpckldq xmm1, xmm1;
		paddw xmm1, xmm3;			// 1: G = L + cr_g + cb_g;

		punpcklwd xmm2, xmm2;
		punpckldq xmm2, xmm2;
		paddw xmm2, xmm3;			// 2: B = L + cb_b

		// compute Red
		pmullw xmm0, xmm6;		// R * m_contrast
		psraw xmm0, 7;			// R >> 7;
		paddw xmm0, xmm7;			// R + m_bright

		packuswb xmm0, xmm0;
		punpcklbw xmm0, xmm5;

		psrlw xmm0, 3;
		psllw xmm0, 11;

		// compute Green
		pmullw xmm1, xmm6;		// G * m_contrast
		psraw xmm1, 7;			// G >> 7;
		paddw xmm1, xmm7;			// G + m_bright

		packuswb xmm1, xmm1;
		punpcklbw xmm1, xmm5;

		psrlw xmm1, 2;
		psllw xmm1, 5;

		// compute Blue
		pmullw xmm2, xmm6;		// B * m_contrast
		psraw xmm2, 7;			// B >> 7;
		paddw xmm2, xmm7;			// B + m_bright

		packuswb xmm2, xmm2;
		punpcklbw xmm2, xmm5;

		psrlw xmm2, 3;

		por xmm0, xmm1;
		por xmm0, xmm2;
		movaps [edi], xmm0;

	/////////////////////////// second
		movups xmm0, [data];
		movups xmm1, [data+16];
		movups xmm2, [data+32];
		movups xmm3, [esi+8];		// lum
		punpcklbw xmm3, xmm5;
		psubw xmm3, xmm4;			// L - 128

		// arange data
		punpcklwd xmm0, xmm0;
		punpckhdq xmm0, xmm0;
		paddw xmm0, xmm3;			// 0: R = L + cr_r

		punpcklwd xmm1, xmm1;
		punpckhdq xmm1, xmm1;
		paddw xmm1, xmm3;			// 1: G = L + cr_g + cb_g;

		punpcklwd xmm2, xmm2;
		punpckhdq xmm2, xmm2;
		paddw xmm2, xmm3;			// 2: B = L + cb_b

		// compute Red
		pmullw xmm0, xmm6;		// R * m_contrast
		psraw xmm0, 7;			// R >> 7;
		paddw xmm0, xmm7;			// R + m_bright

		packuswb xmm0, xmm0;
		punpcklbw xmm0, xmm5;

		psrlw xmm0, 3;
		psllw xmm0, 11;

		// compute Green
		pmullw xmm1, xmm6;		// G * m_contrast
		psraw xmm1, 7;			// G >> 7;
		paddw xmm1, xmm7;			// G + m_bright

		packuswb xmm1, xmm1;
		punpcklbw xmm1, xmm5;

		psrlw xmm1, 2;
		psllw xmm1, 5;

		// compute Blue
		pmullw xmm2, xmm6;		// B * m_contrast
		psraw xmm2, 7;			// B >> 7;
		paddw xmm2, xmm7;			// B + m_bright

		packuswb xmm2, xmm2;
		punpcklbw xmm2, xmm5;

		psrlw xmm2, 3;

		por xmm0, xmm1;
		por xmm0, xmm2;
		movups [edi+16], xmm0;

	////////////////////////// third
		movups xmm0, [data];
		movups xmm1, [data+16];
		movups xmm2, [data+32];
		movups xmm3, [esi+edx];		// lum
		punpcklbw xmm3, xmm5;
		psubw xmm3, xmm4;			// L - 128

		// arange data
		punpckhwd xmm0, xmm0;
		punpckldq xmm0, xmm0;
		paddw xmm0, xmm3;			// 0: R = L + cr_r

		punpckhwd xmm1, xmm1;
		punpckldq xmm1, xmm1;
		paddw xmm1, xmm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd xmm2, xmm2;
		punpckldq xmm2, xmm2;
		paddw xmm2, xmm3;			// 2: B = L + cb_b

		// compute Red
		pmullw xmm0, xmm6;		// R * m_contrast
		psraw xmm0, 7;			// R >> 7;
		paddw xmm0, xmm7;			// R + m_bright

		packuswb xmm0, xmm0;
		punpcklbw xmm0, xmm5;

		psrlw xmm0, 3;
		psllw xmm0, 11;

		// compute Green
		pmullw xmm1, xmm6;		// G * m_contrast
		psraw xmm1, 7;			// G >> 7;
		paddw xmm1, xmm7;			// G + m_bright

		packuswb xmm1, xmm1;
		punpcklbw xmm1, xmm5;

		psrlw xmm1, 2;
		psllw xmm1, 5;

		// compute Blue
		pmullw xmm2, xmm6;		// B * m_contrast
		psraw xmm2, 7;			// B >> 7;
		paddw xmm2, xmm7;			// B + m_bright

		packuswb xmm2, xmm2;
		punpcklbw xmm2, xmm5;

		psrlw xmm2, 3;

		por xmm0, xmm1;
		por xmm0, xmm2;
		add edi, edx;
		movups [edi+edx], xmm0;

	//////////////////////////// fourth
		movups xmm0, [data];
		movups xmm1, [data+16];
		movups xmm2, [data+32];
		movups xmm3, [esi+edx+8];		// lum
		punpcklbw xmm3, xmm5;
		psubw xmm3, xmm4;			// L - 128

		// arange data
		punpckhwd xmm0, xmm0;
		punpckhdq xmm0, xmm0;
		paddw xmm0, xmm3;			// 0: R = L + cr_r

		punpckhwd xmm1, xmm1;
		punpckhdq xmm1, xmm1;
		paddw xmm1, xmm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd xmm2, xmm2;
		punpckhdq xmm2, xmm2;
		paddw xmm2, xmm3;			// 2: B = L + cb_b

		// compute Red
		pmullw xmm0, xmm6;		// R * m_contrast
		psraw xmm0, 7;			// R >> 7;
		paddw xmm0, xmm7;			// R + m_bright

		packuswb xmm0, xmm0;
		punpcklbw xmm0, xmm5;

		psrlw xmm0, 3;
		psllw xmm0, 11;

		// compute Green
		pmullw xmm1, xmm6;		// G * m_contrast
		psraw xmm1, 7;			// G >> 7;
		paddw xmm1, xmm7;			// G + m_bright

		packuswb xmm1, xmm1;
		punpcklbw xmm1, xmm5;

		psrlw xmm1, 2;
		psllw xmm1, 5;

		// compute Blue
		pmullw xmm2, xmm6;		// B * m_contrast
		psraw xmm2, 7;			// B >> 7;
		paddw xmm2, xmm7;			// B + m_bright

		packuswb xmm2, xmm2;
		punpcklbw xmm2, xmm5;

		psrlw xmm2, 3;

		por xmm0, xmm1;
		por xmm0, xmm2;
		movups [edi+edx+16], xmm0;
		sub edi, edx;

		add eax, 8;
		add ebx, 8;
		add esi, 16;
		add edi, 32;

		add ecx, 16;
		cmp ecx, edx;
		jne yuv2rgb_row;

		add esi, edx;
		add edi, edx;
		add edi, edx;

		mov ecx, y;
		add ecx, 2;
		mov y, ecx;
		cmp ecx, height;
		jne yuv2rgb_col;
		}
	}
	else if(m_mmxcap == CPU_MMX && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	{
		__asm
		{
		mov esi, [lum];
		mov edi, [rgb];
		mov eax, [cr];
		mov ebx, [cb];
		mov edx, width;

		movq mm4, [c128];
		mov ecx, [pContrast];
		movq mm6, [ecx];
		mov ecx, [pBright];
		movq mm7, [ecx];

yuv2rgb_mmx_col:
		xor ecx, ecx;

yuv2rgb_mmx_row:
		movd mm0, [eax];
		movd mm2, [ebx];
		pxor mm3, mm3;
		punpcklbw mm0, mm3;		// 0: cr 4 word
		punpcklbw mm2, mm3;		// 2: cb 4 word

		push eax;
		mov eax, [pHue];
		movq mm3, [eax];
		paddw mm0, mm3;			// cr + m_hue
		psubw mm2, mm3;			// cb - m_hue
		psubw mm0, mm4;			// cr - 128
		psubw mm2, mm4;			// cb - 128
		mov eax, [pSaturation];
		movq mm3, [eax];
		pop eax;

		pmullw mm0, mm3;		// cr * m_saturation
		pmullw mm2, mm3;		// cb * m_saturation
		psraw mm0, 7;			// cr >> 7;
		psraw mm2, 7;			// cb >> 7;

		movq mm1, mm0;
		pmullw mm0, [red_cr];
		psraw mm0, 7;			// 0: Cr_r_tab[CR]
		movq [data], mm0;

		pmullw mm1, [green_cr];
		movq mm5, mm2;
		pmullw mm5, [green_cb];
		paddw mm1, mm5;
		psraw mm1, 7;			// 1: Cr_g_tab[CR] + Cb_g_tab[CB]
		movq [data+8], mm1;

		pmullw mm2, [blue_cb];
		psraw mm2, 7;			// 2: Cb_b_tab[CB]
		movq [data+16], mm2;


	/////////////////////// first
		movd mm3, [esi];		// lum
		pxor mm5, mm5;
		punpcklbw mm3, mm5;
		psubw mm3, mm4;			// L - 128

		// arange data
		punpcklwd mm0, mm0;
		punpckldq mm0, mm0;
		paddw mm0, mm3;			// 0: R = L + cr_r

		punpcklwd mm1, mm1;
		punpckldq mm1, mm1;
		paddw mm1, mm3;			// 1: G = L + cr_g + cb_g;

		punpcklwd mm2, mm2;
		punpckldq mm2, mm2;
		paddw mm2, mm3;			// 2: B = L + cb_b

		// compute Red
		pmullw mm0, mm6;		// R * m_contrast
		psraw mm0, 7;			// R >> 7;
		paddw mm0, mm7;			// R + m_bright

		packuswb mm0, mm0;
		punpcklbw mm0, mm5;

		psrlw mm0, 3;
		psllw mm0, 11;

		// compute Green
		pmullw mm1, mm6;		// G * m_contrast
		psraw mm1, 7;			// G >> 7;
		paddw mm1, mm7;			// G + m_bright

		packuswb mm1, mm1;
		punpcklbw mm1, mm5;

		psrlw mm1, 2;
		psllw mm1, 5;

		// compute Blue
		pmullw mm2, mm6;		// B * m_contrast
		psraw mm2, 7;			// B >> 7;
		paddw mm2, mm7;			// B + m_bright

		packuswb mm2, mm2;
		punpcklbw mm2, mm5;

		psrlw mm2, 3;

		por mm0, mm1;
		por mm0, mm2;
		movq [edi], mm0;

	/////////////////////////// second
		movq mm0, [data];
		movq mm1, [data+8];
		movq mm2, [data+16];
		movd mm3, [esi+4];		// lum
		punpcklbw mm3, mm5;
		psubw mm3, mm4;			// L - 128

		// arange data
		punpcklwd mm0, mm0;
		punpckhdq mm0, mm0;
		paddw mm0, mm3;			// 0: R = L + cr_r

		punpcklwd mm1, mm1;
		punpckhdq mm1, mm1;
		paddw mm1, mm3;			// 1: G = L + cr_g + cb_g;

		punpcklwd mm2, mm2;
		punpckhdq mm2, mm2;
		paddw mm2, mm3;			// 2: B = L + cb_b

		// compute Red
		pmullw mm0, mm6;		// R * m_contrast
		psraw mm0, 7;			// R >> 7;
		paddw mm0, mm7;			// R + m_bright

		packuswb mm0, mm0;
		punpcklbw mm0, mm5;

		psrlw mm0, 3;
		psllw mm0, 11;

		// compute Green
		pmullw mm1, mm6;		// G * m_contrast
		psraw mm1, 7;			// G >> 7;
		paddw mm1, mm7;			// G + m_bright

		packuswb mm1, mm1;
		punpcklbw mm1, mm5;

		psrlw mm1, 2;
		psllw mm1, 5;

		// compute Blue
		pmullw mm2, mm6;		// B * m_contrast
		psraw mm2, 7;			// B >> 7;
		paddw mm2, mm7;			// B + m_bright

		packuswb mm2, mm2;
		punpcklbw mm2, mm5;

		psrlw mm2, 3;

		por mm0, mm1;
		por mm0, mm2;
		movq [edi+8], mm0;

	////////////////////////// third
		movq mm0, [data];
		movq mm1, [data+8];
		movq mm2, [data+16];
		movd mm3, [esi+edx];		// lum
		punpcklbw mm3, mm5;
		psubw mm3, mm4;			// L - 128

		// arange data
		punpckhwd mm0, mm0;
		punpckldq mm0, mm0;
		paddw mm0, mm3;			// 0: R = L + cr_r

		punpckhwd mm1, mm1;
		punpckldq mm1, mm1;
		paddw mm1, mm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd mm2, mm2;
		punpckldq mm2, mm2;
		paddw mm2, mm3;			// 2: B = L + cb_b

		// compute Red
		pmullw mm0, mm6;		// R * m_contrast
		psraw mm0, 7;			// R >> 7;
		paddw mm0, mm7;			// R + m_bright

		// Round to 0-255
		packuswb mm0, mm0;
		punpcklbw mm0, mm5;

		psrlw mm0, 3;
		psllw mm0, 11;

		// compute Green
		pmullw mm1, mm6;		// G * m_contrast
		psraw mm1, 7;			// G >> 7;
		paddw mm1, mm7;			// G + m_bright

		packuswb mm1, mm1;
		punpcklbw mm1, mm5;

		psrlw mm1, 2;
		psllw mm1, 5;

		// compute Blue
		pmullw mm2, mm6;		// B * m_contrast
		psraw mm2, 7;			// B >> 7;
		paddw mm2, mm7;			// B + m_bright

		packuswb mm2, mm2;
		punpcklbw mm2, mm5;

		psrlw mm2, 3;

		por mm0, mm1;
		por mm0, mm2;
		add edi, edx;
		movq [edi+edx], mm0;

	//////////////////////////// fourth
		movq mm0, [data];
		movq mm1, [data+8];
		movq mm2, [data+16];
		movd mm3, [esi+edx+4];		// lum
		punpcklbw mm3, mm5;
		psubw mm3, mm4;			// L - 128

		// arange data
		punpckhwd mm0, mm0;
		punpckhdq mm0, mm0;
		paddw mm0, mm3;			// 0: R = L + cr_r

		punpckhwd mm1, mm1;
		punpckhdq mm1, mm1;
		paddw mm1, mm3;			// 1: G = L + cr_g + cb_g;

		punpckhwd mm2, mm2;
		punpckhdq mm2, mm2;
		paddw mm2, mm3;			// 2: B = L + cb_b

		// compute Red
		pmullw mm0, mm6;		// R * m_contrast
		psraw mm0, 7;			// R >> 7;
		paddw mm0, mm7;			// R + m_bright

		packuswb mm0, mm0;
		punpcklbw mm0, mm5;

		psrlw mm0, 3;
		psllw mm0, 11;

		// compute Green
		pmullw mm1, mm6;		// G * m_contrast
		psraw mm1, 7;			// G >> 7;
		paddw mm1, mm7;			// G + m_bright

		packuswb mm1, mm1;
		punpcklbw mm1, mm5;

		psrlw mm1, 2;
		psllw mm1, 5;

		// compute Blue
		pmullw mm2, mm6;		// B * m_contrast
		psraw mm2, 7;			// B >> 7;
		paddw mm2, mm7;			// B + m_bright

		packuswb mm2, mm2;
		punpcklbw mm2, mm5;

		psrlw mm2, 3;

		por mm0, mm1;
		por mm0, mm2;
		movq [edi+edx+8], mm0;
		sub edi, edx;

		add eax, 4;
		add ebx, 4;
		add esi, 8;
		add edi, 16;

		add ecx, 8;
		cmp ecx, edx;
		jne yuv2rgb_mmx_row;

		add esi, edx;
		add edi, edx;
		add edi, edx;

		mov ecx, y;
		add ecx, 2;
		mov y, ecx;
		cmp ecx, height;
		jne yuv2rgb_mmx_col;

		emms;
		}
	}
	else
	{
		int L, CR, CB;
		unsigned short *row1, *row2;
		UCHAR *lum2;
		int cr_r;
		int cr_g;
		int cb_g;
		int cb_b;
		int cols_2;
		int R, G, B;
		
		cols_2 = width >> 1;
		
		row1 = (unsigned short *) rgb;
		row2 = row1 + width;
		lum2 = lum + width;
		for (y = 0; y < height; y += 2)
		{
			for (x = 0; x < cols_2; x++)
			{
				CR = *cr++;
				CB = *cb++;
				CR = (CR + m_hue);
				CB = (CB - m_hue);
				CR = max(0, min(255, ((CR - 128) * m_saturation >> 7) + 128));
				CB = max(0, min(255, ((CB - 128) * m_saturation >> 7) + 128));
				
				cr_r = Cr_r_tab[CR];
				cr_g = Cr_g_tab[CR];
				cb_g = Cb_g_tab[CB];
				cb_b = Cb_b_tab[CB];
				
				L = (int) *lum++;
				L -= 128;
				
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;
				
				R = max(0, min(255, ((R*m_contrast >> 7) + m_bright)));
				G = max(0, min(255, ((G*m_contrast >> 7) + m_bright)));
				B = max(0, min(255, ((B*m_contrast >> 7) + m_bright)));
				
				*row1++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);
				
				L = (int) *lum++;
				L -= 128;
				
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;
				
				R = max(0, min(255, ((R*m_contrast >> 7) + m_bright)));
				G = max(0, min(255, ((G*m_contrast >> 7) + m_bright)));
				B = max(0, min(255, ((B*m_contrast >> 7) + m_bright)));
				
				*row1++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);
				
				L = (int) *lum2++;
				L -= 128;
				
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;
				
				R = max(0, min(255, ((R*m_contrast >> 7) + m_bright)));
				G = max(0, min(255, ((G*m_contrast >> 7) + m_bright)));
				B = max(0, min(255, ((B*m_contrast >> 7) + m_bright)));
				
				*row2++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);
				
				L = (int) *lum2++;
				L -= 128;
				
				R = L + cr_r;
				G = L + cr_g + cb_g;
				B = L + cb_b;
				
				R = max(0, min(255, ((R*m_contrast >> 7) + m_bright)));
				G = max(0, min(255, ((G*m_contrast >> 7) + m_bright)));
				B = max(0, min(255, ((B*m_contrast >> 7) + m_bright)));
				
				*row2++ = (r_2_pix[R] | g_2_pix[G] | b_2_pix[B]);
			}
			
			lum += width;
			lum2 += width;
			row1 += width;
			row2 += width;
		}
	}
}


void CDDrawDisplay::YUVtoRGB24(unsigned char *src0, unsigned char *src1, unsigned char *src2,
							   unsigned char *dst_ori, int width, int height)
{
	int y11, y21;
	int y12, y22;
	int y13, y23;
	int y14, y24;
	int u, v;
	int i, j;
	int c11, c21, c31, c41;
	int c12, c22, c32, c42;
	unsigned int DW;
	unsigned int *id1, *id2;
	unsigned char *py1, *py2, *pu, *pv;
	unsigned char *d1, *d2;
	
	d1 = dst_ori;
	d1 += width * height * 3 - width * 3;
	d2 = d1 - width * 3;
	
	py1 = src0;
	pu = src1;
	pv = src2;
	py2 = py1 + width;
	
	id1 = (unsigned int *) d1;
	id2 = (unsigned int *) d2;
	
	for (j = 0; j < height; j += 2)
	{
		/* line j + 0 */
		for (i = 0; i < width; i += 4)
		{
			u = *pu++;
			v = *pv++;
			c11 = crv_tab[v];
			c21 = cgu_tab[u];
			c31 = cgv_tab[v];
			c41 = cbu_tab[u];
			u = *pu++;
			v = *pv++;
			c12 = crv_tab[v];
			c22 = cgu_tab[u];
			c32 = cgv_tab[v];
			c42 = cbu_tab[u];
			
			y11 = tab_76309[*py1++];  /* (255/219)*65536 */
			y12 = tab_76309[*py1++];
			y13 = tab_76309[*py1++];  /* (255/219)*65536 */
			y14 = tab_76309[*py1++];
			
			y21 = tab_76309[*py2++];
			y22 = tab_76309[*py2++];
			y23 = tab_76309[*py2++];
			y24 = tab_76309[*py2++];
			
			/* RGBR */
			DW = ((clp[(y11 + c41) >> 16])) |
				((clp[(y11 - c21 - c31) >> 16]) << 8) |
				((clp[(y11 + c11) >> 16]) << 16) |
				((clp[(y12 + c41) >> 16]) << 24);
			*id1++ = DW;
			
			/* GBRG */
			DW = ((clp[(y12 - c21 - c31) >> 16])) |
				((clp[(y12 + c11) >> 16]) << 8) |
				((clp[(y13 + c42) >> 16]) << 16) |
				((clp[(y13 - c22 - c32) >> 16]) << 24);
			*id1++ = DW;
			
			/* BRGB */
			DW = ((clp[(y13 + c12) >> 16])) |
				((clp[(y14 + c42) >> 16]) << 8) |
				((clp[(y14 - c22 - c32) >> 16]) << 16) |
				((clp[(y14 + c12) >> 16]) << 24);
			*id1++ = DW;
			
			/* RGBR */
			DW = ((clp[(y21 + c41) >> 16])) |
				((clp[(y21 - c21 - c31) >> 16]) << 8) |
				((clp[(y21 + c11) >> 16]) << 16) |
				((clp[(y22 + c41) >> 16]) << 24);
			*id2++ = DW;
			
			/* GBRG */
			DW = ((clp[(y22 - c21 - c31) >> 16])) |
				((clp[(y22 + c11) >> 16]) << 8) |
				((clp[(y23 + c42) >> 16]) << 16) |
				((clp[(y23 - c22 - c32) >> 16]) << 24);
			*id2++ = DW;
			
			/* BRGB */
			DW = ((clp[(y23 + c12) >> 16])) |
				((clp[(y24 + c42) >> 16]) << 8) |
				((clp[(y24 - c22 - c32) >> 16]) << 16) |
				((clp[(y24 + c12) >> 16]) << 24);
			*id2++ = DW;
		}
		int widthchng = ((width << 3) + width) >> 2;
		id1 -= widthchng;
		id2 -= widthchng;
		py1 += width;
		py2 += width;
	}
}


CDDrawDisplay::CDDrawDisplay() 
{
	m_lBrightness_osd	= 0;	//�豸Ĭ������		caojun   071212
	m_ddcap				= 0;	//ddraw capability
	m_pDD				= NULL;
	m_pDDSPrimary		= NULL;
	m_pDDSMy			= NULL;
	m_pDDClipper		= NULL;
	m_bQuandDiaplsy		= FALSE;
	m_nQuandCh			= 0;
	m_pszRGB			= NULL;
	m_bDisplayMode		= 0;
	m_lpddOsdBackSurface = NULL;

	m_pDDSOSD			= NULL;
	m_pPalette			= NULL;
	m_lpBackBuffer		= NULL;
	m_lBrightness_cp	= 0;

	GetMmxCap();
	SetColorDefault();
	SetRect(&m_ConverRect,0,0,0,0);
	InitializeCriticalSection(&m_critial);

	if(!g_InitRGB16Dither)
	{
		InitRGB16Dither();
		g_InitRGB16Dither = TRUE;
	}

//	m_DevcieType	= DVR_NO_SUPPORT_TYPE;
//	m_DeviceSubType	= DVR_SUB_NONEED;


	InitOsd();

	
	memset(m_OsdInfo1, 0, sizeof(m_OsdInfo1));
	m_iOsdLen1 = 0;
	memset(m_OsdInfo2, 0, sizeof(m_OsdInfo2));
	m_iOsdLen2 = 0;
	memset(m_OsdInfo3, 0, sizeof(m_OsdInfo3));
	m_iOsdLen3 = 0;
	m_lShowMdvrInfo = HI_HIDE;

	InitializeCriticalSection(&m_csOsd);

#ifdef PLAY_WITHD3D
	// Direct3D
	m_pDirect3D9				= NULL;
	m_pDirect3DDevice			= NULL;

	m_pDirect3DSurfaceRender	= NULL;
	m_pDirect3DTexture			= NULL;
	m_pDirect3DVertexBuffer		= NULL;

	m_pD3DFont					= NULL;
	m_pD3DSprite				= NULL;
#endif		// PLAY_WITHD3D

	m_lVideoWidth		= 0;
	m_lVideoHeight		= 0;

	m_hShowWnd			= NULL;
	m_cVideoCardType	= 0;
	//ReleaseDirect3D();
}

CDDrawDisplay::~CDDrawDisplay()
{
	ReleaseSth();

	DeleteCriticalSection(&m_critial);
	DeleteCriticalSection(&m_csOsd);
}

void CDDrawDisplay::ReleaseSth()
{
	ReleaseDDraw();
	ReleaseDirect3D();
}

void CDDrawDisplay::Lock()
{
	//EnterCriticalSection(&m_critial);
}

void CDDrawDisplay::UnLock()
{
	//LeaveCriticalSection(&m_critial);
}

void CDDrawDisplay::SetColorDefault()
{
	SetColorPara(COLOR_HUE, 0);
	SetColorPara(COLOR_BRIGHT, 0x80);
	SetColorPara(COLOR_SATURATION, 0x80);
	SetColorPara(COLOR_CONTRAST, 0x80);
}

void CDDrawDisplay::SetColorPara(int para, int value)
{
	if(para == COLOR_BRIGHT)
	{
		m_bright = value;
		for(int i=0; i<8; i++)
			mmx_bright[i] = value;
	}
	else if(para == COLOR_HUE)
	{
		m_hue = value;
		for(int i=0; i<8; i++)
			mmx_hue[i] = value;
	}
	else if(para == COLOR_SATURATION)
	{
		m_saturation = value;
		for(int i=0; i<8; i++)
			mmx_saturation[i] = value;
	}
	else if(para == COLOR_CONTRAST)
	{
		m_contrast = value;
		for(int i=0; i<8; i++)
			mmx_contrast[i] = value;
	}
}



BOOL CDDrawDisplay::SetQuandDisplay(BOOL Quand, int Chnnal)
{
	m_bQuandDiaplsy = Quand;
	m_nQuandCh = Chnnal;

	return TRUE;

}



void CDDrawDisplay::SetDisplayMode(int Pos, int mode)
{
	m_bDisplayMode = mode;
	m_bpos = Pos;

}

void CDDrawDisplay::InitBmpHeader (int width, int height)
{
	//ZJX/20101019/˫��֧��
	/* now modify the couple that need it */
	bmp_head.biWidth = width;
	bmp_head.biHeight = -height;
	bmp_head.biSizeImage = width * height * 2;

	bmp_head.biSize = sizeof(BITMAPINFOHEADER);
	bmp_head.biCompression = BI_BITFIELDS;//BI_RGB;
	bmp_head.biPlanes = 1;
	bmp_head.biBitCount = 16;
	bmp_head.biXPelsPerMeter = 0;
	bmp_head.biYPelsPerMeter = 0;
	bmp_head.biClrUsed = 3;
	bmp_head.biClrImportant = 0;

	mask[0] = 0xF800;
	mask[1] = 0x07e0;
	mask[2] = 0x001f;

	if(!m_pszRGB)
	{
		//rgb = new UCHAR[bmp_head.biSizeImage];
		//m_pszRGB = new UCHAR[576*720*4];
		m_pszRGB = new UCHAR[576*720*8];
	}
}

void CDDrawDisplay::SetShowWnd(HWND hWnd)
{
	m_hShowWnd = hWnd;
}

// ����ֵ�����ɹ�����0���ɹ�����֧�ֵ�ͼ���ʽ MYCAP_BLTYUV ���� MYCAP_BLT
long CDDrawDisplay::InitDDraw(HWND h, int width, int height)
{
	//return 1;
	
	m_bRecordFlag = false;

	unsigned long lRet;
#ifdef	PLAY_WITHD3D
	// ����Direct3D����������ԣ��Ͱ�������ɾ���������ڱ�����������ע����ͬ�����ݣ�һ��������by Ligo, 2008.6.27
	lRet = InitDirect3D( h, width, height );

	if ( lRet == HI_ERR_SUCCESS )
	{
		// �����ʼ��d3d�ɹ�����ֱ�ӷ��أ����򣬼�������ʹ��ddraw
		m_ddcap = MYCAP_BLTYUV;
		m_hShowWnd = h;
		m_cVideoCardType = 1;
		return m_ddcap;
	}
#endif

	ReleaseDDraw();

	Lock();
	m_hShowWnd = h;
	dd_height = height;
	dd_width = width;
	long i;

//	if ( h )
//		Trace( "ddraw start - %p, hwnd = %d\n", this, m_hShowWnd );
	m_bDisplayMode = 0;
	m_bpos = 0;

	//if(!g_InitRGB16Dither && m_DevcieType == DVR_ATM_REALTIME_TYPE )		// 2006.8.2, Ligo
	if ( !g_InitRGB16Dither )
	{
		InitRGB16Dither();
		g_InitRGB16Dither = TRUE;
	}

	if(DirectDrawCreateEx(NULL,(void **) &m_pDD, IID_IDirectDraw7, NULL))
	{
		UnLock();
		return 0;
	}
	m_pDD->SetCooperativeLevel(NULL, DDSCL_NORMAL);

	DDCAPS          capsDrv;
	INIT_DIRECTDRAW_STRUCT(capsDrv);
	if(m_pDD->GetCaps(&capsDrv, NULL))
	{
		UnLock();
		return 0;
	}
	
	if(capsDrv.dwCaps & DDCAPS_BLTFOURCC)
	{
		m_ddcap = MYCAP_BLTYUV;
	}
	else if(capsDrv.dwCaps & DDCAPS_BLT)
	{
		m_ddcap = MYCAP_BLT;
	}

	// �ж��Ƿ�Ϊ˫����ʾ������ǣ������RGB�ķ�ʽ��ʾ
	if (GetSystemMetrics(SM_CMONITORS) > 1)
	{
		m_ddcap = MYCAP_BLT;
	}
	
	// 2006.6.20, by Ligo
	//for test
	//m_ddcap = MYCAP_BLT;
	

	DDSURFACEDESC2 ddsd;
	INIT_DIRECTDRAW_STRUCT(ddsd);
	ddsd.dwFlags = DDSD_CAPS;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE; 
	if(m_pDD->CreateSurface(&ddsd, &m_pDDSPrimary, NULL)) 
	{
		UnLock();
		return 0;
	}

	//YUYV
	DDPIXELFORMAT ddpf = {sizeof(DDPIXELFORMAT), DDPF_FOURCC,0x32595559,0,0,0,0,0};
	//UYUV
	//DDPIXELFORMAT ddpf = {sizeof(DDPIXELFORMAT), DDPF_FOURCC,0x59565955,0,0,0,0,0};

	INIT_DIRECTDRAW_STRUCT(ddsd);

	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
	ddsd.ddsCaps.dwCaps =  DDSCAPS_VIDEOMEMORY| DDSCAPS_OFFSCREENPLAIN;

	ddsd.dwWidth  = width;
	ddsd.dwHeight = height;
	ddsd.ddpfPixelFormat = ddpf;
	if ( m_ddcap == MYCAP_BLTYUV )
	{
		if(m_pDD->CreateSurface(&ddsd, &m_pDDSMy, NULL))
		{
			//m_ddcap = MYCAP_NOTHING;			//hw 2007-05-29
			m_ddcap = MYCAP_BLT;
		}
	}

	/*
	// ��ȡ���Ƚӿ�
	//LPDIRECTDRAWCOLORCONTROL lpDDCC;
	LPDIRECTDRAWGAMMACONTROL lpDDGC;
	HRESULT hrt = m_pDDSMy->QueryInterface( IID_IDirectDrawGammaControl, (LPVOID*)&lpDDGC );
	if ( hrt == E_NOINTERFACE )
	{
		DebugMsg( "No interface\n" );
	}
	else
	{
		DebugMsg( "interface for color control\n" );

		DDGAMMARAMP dgamma;
		for ( i = 0; i < 256; i++ )
		{
			dgamma.red[i] = 0;
			dgamma.green[i] = 0;
			dgamma.blue[i] = 255 - i;
		}
		hrt = lpDDGC->SetGammaRamp( 1, &dgamma );
		if ( hrt == DD_OK )
		{
			DebugMsg( "setGammaRamp()�ɹ���\n" );
		}
		else
		{
			DebugMsg( "setGammaRamp()ʧ�ܣ�����\n" );
		}
	}
	//*/

	// 20090724 xh ����¼����
	INIT_DIRECTDRAW_STRUCT(ddsd); 
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_VIDEOMEMORY | DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth = 15;
	ddsd.dwHeight = 15;
	if (m_pDD->CreateSurface(&ddsd, &m_lpDDSRecordFlag, NULL))
	{
		SAFE_RELEASE(m_pDDSPrimary);
		UnLock();
		return 0;
	}

	/************** 2007.9.6 **************/
	// ��ʼ��ר��д�ֵı���
	INIT_DIRECTDRAW_STRUCT(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps =  DDSCAPS_VIDEOMEMORY| DDSCAPS_OFFSCREENPLAIN;// | DDSCAPS_PALETTE;

	ddsd.dwWidth  = width;
	ddsd.dwHeight = height;

	//ddsd

	if ( m_pDD->CreateSurface( &ddsd, &m_pDDSOSD, NULL ) )
	{
		SAFE_RELEASE(m_pDDSPrimary);
		UnLock();
		return 0;
	}

	// ������ɫ��
	PALETTEENTRY entry[256];
	for ( i = 0; i < 256; i++ )
	{
		entry[i].peFlags = NULL;
		entry[i].peBlue = i;
		entry[i].peGreen = i;
		entry[i].peRed = i;
	}

	/*
	hrt = m_pDD->CreatePalette( DDPCAPS_8BIT, entry, &m_pPalette, NULL );
	switch ( hrt )
	{
	case DD_OK:
		break;

	case DDERR_INVALIDOBJECT:
		hrt = 1;
		break;

	case DDERR_INVALIDPARAMS:
		hrt = 2;		// this
		break;

	case DDERR_NOCOOPERATIVELEVELSET:
		hrt = 3;
		break;
	case DDERR_OUTOFMEMORY:
		hrt = 4;
		break;
	case DDERR_UNSUPPORTED:
		hrt = 5;
		break;
	default:
		UnLock();
		return 0;
	}

	m_pDDSOSD->SetPalette( m_pPalette );
	//m_pDDSMy->SetPalette( m_pPalette );
	/************ 2007.9.6 end ************/

	//if(m_ddcap == MYCAP_BLT)
	if(m_ddcap != MYCAP_BLTYUV)
	{
		ddpf.dwFlags = DDPF_RGB;
		ddpf.dwFourCC = 0;
		ddpf.dwRGBBitCount = 16;
		ddpf.dwRBitMask = 0xF800;//0xff0000;
		ddpf.dwGBitMask = 0x07e0;//0xff00;
		ddpf.dwBBitMask = 0x001f;//0xff;

		InitBmpHeader(width, height);
	}
	else
	{
		//wangyi
//		ddpf.dwFlags  = DDPF_FOURCC | DDPF_YUV ;
//		ddpf.dwFourCC = MAKEFOURCC('Y','U','Y','2');
		//ddpf.dwFourCC =  MAKEFOURCC('Y','V','1','2');
		//ddpf.dwFourCC = MAKEFOURCC('U','Y','V','Y');
//		ddpf.dwYUVBitCount = 8;
	}

//	INIT_DIRECTDRAW_STRUCT(ddsd);
//
//	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
//	ddsd.ddsCaps.dwCaps =  DDSCAPS_VIDEOMEMORY| DDSCAPS_OFFSCREENPLAIN;
//
//	ddsd.dwWidth  = width;
//	ddsd.dwHeight = height;
//	ddsd.ddpfPixelFormat = ddpf;
//	if ( m_ddcap == MYCAP_BLTYUV )
//		if(m_pDD->CreateSurface(&ddsd, &m_pDDSMy, NULL))  
//			//m_ddcap = MYCAP_NOTHING;			//hw 2007-05-29
//			m_ddcap = MYCAP_BLT;
//
	
	if(m_pDD->CreateClipper(0, &m_pDDClipper, NULL))
	{
		//InitBmpHeader(width, height);
		UnLock();
		return 0;
	}
	if(m_pDDClipper->SetHWnd(0, m_hShowWnd))
	{
		//InitBmpHeader(width, height);
		UnLock();
		return 0;
	}
	if(m_pDDSPrimary->SetClipper(m_pDDClipper))
	{
		//InitBmpHeader(width, height);
		UnLock();
		return 0;
	}
	m_pDDClipper->Release();
	m_pDDClipper = NULL;			// added by Ligo, 2008.11.6

	CreatInfoSurface( m_lpBackBuffer );

	UnLock();

//	SetColor(0, 0, 0, 0);
	
	m_cVideoCardType = 2;
	return m_ddcap;		// 1
}


int CDDrawDisplay::CreateRGBSurface(DDBLTFX ddbltfx, int *s32RGBFormat)
{
    if (NULL == m_pDD)
    {
        return -1;
    }

    ddsdOffBuf.ddpfPixelFormat = ddsdFrontBuf.ddpfPixelFormat;  //����������Ϊ��ҳ������
    int hr = m_pDD->CreateSurface(&ddsdOffBuf, &m_pDDSOSD, NULL);
    if (FAILED(hr) || FAILED(m_pDDSOSD->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx)))
    {
        return -1;
    }

    ZeroMemory(&m_ddsd, sizeof(DDSURFACEDESC2));
    m_ddsd.dwSize = sizeof(DDSURFACEDESC2);
    m_ddrval = m_pDDSOSD->Lock(NULL, &m_ddsd,
                                     DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT, NULL);
    if ( FAILED(m_ddrval) )
    {
        return -1;
    }
    else
    {
        //����
        m_pDDSOSD->Unlock(NULL);
    }

	hr = DetectRGBFormat(s32RGBFormat);

    return hr;
}


int CDDrawDisplay::DetectRGBFormat(int *s32RGBFormat)
{
    if (32 == ddsdFrontBuf.ddpfPixelFormat.dwRGBBitCount)  //��⵽RGB32
    {
        *s32RGBFormat = 32;
    }
    else if (24 == ddsdFrontBuf.ddpfPixelFormat.dwRGBBitCount)  //��⵽RGB24
    {
        *s32RGBFormat = 24;
    }
    else if (16 == ddsdFrontBuf.ddpfPixelFormat.dwRGBBitCount) //֧��RGB16
    {
        if (0xf800 == ddsdFrontBuf.ddpfPixelFormat.dwRBitMask)
        {
            *s32RGBFormat = 565;
        }
        else if (0x7c00 == ddsdFrontBuf.ddpfPixelFormat.dwRBitMask)
        {
            *s32RGBFormat = 555;
        }
        else //��֧��RGB565��RGB555
        {
            *s32RGBFormat = 0;
            return -1;
        }
    }
    else //��֧��RGB32��RGB24��RGB16
    {
        *s32RGBFormat = 0;
        return -1;
    }

	return 0;
}



void CDDrawDisplay::MoveVideoToMid()
{
    if (m_s32Width > (m_rcWindow.right - m_rcWindow.left))
    {
        m_rcWindow.left = m_rcWindow.left
                          - ((m_s32Width - (m_rcWindow.right - m_rcWindow.left)) / 2);
    }
    else
    {
        m_rcWindow.left = m_rcWindow.left
                          + (((m_rcWindow.right - m_rcWindow.left) - m_s32Width) / 2);
    }

    if (m_s32Height > (m_rcWindow.bottom - m_rcWindow.top))
    {
        m_rcWindow.top = m_rcWindow.top
                         - ((m_s32Height - (m_rcWindow.bottom - m_rcWindow.top)) / 2);
    }
    else
    {
        m_rcWindow.top = m_rcWindow.top
                         + (((m_rcWindow.bottom - m_rcWindow.top) - m_s32Height) / 2);
    }
    m_rcWindow.right = m_rcWindow.left + m_s32Width;
    m_rcWindow.bottom = m_rcWindow.top + m_s32Height;
}

int CDDrawDisplay::InitGDI()
{
    /* now modify the couple that need it */

    m_s32Bmpsize = m_s32Width * m_s32Height * 3 + 40;

    m_hMem = NULL;
    m_hMem = ::GlobalAlloc(GMEM_MOVEABLE, m_s32Bmpsize);
    m_pBuf = (BYTE*) ::GlobalLock(m_hMem);
    m_lpDib = (LPBITMAPINFO)m_pBuf;
    if (NULL != m_lpDib)
    {
        m_lpDib->bmiHeader.biWidth = m_s32Width;
        m_lpDib->bmiHeader.biHeight = m_s32Height;
        m_lpDib->bmiHeader.biSizeImage = m_s32Width * m_s32Height * 3;
        m_lpDib->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        m_lpDib->bmiHeader.biCompression = BI_RGB;
        m_lpDib->bmiHeader.biPlanes = 1;
        m_lpDib->bmiHeader.biBitCount = 24;
        m_lpDib->bmiHeader.biXPelsPerMeter = 0;
        m_lpDib->bmiHeader.biYPelsPerMeter = 0;
        m_lpDib->bmiHeader.biClrUsed = 0;
        m_lpDib->bmiHeader.biClrImportant = 0;
        m_pDib = (BYTE*)m_lpDib + 40;
    }

    m_hdc = GetDC(m_hWnd);

    //����
    this->UpdateBounds();
    RECT rcInvalidate;
    rcInvalidate.top = 0;
    rcInvalidate.left = 0;
    rcInvalidate.right = m_rcWindow.right - m_rcWindow.left;
    rcInvalidate.bottom = m_rcWindow.bottom - m_rcWindow.top;
    m_s32OrgZoomed = m_s32Zoom;
    InvalidateRect(m_hWnd, &rcInvalidate, TRUE);

    return 0;
}

int CDDrawDisplay::DrawGDI(
    LPBYTE lpInY,
    LPBYTE lpInU,
    LPBYTE lpInV
)
{
    //���ڱ߽�
    this->UpdateBounds();
    //���Ź�������
    if (m_s32OrgZoomed != m_s32Zoom)
    {
        m_s32OrgZoomed = m_s32Zoom;
		InvalidRect();
    }

    //����
    if (TRUE == m_s32ClearScreen)
    {
		InvalidRect();
        m_s32ClearScreen = FALSE;
        return 0;
    }

    if (TRUE == m_s32OrgZoomed) //�����ڴ�С��ʾ
    {
        m_rcWindow.right = m_rcWindow.right - m_rcWindow.left;
        m_rcWindow.bottom = m_rcWindow.bottom - m_rcWindow.top;
        m_rcWindow.left = 0;
        m_rcWindow.top = 0;
    }
    else //����Ƶ�ŵ������м�
    {
        MoveVideoToMid();
    }

    int iOldMode = SetStretchBltMode(m_hdc, COLORONCOLOR);

    if (IMAGE_NULL_FLAG != m_s32ImageType)
    {
        if (FALSE == m_s32Still)
        {
            YUVtoRGB24(lpInY,  lpInU, lpInV, 
                                         m_pDib, m_s32Width, -m_s32Height);
            m_bLastImage = TRUE;
        }
        else
        {
            if (FALSE == m_bLastImage)
            {
                SetStretchBltMode(m_hdc, iOldMode);
                return 0;
            }
        }
    }
    else
    {
        if (FALSE == m_bLastImage)
        {
            SetStretchBltMode(m_hdc, iOldMode);
            return 0;
        }
    }

    StretchDIBits
    (
        m_hdc,
        m_rcWindow.left,
        m_rcWindow.top,
        m_rcWindow.right,
        m_rcWindow.bottom,
        0,
        0,
        m_s32Width,
        m_s32Height,
        m_pDib,
        m_lpDib,
        DIB_RGB_COLORS,
        SRCCOPY
    );


    SetStretchBltMode(m_hdc, iOldMode);

    return 0;
}

void CDDrawDisplay::ReleaseDDraw()
{

	Lock();
	if(m_pDD)
	{
		if(m_pDDSPrimary)
			DDrawSurfaceClear(m_pDDSPrimary);
		
		SAFE_RELEASE(m_pDDClipper);
		SAFE_RELEASE(m_pDDSMy);
		SAFE_RELEASE(m_pDDSPrimary);
		SAFE_RELEASE(m_lpddOsdBackSurface);

		SAFE_RELEASE(m_lpDDSRecordFlag);
		SAFE_RELEASE(m_pPalette);
		SAFE_RELEASE(m_pDDSOSD);
		SAFE_RELEASE(m_lpBackBuffer);		// added by Ligo, 2008.11.6��ռ��2M�ڴ�

		SAFE_RELEASE(m_pDD);
	}
	if(m_pszRGB)
	{
		delete []m_pszRGB;
		m_pszRGB = NULL;
	}

	// �ô��ڻָ���ԭ���ı���ɫ��by Ligo, 2008.11.26
	if ( m_hShowWnd )
	{
		RECT rt;
		GetClientRect( m_hShowWnd, &rt );
		InvalidateRect( m_hShowWnd, &rt, TRUE );
		UpdateWindow( m_hShowWnd );
	}
	
	m_hShowWnd = NULL;

	UnLock();
}


void CDDrawDisplay::PlayRGB16Ex(char *Videdata, int width, int height, RECT dest, int iTotal, int ch)
{
	HDC hdc = GetDC(m_hShowWnd);
	int MapModeOld = SetMapMode(hdc, MM_TEXT);
	SetStretchBltMode(hdc, COLORONCOLOR);

	int pox1 = 0;
	int poy1 = 0;
	int temp_width = width;
	int temp_height = height;

	int j = 0;
	int i = 0;
	
	if(iTotal < 2)
	{
		int ImageWidth = width*2;
		int ImageHeight = height;
		int rgbWidth = width*2;
		int rgbHeight = height;
		for(i=0; i<rgbHeight;i++)
		{
			memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
		}
	}
	else if(iTotal == 2)//����HALF D1�����
	{
// ���� ע��
//		if (DVR_SUB_ATM_KL_6214 == m_DeviceSubType)
//		{
//			int ImageWidth = width*2*2;
//			int ImageHeight = height;
//			int rgbWidth = width*2;
//			int rgbHeight = height;
//			if (ch == 0)
//			{
//				for(i=0; i<rgbHeight;i++)
//				{
//					memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
//				}
//			}
//			else if(ch == 1)
//			{
//				for(i=0; i<rgbHeight;i++)
//				{
//					memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth+rgbWidth, rgbWidth);
//				}
//			}
//		}
//		else
		{
			int ImageWidth = width*2;
			int ImageHeight = height;
			int rgbWidth = width*2;
			int rgbHeight = height;
			if (ch == 0)
			{
				for(i=0; i<rgbHeight;i++)
				{
					memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
				}
			}
			else if(ch == 1)
			{
				j = ImageHeight;
				for(i=0; i<rgbHeight;i++)
				{
					memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
					j++;
				}
			}
		}

//		int ImageWidth = width*2;
//		int ImageHeight = height*2;
//		int rgbWidth = width*2;
//		int rgbHeight = height;
//
//		if(ch == 0)
//		{
//			
//			for(i=0; i<rgbHeight;i++)
//			{
//				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
//			}
//		}
//		else
//		{
//			j = ImageHeight/2;
//			for(i=0; i<rgbHeight;i++)
//			{
//				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
//				j++;
//			}
//		}
	}
	else if(iTotal > 2)
	{
		//int ImageWidth = width*2*2;
		int ImageWidth = width*2*2;
		int ImageHeight = height;
		int rgbWidth = width*2;
		int rgbHeight = height;
		if(ch == 0)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
			}
		}
		else if(ch == 1)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth+rgbWidth, rgbWidth);
			}
		}
		else if(ch == 2)
		{
			//j = ImageHeight/2;
			j = ImageHeight;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
				j++;
			}

		}
		else if(ch == 3)
		{
			//j = ImageHeight/2;
			j = ImageHeight;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth+rgbWidth, rgbWidth);
				j++;
			}
		}
	}


	ConverSurfaceRect( &m_ConverRect);
	
	//��ʾOSD
	//ZJX/201019/ע������
	//ShowOSD((BYTE*)m_pszRGB, temp_width);
	
	//ZJX/20101019/˫��֧��
	struct 	{
		BITMAPINFOHEADER bmiHeader; 
		RGBQUAD          bmiColors[3]; 
	} bi = {
		{sizeof (BITMAPINFOHEADER), temp_width, -temp_height, 1, 16, BI_BITFIELDS, temp_width * temp_height * 2, 0, 0, 3, 0},
		{
			{0x00, 0xf8, 0x00, 0x00},
			{0xe0, 0x07, 0x00, 0x00},
			{0x1f, 0x00, 0x00, 0x00}
		}
	};
	StretchDIBits(
		 hdc,
		 dest.left,
		 dest.top,
		 dest.right - dest.left,
		 dest.bottom - dest.top,
		 0,
		 0,
		 temp_width,
		 temp_height,
		 //m_pszRGB,
		 Videdata,
		 //(BITMAPINFO*)&bmp_head,
		 (BITMAPINFO*)&bi,
		 DIB_RGB_COLORS,
		 SRCCOPY
		);

	if (m_bRecordFlag)
	{
		::SetTextColor(hdc, RGB(255, 255, 255));
		::SetBkColor(hdc, RGB(255, 0, 0));		
		TextOut(hdc, dest.left + 4, dest.top + 1, " R ", strlen(" R "));
	}
	
	SetMapMode(hdc, MapModeOld);
	ReleaseDC(m_hShowWnd, hdc);
}

void CDDrawDisplay::SaveRGB16Data(char *Videdata, UCHAR *ImageBuf, int width, int height, int iTotal, int ch)
{
	int pox1 = 0;
	int poy1 = 0;
	int temp_width = width;
	int temp_height = height;

	int j = 0;
	int i = 0;
	
	if(iTotal < 2)
	{
		int ImageWidth = width*2;
		int ImageHeight = height;
		int rgbWidth = width*2;
		int rgbHeight = height;
		for(i=0; i<rgbHeight;i++)
		{
			memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
		}
	}
	else if(iTotal == 2)//����HALF D1�����
	{
// ���� ע��
//		if (DVR_SUB_ATM_KL_6214 == m_DeviceSubType)
//		{
//			int ImageWidth = width*2*2;
//			int ImageHeight = height;
//			int rgbWidth = width*2;
//			int rgbHeight = height;
//			if (ch == 0)
//			{
//				for(i=0; i<rgbHeight;i++)
//				{
//					memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
//				}
//			}
//			else if(ch == 1)
//			{
//				for(i=0; i<rgbHeight;i++)
//				{
//					memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth+rgbWidth, rgbWidth);
//				}
//			}
//		}
//		else
		{
			int ImageWidth = width*2;
			int ImageHeight = height;
			int rgbWidth = width*2;
			int rgbHeight = height;
			if (ch == 0)
			{
				for(i=0; i<rgbHeight;i++)
				{
					memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
				}
			}
			else if(ch == 1)
			{
				j = ImageHeight;
				for(i=0; i<rgbHeight;i++)
				{
					memcpy(ImageBuf+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
					j++;
				}
			}
		}
//		int ImageWidth = width*2;
//		int ImageHeight = height*2;
//		int rgbWidth = width*2;
//		int rgbHeight = height;
//
//		if(ch == 0)
//		{
//			
//			for(i=0; i<rgbHeight;i++)
//			{
//				memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
//			}
//		}
//		else
//		{
//			j = ImageHeight/2;
//			for(i=0; i<rgbHeight;i++)
//			{
//				memcpy(ImageBuf+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
//				j++;
//			}
//		}
	}
	else if(iTotal > 2)
	{
		//int ImageWidth = width*2*2;
		int ImageWidth = width*2*2;
		int ImageHeight = height;
		int rgbWidth = width*2;
		int rgbHeight = height;
		if(ch == 0)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
			}
		}
		else if(ch == 1)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(ImageBuf+i*rgbWidth, Videdata+i*ImageWidth+rgbWidth, rgbWidth);
			}
		}
		else if(ch == 2)
		{
			//j = ImageHeight/2;
			j = ImageHeight;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(ImageBuf+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
				j++;
			}

		}
		else if(ch == 3)
		{
			//j = ImageHeight/2;
			j = ImageHeight;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(ImageBuf+i*rgbWidth, Videdata+j*ImageWidth+rgbWidth, rgbWidth);
				j++;
			}
		}
	}

	ConverSurfaceRect( &m_ConverRect);
}

void CDDrawDisplay::PlayRGB16(char *Videdata, int width, int height, RECT dest, int ch)
{
	HDC hdc = GetDC(m_hShowWnd);
	int MapModeOld = SetMapMode(hdc, MM_TEXT);
	SetStretchBltMode(hdc, COLORONCOLOR);

	int pox1 = 0;
	int poy1 = 0;
	int temp_width = width;
	int temp_height = height;

	int j = 0;
	int i = 0;
	
	if(m_bDisplayMode < 2)
	{
		int ImageWidth = width*2;
		int ImageHeight = height;
		int rgbWidth = width*2;
		int rgbHeight = height;
		for(i=0; i<rgbHeight;i++)
		{
			memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
		}
	}
	else if(m_bDisplayMode == 2)//����HALF D1�����
	{
		int ImageWidth = width*2;
		int ImageHeight = height*2;
		int rgbWidth = width*2;
		int rgbHeight = height;

		if(m_bpos == 0)
		{
			
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
			}
		}
		else
		{
			j = ImageHeight/2;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
				j++;
			}
		}
	}
	else if(m_bDisplayMode > 2)
	{
		int ImageWidth = width*2*2;
		int ImageHeight = height*2;
		int rgbWidth = width*2;
		int rgbHeight = height;
		if(m_bpos == 0)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth, rgbWidth);
			}
		}
		else if(m_bpos == 1)
		{
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+i*ImageWidth+rgbWidth, rgbWidth);
			}

		}
		else if(m_bpos == 2)
		{
			j = ImageHeight/2;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth, rgbWidth);
				j++;
			}

		}
		else if(m_bpos == 3)
		{
			j = ImageHeight/2;
			for(i=0; i<rgbHeight;i++)
			{
				memcpy(m_pszRGB+i*rgbWidth, Videdata+j*ImageWidth+rgbWidth, rgbWidth);
				j++;
			}
		}
	}


	ConverSurfaceRect( &m_ConverRect);
	
	//��ʾOSD
	ShowOSD((BYTE*)m_pszRGB, temp_width);
	
	StretchDIBits(
		 hdc,
		 dest.left,
		 dest.top,
		 dest.right - dest.left,
		 dest.bottom - dest.top,
		 0,
		 0,
		 temp_width,
		 temp_height,
		 m_pszRGB,
		 (BITMAPINFO*)&bmp_head,
		 DIB_RGB_COLORS,
		 SRCCOPY
		);

	
	SetMapMode(hdc, MapModeOld);
	ReleaseDC(m_hShowWnd, hdc);
}

void CDDrawDisplay::DDrawSurfaceClear(LPDIRECTDRAWSURFACE7 ClearSurface)
{
	if(ClearSurface)
	{
		DDBLTFX ddbltfx;
		ZeroMemory( &ddbltfx, sizeof(ddbltfx) );
		ddbltfx.dwSize      = sizeof(ddbltfx);
		ddbltfx.dwFillColor = 0;
		ClearSurface->Blt( NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx );
	}
}


void CDDrawDisplay::ConverSurfaceRect(RECT *ConverRect)
{
	if(ConverRect->left == ConverRect->right)
		return;
	
	if(m_ddcap == MYCAP_BLT)
	{ 
		if( m_pszRGB )
		{
			int startx1 = ConverRect->left;
			int startx = ConverRect->right - startx1;

			int starty1 = ConverRect->top;
			int starty2 = ConverRect->bottom;

			for(int i=starty1; i<starty2; i++)
			{
				memset(m_pszRGB+dd_width*2*i+startx1*2,255,startx*2);
			}
		}
	}
	else if(m_pDDSMy)
	{
		DDBLTFX ddbltfx;
		ZeroMemory( &ddbltfx, sizeof(ddbltfx) );
		ddbltfx.dwSize      = sizeof(ddbltfx);
		ddbltfx.dwFillColor = 0xf080;
		HRESULT hr = m_pDDSMy->Blt( ConverRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx );
		if ( hr == DD_OK )
			int i = 1;
		else
		{
			int j = 3;
			switch ( hr )
			{
			case DDERR_GENERIC  :
				j = 1;
				break;
			}
		}
	}
}


BOOL  CDDrawDisplay::RestoreAllDDrawSurfaces( )
{
	if(m_pDD)
	{
		m_pDD->RestoreAllSurfaces();
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}



void CDDrawDisplay::PlayYuv420(unsigned char *lum, unsigned char *cb, unsigned char *cr, int width, int height, RECT show_pos)
{
	DDSURFACEDESC2 ddsd;
	HRESULT ddrval;
	INIT_DIRECTDRAW_STRUCT(ddsd);

	ddrval = m_pDDSMy->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);

	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();  
		return;
	}

	int i, j = 0;
	unsigned char* y = (unsigned char*)ddsd.lpSurface;
	if(!y)
		return;

	int pitch = ddsd.lPitch - (width << 1);
	int halfwidth = width >> 1;

	width -= 1;
	
	if(m_mmxcap == CPU_SSE2 && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	//if(m_mmxcap == CPU_SSE2)// && ((width & 0xf) == 0) && ((height & 0xf) == 0))
	{
		__asm
		{
		mov esi, [lum];
		mov edi, [y];
		mov eax, [cr];
		mov ebx, [cb];

yuy2_row:
		xor ecx, ecx;
		mov edx, edi;
		add edx, ddsd.lPitch;

yuy2_col:

		movups xmm0, [eax];	// 0 : cr
		movups xmm1, [ebx];	// 1 : cb

		// cr0 cb0 cr1 cb1 cr2 cb2 cr3 cb3
		movaps xmm2, xmm1;
		punpcklbw xmm2, xmm0; // 2 : cr0 cb0 cr1 cb1 cr2 cb2 cr3 cb3
		punpckhbw xmm1, xmm0; // 1 : cr4 cb4 cr5 cb5 cr6 cb6 cr7 cb7

		// lum1
		movups xmm3, [esi];	// 3 : lum1
		movaps xmm4, xmm3;
		punpcklbw xmm4, xmm2;	// 4 : lum0 cr0 lum1 cb0 lum2 cr1 lum3 cb1 
		movups [edi], xmm4;

		punpckhbw xmm3, xmm2;	// 4 : lum5 cr2 lum6 cb2 lum7 cr3 lum8 cb3 
		movups [edi+16], xmm3;

		movups xmm3, [esi+16];	// 3 : lum1+16
		movaps xmm4, xmm3;
		punpcklbw xmm4, xmm1;	// 4 : lum0 cr4 lum1 cb4 lum2 cr5 lum3 cb5 
		movups [edi+32], xmm4;

		punpckhbw xmm3, xmm1;	// 4 : lum5 cr6 lum6 cb6 lum7 cr7 lum8 cb7 
		movups [edi+48], xmm3;

		// lum2
		add esi, width;
		movups xmm3, [esi];		// 3 : lum2
		movaps xmm4, xmm3;
		punpcklbw xmm4, xmm2;	// 4 : lum0 cr0 lum1 cb0 lum2 cr1 lum3 cb1 
		movups [edx], xmm4;

		punpckhbw xmm3, xmm2;	// 4 : lum5 cr2 lum6 cb2 lum7 cr3 lum8 cb3 
		movups [edx+16], xmm3;

		movups xmm3, [esi+16];	// 3 : lum1+16
		movaps xmm4, xmm3;
		punpcklbw xmm4, xmm1;	// 4 : lum0 cr4 lum1 cb4 lum2 cr5 lum3 cb5 
		movups [edx+32], xmm4;

		punpckhbw xmm3, xmm1;	// 1 : lum5 cr6 lum6 cb6 lum7 cr7 lum8 cb7 
		movups [edx+48], xmm3;
		sub esi, width;

		add eax, 16;
		add ebx, 16;
		add esi, 32;
		add edi, 64;
		add edx, 64;

		add ecx, 32;
		cmp ecx, width;
		jne yuy2_col;

		add esi, width;
		add edi, pitch;
		add edi, ddsd.lPitch;

		mov ecx, j;
		add ecx, 2;
		mov j, ecx;
		cmp ecx, height;
		jne yuy2_row;
		}
	}
	else
	{
		for(j = 0; j<height; j+=2)
		{
			for(i=0; i<width; i+= 4)
			{
				*y++ = *lum++;
				*y++ = (*cb++);
				*y++ = *lum++;
				*y++ = (*cr++);
				*y++ = *lum++;
				*y++ = (*cb++);
				*y++ = *lum++;
				*y++ = (*cr++);
			}
			y += pitch;

			cb -= halfwidth;
			cr -= halfwidth;

			for(i=0; i<width; i+= 4)
			{
				*y++ = *lum++;
				*y++ = (*cb++);
				*y++ = *lum++;
				*y++ = (*cr++);
				*y++ = *lum++;
				*y++ = (*cb++);
				*y++ = *lum++;
				*y++ = (*cr++);
			}
			y += pitch;
		}
	}

	m_pDDSMy->Unlock(NULL);


	RECT display;
	SetRect(&show_pos,show_pos.left+2, show_pos.top+2, show_pos.right-2, show_pos.bottom-2);

	if(m_bDisplayMode < 2)
	{
		SetRect(&display,0,0,dd_width - 16,dd_height-2);
	}
	else
	{
		if(m_bDisplayMode == 2)//����HALF D1�����
		{
			if(m_bpos == 0)
			{
				SetRect(&display,0,0,dd_width ,dd_height/2);  
			}
			else 
			{
				SetRect(&display,0,dd_height/2,dd_width,dd_height); 
			}
		}
		else
		{
			if(m_bpos == 0)
			{
				SetRect(&display,0,0,dd_width/2 ,dd_height/2);  
			}
			else if(m_bpos == 1)
			{
				SetRect(&display,dd_width/2,0,dd_width,dd_height/2); 
			}
			else if(m_bpos == 2)
			{
				SetRect(&display,0,dd_height/2,dd_width/2,dd_height); 
			}
			else if(m_bpos == 3)
			{
				SetRect(&display,dd_width/2,dd_height/2,dd_width,dd_height); 
			}
		}
	}

	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();  
	}

	ConverSurfaceRect( &m_ConverRect);

	//HDC hDc;
	//m_pDDSMy->GetDC( &hDc );
	//TextOut( hDc, 0, 0, "abc", 3 );
	ddrval = m_pDDSPrimary->Blt(&show_pos, m_pDDSMy, &display, DDBLT_WAIT, NULL);
}



void CDDrawDisplay::QuadTwoSurface(char *VideoData, int Starty)
{
	DDSURFACEDESC2 desc;
	int width; 
	int height; 
	int LineByteCount;
	BYTE *src; 

	width = dd_width>>1;
	height = dd_height>>1;
	src = (BYTE *)VideoData;  
	LineByteCount = dd_width<<1;
	//int HalfLineByteCount = dd_width;

	if(m_pDDSMy == NULL)
		return;

	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);

	HRESULT ddrval = m_pDDSMy->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY | DDLOCK_WAIT, NULL );
	//m_pDDSMy->GetClipper(
	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();
		return;
	}
	
	BYTE *dst = (BYTE*)desc.lpSurface;

	if(Starty == 0)
	{
		for(int i=0; i<height; i++)
		{
			memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, src+LineByteCount*i, LineByteCount);  
		}
	}
	else
	{
		for(int i=height; i<height*2; i++)
		{
			memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, src+LineByteCount*i, LineByteCount);  
		}
	}
	m_pDDSMy->Unlock(NULL);
}


void CDDrawDisplay::QuadOneSurface(char *VideoData)
{
	DDSURFACEDESC2 desc;
	int width; 
	int height; 
	int LineByteCount;
	BYTE *src; 

	width = dd_width;
	height = dd_height;
	src = (BYTE *)VideoData;  
	LineByteCount = dd_width<<1;
	
	if(m_pDDSMy == NULL)
		return;

	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);
	//m_pDDSMy
	
	HRESULT ddrval = m_pDDSMy->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY | DDLOCK_WAIT, NULL );
	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();
		return;
	}
	
	BYTE *dst = (BYTE*)desc.lpSurface;

	for(int i=0; i<height; i++)
	{
		memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, src+LineByteCount*i, LineByteCount);  
	}
	
	m_pDDSMy->Unlock(NULL);
}



void CDDrawDisplay::DrawVideoIamge(char *Videodata, int Total_ch, int ch)
{
	if(!m_hShowWnd || m_cVideoCardType == 0)
		return;

	if(m_ddcap == MYCAP_BLTYUV)
	{
	
		PlayUYVYFrame(Videodata, Total_ch,  ch);
	}
	else
	{
		RECT show_pos;

//		if(!m_hShowWnd)
//			return;

		int				width = dd_width;
		int				height  = dd_height;

		GetClientRect(m_hShowWnd, &show_pos);

		//Old
		//PlayRGB16((char *)Videodata, width, height, show_pos, ch);
		//end
		++ show_pos.left;
		++ show_pos.top;
		-- show_pos.right;
		-- show_pos.bottom;
		PlayRGB16Ex((char *)Videodata, width, height, show_pos, Total_ch, ch);
	}
}




void CDDrawDisplay::PlayUYVYFrame(char *Videodata, int toltal_ch, int ch)
{
	if ( m_cVideoCardType == 1 )
	{
#ifdef PLAY_WITHD3D
		// ����Direct3D����������ԣ��Ͱ�������ɾ���������ڱ����� ������ע����ͬ�����ݣ�һ��������by Ligo, 2008.6.27
		PlayUYVYFrame2( Videodata, toltal_ch, ch );
#endif		// PLAY_WITHD3D
		return;
	}

	DDSURFACEDESC2 desc;
	int Bpp = 2;
	int width = 0;//Bpp*dd_width;
	int chwidth = 0;//(Bpp*dd_width);
	RECT show_pos;
	
	if(!m_pDDSMy || !m_hShowWnd)
		return;
	
	//old 
	//if(toltal_ch >= 3)
	//end
	
	if(toltal_ch >= 3)
	{
		width = Bpp*dd_width;
		chwidth = (Bpp*dd_width)*2;	
	}
	else
	{
		//modify by yfli 2006-08-21
		//reason:���·ָ������ҷָ�
		//new
//		if(DVR_SUB_ATM_KL_6214 == m_DeviceSubType && toltal_ch == 2)
//		{
//			width = Bpp*dd_width;
//			chwidth = (Bpp*dd_width)*2;	
//		}
//		else
		{
			width = Bpp*dd_width;
			chwidth = (Bpp*dd_width);
		}
			//end
		//old
		//width = Bpp*dd_width;
		//chwidth = (Bpp*dd_width);	
		//end
	}

	GetClientRect(m_hShowWnd, &show_pos);
	ClientToScreen(m_hShowWnd, (LPPOINT)&show_pos);
	ClientToScreen(m_hShowWnd, (LPPOINT)&show_pos.right);
	SetRect(&show_pos,show_pos.left+2, show_pos.top+2, show_pos.right-2, show_pos.bottom-2);

	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);

	// Complete the surface description
//	DDSURFACEDESC2 ddsd;
//	ddsd.dwSize = sizeof(ddsd);
//	ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
//	HRESULT hr = m_pDDSMy->GetSurfaceDesc(&ddsd);
//	if(SUCCEEDED(hr))
//	{
//		HDC hdc = NULL;
//		hr = m_pDDSMy->GetDC(&hdc);
//		if(SUCCEEDED(hr))
//		{
//			m_pDDSMy->ReleaseDC(hdc);
//		}
//	}
//	HRESULT hr;
//	if (FAILED(hr= m_pDDSMy->CreateSurfaceFromText(&g_pTextSurface,
//		NULL, "Hello DirectX 8 !", RGB(0,0,0), RGB(255,255,0))))
//	{
//
//	}

	//test

	HRESULT ddrval = m_pDDSMy->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY | DDLOCK_WAIT, NULL );
	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();
		return;
	}

	int i = 0;
	int j = 0;

	if(toltal_ch >=3 )
	{
		switch(ch)
		{
		case 0:
			for(i=0; i<(int)desc.dwHeight; i++)
			{
				memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i,width);
			}
			break;

		case 1:
			for(i=0; i<(int)desc.dwHeight; i++)
			{
				memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i+width,width);
			}
			break;
		case 2:
			j = desc.dwHeight;
			for(i=0; i<(int)desc.dwHeight; i++)
			{
				memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*j,width);
				j++;
			}
			break;
		case 3:
			j = desc.dwHeight;
			for(i=0; i<(int)desc.dwHeight; i++)
			{
				memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*j+width,width);
				j++;
			}
			break;
		}
	}
	else
	{
		//modify by yfli 2006-08-21
		//reason:�������·ָ����ҷָ�
		//new	
// ���� ע��
//		if(DVR_SUB_ATM_KL_6214 == m_DeviceSubType)
//		{
//			switch(ch)
//			{
//			case 0:
//				for(i=0; i<(int)desc.dwHeight; i++)
//				{
//					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i,width);
//				}
//				break;
//				
//			case 1:
//				for(i=0; i<(int)desc.dwHeight; i++)
//				{
//					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i+width,width);
//				}
//				break;
//			}
//		}
//		else
		{
			switch(ch)
			{
			case 0:
				for(i=0; i<(int)desc.dwHeight; i++)
				{
					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i,width);
				}

				if ( 0 )
				{
					static long stl;
					char szf[] = "F:/directx_picture/yuv_2008.yuv";
					sprintf( szf, "F:/directx_picture/yuv_%d_%04d.yuv", ch, stl++ );
					FILE *pf = fopen( szf, "w+b" );
					if ( pf )
					{
						fwrite( Videodata, 1, width * desc.dwHeight, pf );
						fclose( pf );
						pf = NULL;
					}
				}
				break;
				
			case 1:
				j = desc.dwHeight;
				for(i=0; i<(int)desc.dwHeight; i++)
				{
					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*j,width);
					j++;
				}
				break;
			}
		}
		//end
//		old
//		switch(ch)
//		{
//			case 0:
//				for(i=0; i<(int)desc.dwHeight; i++)
//				{
//					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*i,width);
//				}
//				break;
//
//			case 1:
//				j = desc.dwHeight;
//				for(i=0; i<(int)desc.dwHeight; i++)
//				{
//					memcpy((BYTE*)desc.lpSurface + i*desc.lPitch, Videodata+chwidth*j,width);
//					j++;
//				}
//				break;
//		}
//		end
	}

	m_pDDSMy->Unlock(NULL);

	if (m_bRecordFlag)
	{
		// 20090724 xh ����¼����
		HDC hdc;
		if (m_lpDDSRecordFlag->GetDC(&hdc) == DD_OK)
		{
			SetBkColor(hdc, RGB(255, 0, 0)); 
			SetTextColor(hdc, RGB(255, 255, 255)); 
			TextOut(hdc, 0, 0, " R ", lstrlen(" R ")); 
			m_lpDDSRecordFlag->ReleaseDC(hdc);
		}
	}

	//���ȵĵ���
	if ( m_lBrightness_cp != 0 )
	{
		EffectBrightness( (BYTE*)desc.lpSurface, desc.lPitch, desc.dwHeight );
	}


// 	if (m_DevcieType != DVR_ATM_REALTIME_TYPE)
// 	{
		ConverSurfaceRect(&m_ConverRect);
// 	}
	//ShowOSD
	{
		ShowOSD((BYTE*)desc.lpSurface, desc.lPitch);
//		EnterOsdCS();
//		if(m_bShowOsd && m_iOsdLen)	//��ʾOSD����Ϣ
//		{
//			int xPos = 0;
//			int yPos = 0;	
//			GetPos(dd_width, dd_height, xPos, yPos);	
//			WriteOsd((BYTE*)desc.lpSurface, desc.lPitch, xPos, yPos, m_OsdInfo, m_iOsdLen, m_iBrightness);
//		}
//		LeaveOsdCS();
	}




	BOOL bBlank = FALSE;
	int iErr = m_pDD->GetVerticalBlankStatus( &bBlank );
	if ( iErr  == 0)
	{
		if ( !bBlank )
		{
			m_pDD->WaitForVerticalBlank( DDWAITVB_BLOCKBEGINEVENT , NULL);
		}
	}
	else
	{
		m_pDD->WaitForVerticalBlank( DDWAITVB_BLOCKBEGINEVENT , NULL);
	}


	ddrval = m_pDDSPrimary->Blt(&show_pos, m_pDDSMy, NULL, DDBLT_WAIT, NULL);


	if (m_bRecordFlag)
	{
		// 20090724 xh ����¼����
		RECT rc;
		rc.left = show_pos.left + 4;
		rc.top = show_pos.top + 1;
		rc.bottom = rc.top + 17;
		rc.right = rc.left + 17;

		m_pDDSPrimary->Blt(&rc, m_lpDDSRecordFlag, NULL, DDBLT_WAIT, NULL);
	}
	//ddrval = m_pDDSPrimary->BltFast( show_pos.left, show_pos.top, m_pDDSMy, NULL, DDBLTFAST_NOCOLORKEY | DDBLTFAST_WAIT );

	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();
	}
	
	return;
}


/*
void CDDrawDisplay::PlayUYVYFrame(char *VideoData, RECT show_pos)// ��ʾͼ��
{
	RECT display;
	HRESULT ddrval;

	SetRect(&show_pos,show_pos.left+2, show_pos.top+2, show_pos.right-2, show_pos.bottom-2);

	if(m_bDisplayMode < 2)
	{
		QuadOneSurface(VideoData);
		SetRect(&display,0,0,dd_width - 16,dd_height-2);
	}
	else
	{
		if(m_bDisplayMode == 2)//����HALF D1�����
		{
			if(m_bpos == 0)
			{
				QuadTwoSurface(VideoData, 0);
				SetRect(&display,0,0,dd_width ,dd_height/2);  
			}
			else 
			{
				QuadTwoSurface(VideoData, dd_height/2);
				SetRect(&display,0,dd_height/2,dd_width,dd_height); 
			}
		}
		else
		{
			int Startx, Starty,Endx,Endy;
			if(m_bpos == 0)
			{
				Startx = 0;
				Starty = 0;
				Endx = dd_width/2;
				Endy = dd_height/2;
				SetRect(&display,0,0,dd_width/2 ,dd_height/2);  
			}
			else if(m_bpos == 1)
			{
				Startx = dd_width/2;
				Starty = 0;
				Endx = dd_width;
				Endy = dd_height/2;
				SetRect(&display,dd_width/2,0,dd_width,dd_height/2); 
			}
			else if(m_bpos == 2)
			{
				Startx = 0;
				Starty = dd_height/2;;
				Endx = dd_width/2;
				Endy = dd_height;
				SetRect(&display,0,dd_height/2,dd_width/2,dd_height); 
			}
			else if(m_bpos == 3)
			{
				Startx = dd_width/2;;
				Starty = dd_height/2;;
				Endx = dd_width;
				Endy = dd_height;
				SetRect(&display,dd_width/2,dd_height/2,dd_width,dd_height); 
			}
			QuadFourSurface(VideoData, Startx, Starty,Endx, Endy);
		}
	}


	ddrval = m_pDDSPrimary->Blt(&show_pos, m_pDDSMy, &display, DDBLT_WAIT, NULL);

	if(ddrval == DDERR_SURFACELOST)
	{
		m_pDD->RestoreAllSurfaces();  
	}
}
*/


BOOL CDDrawDisplay::SaveImageToBuffer(char* VideoData, UCHAR *ImageBuf, int *Width, int *Height)
{
	//ADD BY YFLI 2006-09-28
	if(!m_lpBackBuffer)
	{
		return FALSE;
	}

	int m_nWidth = dd_width;
	int m_nHeight = dd_height;

	DDSURFACEDESC2 desc;
	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);

	float Bit5_to_bit8 = 255/31;
	float Bit6_to_bit8 = 255/63;
	WORD * tmp;
	
	int nBpp;



	int width; 
	int height; 
	int LineByteCount;

	width = dd_width;
	height = dd_height;
	
	LineByteCount = dd_width<<1;
	
	if(m_pDDSMy == NULL)
		return FALSE;

	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);
	
	m_lpBackBuffer->Blt(NULL, m_pDDSMy, NULL ,DDBLT_ASYNC | DDBLT_WAIT , NULL);

	ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
	desc.dwSize     = sizeof(DDSURFACEDESC2);
	
	if( FAILED(m_lpBackBuffer->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY | DDLOCK_WAIT, NULL )))
	return FALSE;

	nBpp = desc.ddpfPixelFormat.dwRGBBitCount/8;

	int imagelenth = m_nWidth*m_nHeight*nBpp;
	int imagelenth2 = m_nWidth*m_nHeight*3;

	UCHAR *tempbuff = new UCHAR[imagelenth];
	UCHAR *tempbuff2 = new UCHAR[imagelenth2];
	UCHAR *deletebuffer = tempbuff;
	UCHAR *deletebuffer2 = tempbuff2;


	if((tempbuff == NULL) || (tempbuff2 == NULL))
	{
		m_lpBackBuffer->Unlock(NULL);
		return FALSE;
	}
	
	tmp = (WORD*)tempbuff;

	 width = nBpp*m_nWidth;
	int j = 0;
	for( int i=0 ; i < (int)desc.dwHeight-1; i++)
	{
		memcpy(tempbuff+width*j,(BYTE*)desc.lpSurface + i*desc.lPitch,width);
		j++;
	}

	m_lpBackBuffer->Unlock(NULL);

	if(nBpp==2)
	{
		for(int i=0; i<m_nWidth*m_nHeight*3;)
		{
			tempbuff2[i++] = BYTE((*tmp)&0x001f)*Bit5_to_bit8;
			tempbuff2[i++] = BYTE(((*tmp)&0x07e0)>>5)*Bit6_to_bit8;
			tempbuff2[i++] = BYTE(((*tmp)&0xf800)>>11)*Bit5_to_bit8;
			tmp++;
		}
	}

	if(nBpp == 4)
	{
		for(int i=0; i<m_nWidth*m_nHeight*3;)
		{
			tempbuff2[i++] =*tempbuff++;
			tempbuff2[i++] =*tempbuff++;
			tempbuff2[i++] =*tempbuff++;
			tempbuff++;
		}
	}

	memcpy(ImageBuf,tempbuff2,imagelenth2);

	delete []deletebuffer;
	delete []deletebuffer2;
	
	*Width = m_nWidth;
	*Height = m_nHeight;

	return TRUE;
}

BOOL CDDrawDisplay::CreatInfoSurface( LPDIRECTDRAWSURFACE7 &lpddsBuffer )
{
	DDSURFACEDESC2 ddsd;
	
	ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize     = sizeof(ddsd);
	ddsd.dwFlags        = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH ;
	ddsd.ddsCaps.dwCaps = DDSCAPS_VIDEOMEMORY |DDSCAPS_OFFSCREENPLAIN  ;
	ddsd.dwWidth  = dd_width;
	ddsd.dwHeight = dd_height;
	
	if(m_pDD != NULL)
	{
		if(FAILED(m_pDD->CreateSurface(&ddsd, &lpddsBuffer, NULL)))
		{
			return FALSE;
		}

		DDrawSurfaceClear(lpddsBuffer);

		return TRUE;
	}
	else
		return FALSE;
}

void CDDrawDisplay::SetConverRect(int posx1,int posx2,int posy1,int posy2)
{
	// 6304��6308��x��y��������ſ��ܲ�ͬ
	int scalx, scaly;


	if(dd_width>400)
	{
		scalx = scaly = 24;
	}
	else
	{
		scalx = scaly = 12;
	}


	SetRect(&m_ConverRect,posx1*scalx, posy1*scaly, posx2*scalx, posy2*scaly);

	if ( dd_height < 10 || dd_width < 10 )
		return;

	// 2006.6.14
	// ��������磬�Ͱѳ����Ĳ�������Ϊ������ļ�1
	if ( m_ConverRect.top >= dd_height )
	{
		m_ConverRect.top = dd_height - 1;
		m_ConverRect.bottom = dd_height - 1;
	}
	else
	{
		if ( m_ConverRect.bottom >= dd_height )
			m_ConverRect.bottom = dd_height - 1;
	}
	if ( m_ConverRect.left >= dd_width )
	{
		m_ConverRect.left = dd_width - 1;
		m_ConverRect.right = dd_width - 1;
	}
	else
	{
		if ( m_ConverRect.right >= dd_width )
			m_ConverRect.right = dd_width - 1;
	}
}



//����Ҫע��������ڹ�����������Ŀ��Ļ��ʾ������
//#define  STL_NEED_AUTOCOLOR
//#define  STL_NEED_RMS_TR
//#define  STL_NEED_RMPLAYER_BUS

//���ڻ������ĵ���ͼ������Ƶ֡������
void CDDrawDisplay::WriteOsd(BYTE *Image, int ImageWidth, int xpos,int ypos, 
							 tag_OSDFrontLattice *OsdLattice,int OSDLenth,int osdcolor)
{
	tag_OSDFrontLattice *Temp = OsdLattice;
	char Row = 0;
	WORD Row2 = 0;

	char frontTemp[16];
	char frontTemp2[32];

	WORD YUV422_wite = 0xf080;
	WORD YUV422_black = 0x1080;
	WORD FrontColor;
	WORD *Value;

	//int xCoord = xpos + 10;			// TR�ı��豸ͨ��������ʾ��λ��    caojun 070831
	//int yCoord = ypos + 18;			// tr�ı��豸ͨ��������ʾ��λ��	
	int xCoord = xpos;			// ���ڹ����ı��豸ͨ��������ʾ��λ��    caojun 070831
	int yCoord = ypos + 5;			// ���ڹ����ı��豸ͨ��������ʾ��λ��    caojun 070831
	int newposx = xpos;
	int newposy = ypos;

	// Ϊ�˲��õ�ɫ���ּ���ĺ������Ѽ�����ܰ�ImageWith*2��ΪImageWith
	int width = ImageWidth;

	int ii,kk,jj;

	if(OSDLenth>0)
	{
		for(int i=0;i<OSDLenth;i++)
		{
			if(Temp[i].FrontType == 0)
			{
				// Ӣ���ַ�
				memcpy(frontTemp,Temp[i].OsdLattice,16);

				//GetOsdColor( &FrontColor, Image, yCoord, xCoord, width, &Temp[i].OSDColor, LT_ENGLISH );
				#ifdef STL_TMSDK_VAR
				FrontColor = osdcolor;
				#else
				Value = (WORD *)(Image + ((yCoord+8)*width+(xCoord+4)*2));

				FrontColor = Temp[i].OSDColor;
//				if(*Value>0xc080)
				if(*Value>0x8080)
				//if(0x4880>*Value>0xB880)
				{
					if(Temp[i].OSDColor == 0)
					{
						FrontColor = YUV422_black;
						Temp[i].OSDColor = YUV422_black;
					}
					else
					{
						if(Temp[i].OSDColor == YUV422_wite)
						{
//							if(*Value>0xd080)
							if(*Value>0xa080)
							{
								FrontColor = YUV422_black;
								Temp[i].OSDColor = YUV422_black;
							}
						}
					}	
				}
				else
				{
					if(Temp[i].OSDColor == 0)
					{
						FrontColor = YUV422_wite;
						Temp[i].OSDColor = YUV422_wite;
					}
					else
					{
						if(Temp[i].OSDColor == YUV422_black)
						{
//							if(*Value<0xb080)
							if(*Value<0x6080)
							{
								FrontColor = YUV422_wite;
								Temp[i].OSDColor = YUV422_wite;
							}
						}
					}
				}
				#endif
				//*/

				#ifdef STL_NEED_AUTOCOLOR		//�Ƿ���Ҫ��ɫ��Ч��  caojun
				for( ii=0;ii<16;ii++)
				{
					 for( kk=0;kk<8;kk++)
					  if(((frontTemp[ii]>>(7-kk))&0x1)!=NULL)
					  {
						 *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = FrontColor;
					  }
				}
				#else 
				// �������ǲ����Զ��ķ�ɫ��������ΪЧ�����Ǻܺã�����ֱ���úڵװ���
				for( ii=0;ii<16;ii++)
				{
					 for( kk=0;kk<8;kk++)
					 {
						  if(((frontTemp[ii]>>(7-kk))&0x1)!=NULL)
						  {
							  // 1. STL_NEED_RMPLAYER_BUS
							  // ����(yCoord+ii)��ԭ�д��룬��Ҫ����������������(yCoord+ii*2)
							  //��Ҫ�������彫(xCoord+kk)��Ϊ(xCoord+kk*2)����2Ϊ���ڳ̶�,ע��Ҫ����ʱ����ҪxCoord += 16;
							 //*(WORD *)(Image + ((yCoord+ii*2)*width+(xCoord+kk*2)*2)) = FrontColor;
							 //*(WORD *)(Image + ((yCoord+ii*2+1)*width+(xCoord+kk*2)*2)) = FrontColor;
							 //*(WORD *)(Image + ((yCoord+ii*2)*width+(xCoord+kk*2)*2+2)) = FrontColor;
							 //*(WORD *)(Image + ((yCoord+ii*2+1)*width+(xCoord+kk*2)*2+2)) = FrontColor;
							  // 2. STL_NEED_RMS_TR
							 *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = YUV422_wite;
							 *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2+2)) = YUV422_wite;
							 *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2+4)) = YUV422_wite;
							 
						  }
						  else
						  {
							  // 2. STL_NEED_RMS_TR
							  *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = YUV422_black;
							  *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2+2)) = YUV422_black;
							  *(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2+4)) = YUV422_black;
						
						  }
					 }
				}

				#endif
				// 1. STL_NEED_RMPLAYER_BUS
				//xCoord += 16;
				// 2. STL_NEED_RMS_TR
				xCoord += 8;
				
			}

			else
			{
				// �����ַ�
				memcpy(frontTemp2,Temp[i].OsdLattice,32);


			//GetOsdColor( &FrontColor, Image, yCoord, xCoord, width, &Temp[i].OSDColor, LT_CHINESE );
			#ifdef STL_TMSDK_VAR
				FrontColor = osdcolor;
			#else
				Value = (WORD *)(Image + ((yCoord+8)*width+(xCoord+8)*2));

				FrontColor = Temp[i].OSDColor;
//				if(*Value>0xc080)
				if(*Value>0x8080)
				{
					if(Temp[i].OSDColor == 0)
					{
						FrontColor = YUV422_black;
						Temp[i].OSDColor = YUV422_black;
					}
					else
					{
						if(Temp[i].OSDColor == YUV422_wite)
						{
//							if(*Value>0xd080)
							if(*Value>0xa080)
							{
								FrontColor = YUV422_black;
								Temp[i].OSDColor = YUV422_black;
							}
						}
					}	
				}
				else
				{
					if(Temp[i].OSDColor == 0)
					{
						FrontColor = YUV422_wite;
						Temp[i].OSDColor = YUV422_wite;
					}
					else
					{
						if(Temp[i].OSDColor == YUV422_black)
						{
//							if(*Value<0xb080)
							if(*Value<0x6080)
							{
								FrontColor = YUV422_wite;
								Temp[i].OSDColor = YUV422_wite;
							}

						}
					}
				}

		#endif
				//*/
				   for( ii=0;ii<16;ii++)
					for( jj=0;jj<2;jj++)
					 for( kk=0;kk<8;kk++)
					  if(((frontTemp2[ii*2+jj]>>(7-kk))&0x1)!=NULL)
					  {

						*(WORD *)(Image + ((yCoord+ii*2)*width+(xCoord+8*jj*2+kk*2)*2)) = FrontColor;
						*(WORD *)(Image + ((yCoord+ii*2+1)*width+(xCoord+8*jj*2+kk*2)*2)) = FrontColor;
						*(WORD *)(Image + ((yCoord+ii*2)*width+(xCoord+8*jj*2+kk*2)*2+2)) = FrontColor;
						*(WORD *)(Image + ((yCoord+ii*2+1)*width+(xCoord+8*jj*2+kk*2)*2+2)) = FrontColor;

						  //*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+8*jj+kk)*2)) = FrontColor;
					  }
					   
					  //else
						  //*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+8*jj+kk)*2)) = YUV422_black;
					  xCoord += 32;
			}
		}
	}	
}
//*/

//���ڻ������ĵ���ͼ������Ƶ֡�����С�
// Ч������Ϊ��ɫ���ʻ�����Χʹ��һȦ��ɫ�߿�
// by Ligo, 2007.9.24
void CDDrawDisplay::WriteOsd_ByBorder(BYTE *Image, int ImageWidth, int xpos,int ypos, 
							 tag_OSDFrontLattice *OsdLattice,int OSDLenth,int osdcolor)
{
	tag_OSDFrontLattice *Temp = OsdLattice;
	char Row = 0;
	WORD Row2 = 0;

	char frontTemp[16];
	char frontTemp2[32];

	WORD YUV422_wite = 0xf080;
	WORD YUV422_black = 0x1080;

	int xCoord = xpos + 15;			// �ı��豸ͨ��������ʾ��λ��    caojun 070831
	int yCoord = ypos + 10;			// �ı��豸ͨ��������ʾ��λ��	
	int newposx = xpos;
	int newposy = ypos;
	int width = ImageWidth;//*2;

	int ii,kk,jj;

	if(OSDLenth>0)
	{
		for(int i=0;i<OSDLenth;i++)
		{
			if(Temp[i].FrontType == 0)
			{
				// Ӣ���ַ�
				memcpy(frontTemp,Temp[i].OsdLattice,16);

				for( ii=0;ii<16;ii++)
				{
					for( kk=0;kk<8;kk++)
					{
						if(((frontTemp[ii]>>(7-kk))&0x1)!=NULL)
						{
							// �бʻ�
							//*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = FrontColor;
							if ( ii == 0 )
							{
								// ��һ��
								//if ( kk == 0 )
								{


									// ֻ�ڵ�һ�а��������һ�е���ɫҲ��������
									*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk-1)*2)) = YUV422_black;		// ���Ͻǵ�����
									*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk-0)*2)) = YUV422_black;		// �Ϸ���һ������
									*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk+1)*2)) = YUV422_black;		// ���Ϸ�������
									// ֻ�ڵ�һ�а��������һ�е���ɫҲ��������
									//*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk-1)*2)) = YUV422_black;		// ���Ͻǵ�����
									//*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk-0)*2)) = YUV422_black;		// �Ϸ���һ������
									//*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+kk+1)*2)) = YUV422_black;
								}
							}
							if ( kk == 0 )
							{
								// ��һ�У���Ҫ����������ؽ�����ɫ
								*(WORD *)(Image + ((yCoord+ii+0)*width+(xCoord+kk-1)*2)) = YUV422_black;		// �󷽵�����
							}

							// �Ա��е��Ҳࡢ�²������ɫ
							{
								*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+kk-1)*2)) = YUV422_black;		// ���·�������
								*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+kk+0)*2)) = YUV422_black;		// �·�������
								*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+kk+1)*2)) = YUV422_black;		// ���·�������
								*(WORD *)(Image + ((yCoord+ii-0)*width+(xCoord+kk+1)*2)) = YUV422_black;		// �ҷ�������
							}

							// ����Ϳ��ɫ
							*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = YUV422_wite;
						}
						/*
						else
						{
							// �ޱʻ�
							*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = YUV422_black;
						}
						//*/
					}
				}
				xCoord += 8;
			}
			else
			{
				// ����
				memcpy(frontTemp2,Temp[i].OsdLattice,32);
				//memcpy(frontTemp2,Temp[i].OsdLattice,64);
				for( ii=0;ii<16;ii++)
				{
					for( jj=0;jj<2;jj++)
					{
						for( kk=0;kk<8;kk++)
						{
							if(((frontTemp2[ii*2+jj]>>(7-kk))&0x1)!=NULL)
							{
								if ( ii == 0 )
								{
									// ��һ��
									//if ( kk == 0 )
									{
										// ֻ�ڵ�һ�а��������һ�е���ɫҲ��������
										*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+8*jj+kk-1)*2)) = YUV422_black;		// ���Ͻǵ�����
										*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+8*jj+kk-0)*2)) = YUV422_black;		// �Ϸ���һ������
										*(WORD *)(Image + ((yCoord+ii-1)*width+(xCoord+8*jj+kk+1)*2)) = YUV422_black;		// ���Ϸ�������
									}
								}
								if ( kk == 0 )
								{
									// ��һ�У���Ҫ����������ؽ�����ɫ
									*(WORD *)(Image + ((yCoord+ii+0)*width+(xCoord+8*jj+kk-1)*2)) = YUV422_black;		// �󷽵�����
								}

								// �Ա��е��Ҳࡢ�²������ɫ
								{
									*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+8*jj+kk-1)*2)) = YUV422_black;		// ���·�������
									*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+8*jj+kk+0)*2)) = YUV422_black;		// �·�������
									*(WORD *)(Image + ((yCoord+ii+1)*width+(xCoord+8*jj+kk+1)*2)) = YUV422_black;		// ���·�������
									*(WORD *)(Image + ((yCoord+ii-0)*width+(xCoord+8*jj+kk+1)*2)) = YUV422_black;		// �ҷ�������
								}

								// ����Ϳ��ɫ
								//*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+kk)*2)) = YUV422_wite;
								*(WORD *)(Image + ((yCoord+ii)*width+(xCoord+8*jj+kk)*2)) = YUV422_wite;
							}
						}
					}
				}

				xCoord += 16;
			}
		}
	}	
}


void CDDrawDisplay::GetOsdColor( WORD *FrontColor, BYTE *Image, int yCoord, int xCoord, 
										int width, WORD *OSDColor, int LangType )
{
	WORD YUV422_wite = 0xf080;
	WORD YUV422_black = 0x1080;
	WORD *Value;
	#ifdef STL_TMSDK_VAR
	FrontColor = osdcolor;
	#else
	
	if ( LangType == LT_ENGLISH )
	{
		// Ӣ��
		Value = (WORD *)(Image + ((yCoord+8)*width+(xCoord+4)*2));
	}
	else
	{
		// ����
		Value = (WORD *)(Image + ((yCoord+8)*width+(xCoord+8)*2));
	}
	FrontColor = OSDColor;
	//				if(*Value>0xc080)
	if(*Value>0x8080)
	//if(0x4880>*Value>0xB880)
	{
		if(*OSDColor == 0)
		{
			*FrontColor = YUV422_black;
			*OSDColor = YUV422_black;
		}
		else
		{
			if(*OSDColor == YUV422_wite)
			{
	//							if(*Value>0xd080)
				if(*Value>0xa080)
				{
					*FrontColor = YUV422_black;
					*OSDColor = YUV422_black;
				}
			}
		}	
	}
	else
	{
		if(*OSDColor == 0)
		{
			*FrontColor = YUV422_wite;
			*OSDColor = YUV422_wite;
		}
		else
		{
			if(*OSDColor == YUV422_black)
			{
	//							if(*Value<0xb080)
				if(*Value<0x6080)
				{
					*FrontColor = YUV422_wite;
					*OSDColor = YUV422_wite;
				}
			}
		}
	}
	#endif

}

//���ֿ��еõ�����ͼ
void CDDrawDisplay::GetFrontLattice(tag_OSDFrontLattice *OsdLattice, LPCTSTR String)
{
	int FrontNum = 0 ;
	tag_OSDFrontLattice *Temp = OsdLattice;

	long int nma;
	int m;
	unsigned int qma,wma;
	
	for(m=0 ; m< static_cast<int>(_tcslen(String)); m++)
	{
		qma = (BYTE )*(String+m);
		
		if(qma<0xa1)
		{
			Temp[FrontNum].FrontType = 0;
			nma=qma*16;
			//nma=qma*32;		//32�����ַ�
		}
		else
		{
			m++;
			wma=(unsigned char)*(String+m);
			Temp[FrontNum].FrontType = 1;
			nma=((qma-0xa1)*94+(wma-0xa1))*32;
			//nma=((qma-0xa1)*94+(wma-0xa1))*128;		//32�����ַ�
		}

		if(Temp[FrontNum].nma != nma)
		{
			Temp[FrontNum].nma= nma;

			/*if(Temp[FrontNum].FrontType == 0)
				memcpy(Temp[FrontNum].OsdLattice,pAscFrontSource+nma,16);
			else
				memcpy(Temp[FrontNum].OsdLattice,pHZKFrontSource+nma,32);
			*/
		}

		FrontNum++;

	}
}

//---------------------------------------------------------------------------------------------
//˵����������ʾOSD
//		[in]szOsd:OSD�ַ�����Ϣ��������'/0'���������ҳ��Ȳ��ô���16
//		[in]showPos:��ʾλ��
//		[in]iBrightness:���� 0-255
//		[in]bShow:�Ƿ��ڴ�������ʾOSD��TRUE��ʾ��FALSE����ʾ
//���أ��ɹ�����TRUE��ʧ�ܷ���FALSE
//---------------------------------------------------------------------------------------------
unsigned long CDDrawDisplay::SetOsd( unsigned long lShow /*= HI_HIDE*/,
									LPCTSTR pszOsd /*= NULL*/,
									E_OSDShowPos enuShowPos /*= OSD_LEFT_TOP*/,
									unsigned long lBrightness /*= 0*/ )
{
	unsigned long lRet = HI_ERR_PAR_PARAMETER;		// by Ligo, 2008.6.4
	EnterOsdCS();
	if(lShow == HI_HIDE)
	{
		InitOsd();
		lRet = HI_ERR_SUCCESS;
	}
	else
	{
		if(pszOsd)
		{
			size_t iLen = _tcslen(pszOsd);
			if(iLen <= OSD_LENTH && lBrightness <= 255 && enuShowPos >= OSD_LEFT_TOP
				&& enuShowPos <= OSD_RIGHT_BOTTOM )
			{
				InitOsd();
				m_lOsdLen = iLen;
				m_lBrightness_osd = lBrightness;
				m_lShowOsd = HI_SHOW;
				m_eShowPos = enuShowPos;
				GetFrontLattice( m_OsdInfo, (LPCTSTR)pszOsd );

				lRet = HI_ERR_SUCCESS;
			}
		}
	}
	LeaveOsdCS();

	return lRet;
}

//---------------------------------------------------------------------------------------------
//˵����������ʾOSD
//		[in]szOsd:OSD�ַ�����Ϣ��������'/0'���������ҳ��Ȳ��ô���16
//		[in]showPos:��ʾλ��
//		[in]Index:��ʾ�ڼ���osd������2��osd��ȡֵΪ0����1
//���أ��ɹ�����TRUE��ʧ�ܷ���FALSE
//---------------------------------------------------------------------------------------------
BOOL CDDrawDisplay::SetOsdEx(char* szOsd, E_OSDShowPos showPos, int Index)
{
	BOOL bRtn(TRUE);
	EnterOsdCS();
	if(szOsd)
	{
		int iLen = strlen(szOsd);
		if(iLen > OSD_LENTH || showPos < OSD_LEFT_TOP || showPos > OSD_RIGHT_BOTTOM )
		{
			bRtn = FALSE;
		}
		else
		{
			//InitOsd();   //���ڹ�����Ŀ�˴��ӵĴ������   caojun 070919
			if (0 == Index)
			{
				m_iOsdLen1 = iLen;
				GetFrontLattice(m_OsdInfo1, szOsd);
			}
			else if (1 == Index)
			{
				m_iOsdLen2 = iLen;
				GetFrontLattice(m_OsdInfo2, (LPCTSTR)szOsd);
			}
			else
			{
				m_iOsdLen3 = iLen;
				GetFrontLattice(m_OsdInfo3, (LPCTSTR)szOsd);
			}
		}
	}
	else
	{
		bRtn = FALSE;
	}
	LeaveOsdCS();
	return bRtn;
}

// ��ͼ������ʾosd��Ϣ���������ȣ�γ�ȣ��ٶȣ������¶ȡ�������
BOOL CDDrawDisplay::SetShowMdvrInfo( unsigned long lShow )
{
	m_lShowMdvrInfo = lShow;
	return TRUE;
}

//����OSD���õ��ٽ���
void CDDrawDisplay::EnterOsdCS()
{
	EnterCriticalSection(&m_csOsd);
}

//�뿪OSD���õ��ٽ���
void CDDrawDisplay::LeaveOsdCS()
{
	LeaveCriticalSection(&m_csOsd);
}

//��ʼ��OSD��Ϣ
void CDDrawDisplay::InitOsd()
{
	m_lShowOsd = HI_HIDE;
	memset(m_OsdInfo, 0, sizeof(m_OsdInfo));
	m_eShowPos = OSD_LEFT_TOP;
	m_lBrightness_osd = 0;
	m_lOsdLen = 0;
}

//�ӵ�ǰ��ʾλ�úͻ����Сȡ����ʾλ�õ���Ϣ
void CDDrawDisplay::GetPos(int iWidth, int iHeight, int& xPos, int& yPos)
{
	switch(m_eShowPos)
	{
	case OSD_LEFT_TOP:// ����
		xPos = 5;
		yPos = 5;
		break;	
	case OSD_RIGHT_TOP:// ����
		xPos = iWidth - (130.0/OSD_LENTH)*m_lOsdLen;
		yPos = 5;
		break;	
	case OSD_LEFT_BOTTOM:// ����
		xPos = 5;
		yPos = iHeight/2 -20;
		break;
	case OSD_RIGHT_BOTTOM:// ����
		xPos = iWidth - (130.0/OSD_LENTH)*m_lOsdLen;
		yPos = iHeight/2 - 20;
		break;
	default:
		break;
	}
}

//��ʾOSD
void CDDrawDisplay::ShowOSD(BYTE *Image, int ImageWidth)
{
	//ShowOSD
	{
		EnterOsdCS();
//		if (g_sys.m_lSetDVRInfo == HI_SHOW)
		{
			int xPos = 3;
			int yPos = 0;	
		}
//		else 
//		{
//			if((m_lShowOsd == HI_SHOW) && m_lOsdLen)	//��ʾOSD����Ϣ
//			{
//				int xPos = 0;
//				int yPos = 0;	
//				GetPos(dd_width, dd_height, xPos, yPos);	
				//WriteOsd(Image/*(BYTE*)desc.lpSurface*/, ImageWidth/*desc.lPitch*/, 
					//xPos, yPos, m_OsdInfo, m_iOsdLen, m_iBrightness);
				//WriteOsd(Image/*(BYTE*)desc.lpSurface*/, ImageWidth/*desc.lPitch*/, 
				//	xPos, yPos + 12, m_OsdInfo, m_iOsdLen, m_iBrightness);
//			}
//		}
		LeaveOsdCS();
	}
}

void CDDrawDisplay::SetColor(int bright, int Hue, int Sat, int Con)
{
	SetColorPara(COLOR_BRIGHT, bright);
	SetColorPara(COLOR_HUE, Hue);
	SetColorPara(COLOR_SATURATION, Sat);
	SetColorPara(COLOR_CONTRAST, Con);
}


/*************************************************************************
����ͼ�����ȡ�ͼ���ʽΪYUV422������������4���ֽڱ�ʾ
˼·������Ǵ���0�����ʾҪ��������ȡԭ��ֵ��255�Ĳ��İٷֱȺ��ټ���ԭ����ֵ
�����С��0�����ʾҪ��������ֱ��ȡԭ��ֵ�İٷֱȼ���
�ٷֱ���ָ�ϲ��ṩ��ֵ�ľ���ֵ��255��ȵĽ��
������
 byMediaData��[in]��ͼ������
 lWidth��[in]��ͼ��Ŀ���
 lHeight��[in]��ͼ��ĸ߶�
 lBrightness��[in]�����ȡ���Χ��0 ~ 255��0���255����
����ֵ����
by Ligo, 2007.12.12
*****************************************************************************/
void CDDrawDisplay::EffectBrightness( BYTE *byMediaData, long lWidth, long lHeight )
{
	long lm;
	for ( long y = 0; y < lHeight; y++ )
	{
		for ( long x = 0; x < lWidth; x += 2 )
		{
			lm = 0x000000FF & byMediaData[y * lWidth + x + 1];
			if ( m_lBrightness_cp > 0 )
				lm = (255 - lm) * m_lBrightness_cp / 255 + lm;
			else
				lm = lm * (255 + m_lBrightness_cp) / 255;
			byMediaData[y * lWidth + x + 1] = BYTE(lm);
		}
	}
}

/************************************************************************/
/* ͨ���ⲿ�ӿڣ��������ȱ���										     */
/************************************************************************/
unsigned long CDDrawDisplay::SetChBrightness( unsigned long lBrightness )
{
	m_lBrightness_cp = lBrightness;
	return HI_ERR_SUCCESS;
}

void CDDrawDisplay::UpdateBounds()
{
    GetClientRect(this->m_hWnd, &this->m_rcWindow);
    ClientToScreen(this->m_hWnd, (POINT*)&this->m_rcWindow.left);
    ClientToScreen(this->m_hWnd, (POINT*)&this->m_rcWindow.right);
}

void CDDrawDisplay::InvalidRect()
{
    RECT rcInvalidate;
    rcInvalidate.top = 0;
    rcInvalidate.left = 0;
    rcInvalidate.right = m_rcWindow.right - m_rcWindow.left;
    rcInvalidate.bottom = m_rcWindow.bottom - m_rcWindow.top;
    InvalidateRect(m_hWnd, &rcInvalidate, TRUE);
}