#pragma once
#include <Windows.h>
#include <ddraw.h>
#include <assert.h>
#pragma comment(lib, "ddraw.lib")
#pragma comment(lib, "dxguid.lib")
#define SafeRelease(pobj) if(pobj){pobj->Release();pobj=NULL;}
static DDPIXELFORMAT ddpfOverlayFormats[] = {
	{sizeof(DDPIXELFORMAT), DDPF_FOURCC, MAKEFOURCC('Y','V','1','2'),0,0,0,0,0},  // YV12
	{sizeof(DDPIXELFORMAT), DDPF_FOURCC, MAKEFOURCC('U','Y','V','Y'),0,0,0,0,0},  // UYVY    
};
#define PF_TABLE_SIZE (sizeof(ddpfOverlayFormats) / sizeof(ddpfOverlayFormats[0]))
class CDDraw
{
public:
	CDDraw(void);
	virtual ~CDDraw(void);
	virtual bool InitDDraw7(HWND hWnd, int width, int height);
	virtual LPDIRECTDRAWSURFACE7 CreatEmptySurface(int w , int h);
	virtual LPDIRECTDRAWSURFACE7 CreatOverlaySurface(int w , int h);
	virtual void ReleaseDDraw(void);
	virtual HRESULT RestoreDDraw(void);
	virtual HRESULT RestoreAllSurfaces();
	virtual int SetDDSPointColor(LPDIRECTDRAWSURFACE7	lpDDSO, DWORD color);
	virtual bool CreateClipper(HWND hWnd);
	virtual void DrawText(LPDIRECTDRAWSURFACE7 lpDDSo, int x, int y, LPCTSTR str, COLORREF textcolor = RGB(255, 255, 255), int fontheight = 16, int fontwidth = 8);
	virtual void Clrscr(LPDIRECTDRAWSURFACE7,WORD=0);
	virtual void DrawRect(DWORD color, LPRECT rt, LPDIRECTDRAWSURFACE7 lpDDSO);
	virtual void DrawRect(DWORD color, int sx, int sy, int ex, int ey, LPDIRECTDRAWSURFACE7 lpDDSO);
	virtual LPDIRECTDRAWSURFACE7 MyLoadBitmap(HBITMAP hbm, int W,	int H);
	virtual void MySetColorKey(LPDIRECTDRAWSURFACE7 lpDDSO);

	virtual HRESULT PlayYUV(BYTE* y, BYTE* u, BYTE* v, LPDIRECTDRAWSURFACE7 lpDDSView, int w, int h, int dataStrip);
	virtual void Flip(LPDIRECTDRAWSURFACE7 lpDDSView);
	virtual void FlipFast(LPDIRECTDRAWSURFACE7 lpDDSView);
	virtual void FlipRect(LPDIRECTDRAWSURFACE7 lpDDSView, RECT* dst, RECT* src = NULL);
	virtual bool IsDDrawCreate();
	
public:
	HWND m_hWnd;
	int m_height;
	int m_widht;
	LPDIRECTDRAW7			lpDD;
	LPDIRECTDRAWSURFACE7	lpDDSFront;
	LPDIRECTDRAWSURFACE7    lpDDSBack;
	LPDIRECTDRAWCLIPPER		 lpClipper;
};