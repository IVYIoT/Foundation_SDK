#include "StdAfx.h"
#include "windows.h"

char m_mmxcap = 0;	//mmx capability
short c128[8] = {128, 128, 128, 128, 128, 128, 128, 128};

#define CPU_MMX			1
#define CPU_SSE2		2

void GetMmxCap()
{
	DWORD mmx_code;
	_asm
	{
		mov eax, 1;
		cpuid;
		mov mmx_code, edx;
	}

	if(mmx_code & 0x00800000)
		m_mmxcap = CPU_MMX;
	if(mmx_code & 0x04000000)
		m_mmxcap = CPU_SSE2;
}