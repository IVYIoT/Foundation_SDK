
// sdkDemoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "sdkDemo.h"
#include "sdkDemoDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsdkDemoDlg �Ի���


int recorderrcb(FOSRECORD_ERROR errcode)
{
	switch(errcode)
	{
	case FOSRECORD_ERROR_ACHIEVE_FILE_MAXSIZE:
		{
			AfxMessageBox("�ﵽ�ļ����ֵ��¼�������");
			break;
		}
	case FOSRECORD_ERROR_NO_ENOUGE_SPACE:
		{
			AfxMessageBox("û���㹻�Ĵ洢�ռ䣬¼�������");
			break;
		}
	case FOSRECORD_ERROR_RESOLUTION_CHANGE:
		{
			AfxMessageBox("�ֱ��ʷ����仯��¼�������");
			break;
		}
	case FOSRECORD_ERROR_UNKNOW:
		{
			AfxMessageBox("����δ֪����¼�������");
			break;
		}
	default:
		{
			break;
		}
	}
	return 0;
}

CsdkDemoDlg::CsdkDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CsdkDemoDlg::IDD, pParent)
{
	m_videoPlayMode = VIDEO_PLAYMODE_LIVEVIEW;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CsdkDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CsdkDemoDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON6, &CsdkDemoDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON11, &CsdkDemoDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON1, &CsdkDemoDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CsdkDemoDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON4, &CsdkDemoDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON3, &CsdkDemoDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON7, &CsdkDemoDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON5, &CsdkDemoDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON8, &CsdkDemoDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON14, &CsdkDemoDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CsdkDemoDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &CsdkDemoDlg::OnBnClickedButton16)
//	ON_NOTIFY(TRBN_THUMBPOSCHANGING, IDC_SLIDER5, &CsdkDemoDlg::OnTRBNThumbPosChangingSlider5)
//ON_NOTIFY(TRBN_THUMBPOSCHANGING, IDC_SLIDER1, &CsdkDemoDlg::OnTRBNThumbPosChangingSlider1)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER1, &CsdkDemoDlg::OnNMReleasedcaptureSlider1)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER2, &CsdkDemoDlg::OnNMReleasedcaptureSlider2)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER3, &CsdkDemoDlg::OnNMReleasedcaptureSlider3)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER4, &CsdkDemoDlg::OnNMReleasedcaptureSlider4)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER5, &CsdkDemoDlg::OnNMReleasedcaptureSlider5)
ON_BN_CLICKED(IDC_BUTTON17, &CsdkDemoDlg::OnBnClickedButton17)
ON_BN_CLICKED(IDC_BUTTON18, &CsdkDemoDlg::OnBnClickedButton18)
ON_BN_CLICKED(IDC_BUTTON12, &CsdkDemoDlg::OnBnClickedButton12)
ON_BN_CLICKED(IDC_BUTTON13, &CsdkDemoDlg::OnBnClickedButton13)
ON_BN_CLICKED(IDC_BUTTON19, &CsdkDemoDlg::OnBnClickedButton19)
ON_BN_CLICKED(IDC_BUTTON20, &CsdkDemoDlg::OnBnClickedButton20)
ON_BN_CLICKED(IDC_BUTTON21, &CsdkDemoDlg::OnBnClickedButton21)
ON_BN_CLICKED(IDC_BUTTON22, &CsdkDemoDlg::OnBnClickedButton22)
ON_BN_CLICKED(IDC_BUTTON23, &CsdkDemoDlg::OnBnClickedButton23)
ON_BN_CLICKED(IDC_BUTTON10, &CsdkDemoDlg::OnBnClickedButton10)
ON_BN_CLICKED(IDC_BUTTON9, &CsdkDemoDlg::OnBnClickedButton9)
ON_BN_CLICKED(IDC_BUTTON24, &CsdkDemoDlg::OnBnClickedButton24)


ON_BN_CLICKED(IDC_BUTTON_STARTRECORD, &CsdkDemoDlg::OnBnClickedButtonStartrecord)
ON_BN_CLICKED(IDC_BUTTON_STOPRECORD, &CsdkDemoDlg::OnBnClickedButtonStoprecord)
ON_BN_CLICKED(IDC_BUTTON25, &CsdkDemoDlg::OnBnClickedButton25)
ON_BN_CLICKED(IDC_BTNOpenPB, &CsdkDemoDlg::OnBnClickedBtnopenpb)
ON_BN_CLICKED(IDC_BTNClosePB, &CsdkDemoDlg::OnBnClickedBtnclosepb)
ON_BN_CLICKED(IDC_BTNSeekForward, &CsdkDemoDlg::OnBnClickedBtnseekforward)
ON_BN_CLICKED(IDC_BTNSeekBack, &CsdkDemoDlg::OnBnClickedBtnseekback)
ON_BN_CLICKED(IDC_BTNPBPause, &CsdkDemoDlg::OnBnClickedBtnpbpause)
ON_BN_CLICKED(IDC_BTNPBResume, &CsdkDemoDlg::OnBnClickedBtnpbresume)
END_MESSAGE_MAP()


// CsdkDemoDlg ��Ϣ��������

void CsdkDemoDlg::AudioRecv(int type, unsigned char* pData, int length, LPVOID pUser )
{
	CsdkDemoDlg* pThis = (CsdkDemoDlg*)pUser;
	FosSdk_SendTalkData(pThis->m_hFos, (char*)pData, length);
}

BOOL CsdkDemoDlg::ChildWndProc(HWND hWnd, LPARAM lParam)
{
	::EnableWindow(hWnd, lParam);
	return TRUE;
}

void CsdkDemoDlg::SetMediaSpeed(int speed)
{
	char tem[256] = {0};
	sprintf(tem, "%d bytes/s", speed);
	GetDlgItem(IDC_STATICMediaSpeed)->SetWindowText(tem);
	return;
}

BOOL CsdkDemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	//GetDlgItem(IDC_EDIT1)->SetWindowText("192.168.1.7:88/2:12345a");
	GetDlgItem(IDC_EDIT1)->SetWindowText("192.168.1.3:88/1:foscam1");
	GetDlgItem(IDC_EDIT2)->SetWindowText("cmd=getImageSetting");
	HWND hWnd = GetDlgItem(IDC_STATIC)->GetSafeHwnd();
	RECT rt;
	::GetWindowRect(hWnd, &rt);
	m_ddraw.InitDDraw7(hWnd, rt.right - rt.left, rt.bottom - rt.top);
	m_d3d.InitDDraw(hWnd, rt.right - rt.left, rt.bottom - rt.top);
	m_hThread = NULL;
	m_hAudioThread = NULL;
	m_pYUV = NULL;
	m_pRGB = NULL;
	m_hFos = NULL;
	m_bLogin = false;

	HWND hWndSlider = GetDlgItem(IDC_SLIDER1)->GetSafeHwnd();
	SendMessageW(hWndSlider, TBM_SETRANGE, TRUE, (LPARAM)MAKELONG(0, 100));
	hWndSlider = GetDlgItem(IDC_SLIDER2)->GetSafeHwnd();
	SendMessageW(hWndSlider, TBM_SETRANGE, TRUE, (LPARAM)MAKELONG(0, 100));
	hWndSlider = GetDlgItem(IDC_SLIDER3)->GetSafeHwnd();
	SendMessageW(hWndSlider, TBM_SETRANGE, TRUE, (LPARAM)MAKELONG(0, 100));
	hWndSlider = GetDlgItem(IDC_SLIDER4)->GetSafeHwnd();
	SendMessageW(hWndSlider, TBM_SETRANGE, TRUE, (LPARAM)MAKELONG(0, 100));
	hWndSlider = GetDlgItem(IDC_SLIDER5)->GetSafeHwnd();
	SendMessageW(hWndSlider, TBM_SETRANGE, TRUE, (LPARAM)MAKELONG(0, 100));

	m_hAudioOut = CreatePlayDev();
	OpenPlayDev(m_hAudioOut);

	m_hAudioIn = CreateRecDev();
	SetRecDataCallback(m_hAudioIn, AudioRecv, this);
	OpenRecDev(m_hAudioIn);

	EnumChildWindows(GetSafeHwnd(), ChildWndProc, FALSE);
	::EnableWindow(GetDlgItem(IDC_BUTTON22)->GetSafeHwnd(), TRUE);
	::EnableWindow(GetDlgItem(IDC_EDIT1)->GetSafeHwnd(), TRUE);
	::EnableWindow(GetDlgItem(IDC_BUTTON24)->GetSafeHwnd(), TRUE);
	::EnableWindow(GetDlgItem(IDC_RICHEDIT23)->GetSafeHwnd(), TRUE);
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CsdkDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CsdkDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CsdkDemoDlg::OnBnClickedButton6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FosSdk_PtzCmd(m_hFos, FOSPTZ_LEFT_UP, 500);
}

DWORD CsdkDemoDlg::ThreadRun(LPVOID lpParam)
{
	CsdkDemoDlg* pThis = (CsdkDemoDlg*)lpParam;
	FOSHANDLE hFos = pThis->m_hFos;
	int usrRight = 0;
	int offLineCount = 0;
	bool bConnectErro = false;
	//Sleep(3000);
	//FosSdk_CancelAllNetCmd(h);
	FOSDEC_DATA* pFrame = NULL;
	int dataLen = 0;
	int times = 100;
	FOSDECFMT videofmt = FOSDECTYPE_YUYV422;
	FOSDECFMT audiofmt = FOSDECTYPE_PCM;
	int w=0, h=0;
	DWORD tick = GetTickCount();
	int mediaSpeed = 0;
	FOSEVET_DATA event;
	while(pThis->m_hThreadRun)
	{
		if (pThis->m_videoPlayMode == VIDEO_PLAYMODE_LIVEVIEW)
		{
			if ( FOSCMDRET_OK == FosSdk_GetVideoData2(hFos, (char**)&pFrame, &dataLen, videofmt,&mediaSpeed) )
			{
				tick = GetTickCount();
				pThis->SetMediaSpeed(mediaSpeed);
				if (dataLen)
				{
					if (pFrame->type == FOSMEDIATYPE_VIDEO)
					{
						if (pThis->m_pYUV == NULL || w != pFrame->media.video.picWidth || h != pFrame->media.video.picHeight || GetTickCount() - tick > 5000)
						{
							SafeRelease(pThis->m_pRGB);
							SafeRelease(pThis->m_pYUV);
							w = pFrame->media.video.picWidth;
							h = pFrame->media.video.picHeight;
							pThis->m_pRGB = pThis->m_ddraw.CreatEmptySurface(pFrame->media.video.picWidth, pFrame->media.video.picHeight);
							pThis->m_pYUV = pThis->m_ddraw.CreatOverlaySurface(pFrame->media.video.picWidth, pFrame->media.video.picHeight);
							HWND hWnd = pThis->GetDlgItem(IDC_STATIC)->GetSafeHwnd();
							pThis->m_d3d.InitDDraw(hWnd, w, h);
						}
						pThis->m_d3d.DrawVideoIamge(pFrame->data, 1, 0);

					}
				}
			}
			else
			{
				if (GetTickCount() - tick > 3000)
				{
					pThis->SetMediaSpeed(0);
				}
			}
		}
		else if (pThis->m_videoPlayMode == VIDEO_PLAYMODE_PLAYBACK)
		{

			if ( FOSCMDRET_OK == FosSdk_GetVideoPBData(hFos, (char**)&pFrame, &dataLen, videofmt,&mediaSpeed) )
			{
				tick = GetTickCount();
				pThis->SetMediaSpeed(mediaSpeed);
				if (dataLen)
				{
					if (pFrame->type == FOSMEDIATYPE_VIDEO)
					{
						if (pThis->m_pYUV == NULL || w != pFrame->media.video.picWidth || h != pFrame->media.video.picHeight || GetTickCount() - tick > 5000)
						{
							SafeRelease(pThis->m_pRGB);
							SafeRelease(pThis->m_pYUV);
							w = pFrame->media.video.picWidth;
							h = pFrame->media.video.picHeight;
							pThis->m_pRGB = pThis->m_ddraw.CreatEmptySurface(pFrame->media.video.picWidth, pFrame->media.video.picHeight);
							pThis->m_pYUV = pThis->m_ddraw.CreatOverlaySurface(pFrame->media.video.picWidth, pFrame->media.video.picHeight);
							HWND hWnd = pThis->GetDlgItem(IDC_STATIC)->GetSafeHwnd();
							pThis->m_d3d.InitDDraw(hWnd, w, h);
						}
						pThis->m_d3d.DrawVideoIamge(pFrame->data, 1, 0);

					}
				}
			}
			else
			{
				if (GetTickCount() - tick > 3000)
				{
					pThis->SetMediaSpeed(0);
				}
			}
		}
		
		if (FOSCMDRET_OK == FosSdk_GetEvent(hFos, &event))
		{
			if(event.id == EVENT_MSG::NETSTATE_RECONNECTRESULT)
			{
				FOSRECONNECTPARAM *reconnectMsg = (FOSRECONNECTPARAM *)event.data;
				usrRight = reconnectMsg->usrPrivilege;
				if (reconnectMsg->state == FOS_HANDLE_ONLINE)
				{
					AfxMessageBox("�豸�����ˣ�����");
					bConnectErro = false;
				}
				else
				{
					if (reconnectMsg->result == FOSUSRRET_USRNAMEORPWD_ERR)
					{
						AfxMessageBox("�û��������벻ƥ��");
					}
					bConnectErro = true;
				}
			}
			if(event.id == EVENT_MSG::NETSTATE_CONNECTERROR_EVENT_CHG)
			{
				AfxMessageBox("�豸�����ߣ�����");
				bConnectErro = true;
			}
			if(event.id == EVENT_MSG::VIDEO_EPT_STATE_CHG)
			{
				FOS_VideoEPTValue *value = (FOS_VideoEPTValue*)event.data;
				int a= 0;
				int b = 0;
			}
			if(event.id == EVENT_MSG::RECORD_EVENT_CHG && event.len == sizeof(FOSRECORD))
			{
				FOSRECORD* record = (FOSRECORD*)event.data;
				int n = record->state;
			}
			if(event.id == EVENT_MSG::IRCUT_EVENT_CHG && event.len == sizeof(FOSIRCUTSTATE))
			{
				FOSIRCUTSTATE* ircut = (FOSIRCUTSTATE*)event.data;
				int n = ircut->mode;
			}
			if(event.id == EVENT_MSG::PRESET_EVENT_CHG && event.len == sizeof(FOSPRESETPOINT))
			{
				FOSPRESETPOINT* preset = (FOSPRESETPOINT*)event.data;
				int n = preset->cnt;
			}
			if(event.id == EVENT_MSG::CRUISE_EVENT_CHG && event.len == sizeof(FOSCRUISEMAP))
			{
				FOSCRUISEMAP* cruise = (FOSCRUISEMAP*)event.data;
				int n = cruise->cnt;
			}
			if(event.id == EVENT_MSG::MIRRORFLIP_EVENT_CHG && event.len == sizeof(FOSMIRRORFLIP))
			{
				FOSMIRRORFLIP* mirFlip = (FOSMIRRORFLIP*)event.data;
				int nt = mirFlip->isMirror;
			}
			if(event.id == EVENT_MSG::STREAMPARAM_EVENT_CHG && event.len == sizeof(FOSSTREAMPARAM))
			{
				FOSSTREAMPARAM* streamParam = (FOSSTREAMPARAM*)event.data;
				int n = streamParam->mainStreamType;
			}
			if (event.id == EVENT_MSG::IMAGE_EVENT_CHG && event.len == sizeof(FOSIMAGE))
			{
				FOSIMAGE* img = (FOSIMAGE*)event.data;
				HWND hWndSlider = pThis->GetDlgItem(IDC_SLIDER1)->GetSafeHwnd();
				SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)(*img).brightness);
				hWndSlider = pThis->GetDlgItem(IDC_SLIDER2)->GetSafeHwnd();
				SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)(*img).contrast);
				hWndSlider = pThis->GetDlgItem(IDC_SLIDER3)->GetSafeHwnd();
				SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)(*img).hue);
				hWndSlider = pThis->GetDlgItem(IDC_SLIDER4)->GetSafeHwnd();
				SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)(*img).saturation);
				hWndSlider = pThis->GetDlgItem(IDC_SLIDER5)->GetSafeHwnd();
				SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)(*img).sharpness);
			}
			if(event.id == EVENT_MSG::ALARM_EVENT_CHG && event.len == sizeof(FOSALARM))
			{
				FOSALARM* alarm = (FOSALARM*)event.data;
				int n = alarm->alarmType;
			}
			if(event.id == EVENT_MSG::PWRFREQ_EVENT_CHG && event.len == sizeof(FOSPWRFREQ))
			{
				FOSPWRFREQ* pwrFreq = (FOSPWRFREQ*)event.data;
				int n = pwrFreq->freq;
			}
			if(event.id == EVENT_MSG::STREAMTYPE_EVENT_CHG && event.len == sizeof(FOSSTREAMTYPE))
			{
				FOSSTREAMTYPE* streamType = (FOSSTREAMTYPE*)event.data;
				int n = streamType->streamType;
			}
			if(event.id == EVENT_MSG::SUBSTREAMTYPE_EVENT_CHG && event.len == sizeof(FOSSUBSTREAMTYPE))
			{
				FOSSUBSTREAMTYPE* subStreamType = (FOSSUBSTREAMTYPE*)event.data;
				int n = subStreamType->streamType;
			}
			if(event.id == EVENT_MSG::SUBSTREAMPARAM_EVENT_CHG && event.len == sizeof(FOSSUBSTREAMPARAM))
			{
				FOSSUBSTREAMPARAM* subStreamParam = (FOSSUBSTREAMPARAM*)event.data;
				int n = subStreamParam->subStreamType;
			}
			if(event.id == EVENT_MSG::AUDIO_VOLUME_CHG )
			{
				FOSVOLUME *volumeMsg = (FOSVOLUME *)event.data;
				int n = event.len;
				int volume = volumeMsg->volume;
			}
		}
		/*if (bConnectErro)
		{
		FOS_HANDLE_STATE res = FosSdk_CheckHandle(hFos, &usrRight); 
		if (res !=  FOS_HANDLE_ONLINE)
		{
		offLineCount++;
		}
		else if(offLineCount != 0)
		{
		bConnectErro = false;
		offLineCount = 0;
		AfxMessageBox("�豸�����ˣ�����");
		}
		if (offLineCount == 2500)
		{
		AfxMessageBox("�豸�����ߣ�����");
		}
		}*/
		Sleep(5);
	}
	return 0;
}

DWORD CsdkDemoDlg::AudioThreadRun(LPVOID lpParam)
{
	CsdkDemoDlg* pThis = (CsdkDemoDlg*)lpParam;
	FOSHANDLE hFos = pThis->m_hFos;
	//Sleep(3000);
	//FosSdk_CancelAllNetCmd(h);
	FOSDEC_DATA* pFrame = NULL;
	int dataLen = 0;
	int times = 100;
	int w=0, h=0;
	int undecodeLen = 0;
	FosSdk_SetWebRtcState(hFos, false);
	FOSEVET_DATA event;
	while(pThis->m_hThreadRun)
	{
		if (pThis->m_videoPlayMode == VIDEO_PLAYMODE_LIVEVIEW)
		{
			if ( FOSCMDRET_OK == FosSdk_GetAudioData2(hFos, (char**)&pFrame, &dataLen,&undecodeLen))
			{
				if (dataLen)
				{
					if (pFrame->type == FOSMEDIATYPE_AUDIO)
					{
						static FILE* fp = fopen("d://test.pcm", "wb");
						static int iCount=0;
						if (fp)
						{
							fwrite(pFrame->data, pFrame->len, 1, fp);
							if (iCount++ > 500)
							{
								fclose(fp);
								fp = NULL;
							}
						}
						WriteData(pThis->m_hAudioOut, (unsigned char*)pFrame->data, pFrame->len);
					}
				}
			}
		}
		else if (pThis->m_videoPlayMode == VIDEO_PLAYMODE_PLAYBACK)
		{
			if ( FOSCMDRET_OK == FosSdk_GetAudioPBData(hFos, (char**)&pFrame, &dataLen,&undecodeLen))
			{
				if (dataLen)
				{
					if (pFrame->type == FOSMEDIATYPE_AUDIO)
					{
						static FILE* fp = fopen("d://test.pcm", "wb");
						static int iCount=0;
						if (fp)
						{
							fwrite(pFrame->data, pFrame->len, 1, fp);
							if (iCount++ > 500)
							{
								fclose(fp);
								fp = NULL;
							}
						}
						WriteData(pThis->m_hAudioOut, (unsigned char*)pFrame->data, pFrame->len);
					}
				}
			}
		}
		
	}
	return 0;
}

void CsdkDemoDlg::OnBnClickedButton11()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}

// 	if (m_hThread)
// 	{
// 		m_hThreadRun = false;
// 		if (WaitForSingleObject(m_hThread, 5000) == WAIT_TIMEOUT)
// 		{
// 			TerminateThread(m_hThread, 0);
// 			CloseHandle(m_hThread);
// 			m_hThread = NULL;
// 		}
// 		m_hThread = NULL;
// 	}
// 	if (m_bLogin)
// 	{
// 		m_hThreadRun = true;
// 		m_hThread = CreateThread(NULL, NULL, ThreadRun, this, NULL, NULL);
// 		EnumChildWindows(GetSafeHwnd(), ChildWndProc, TRUE);
// 	}	
	if (m_videoPlayMode == VIDEO_PLAYMODE_PLAYBACK)
	{
		OnBnClickedBtnclosepb();
		Sleep(200);
	}
	m_videoPlayMode = VIDEO_PLAYMODE_LIVEVIEW;
	FOSCMD_RESULT ret = FosSdk_OpenVideo(m_hFos, FOSSTREAM_MAIN, 500);
	if (ret != FOSCMDRET_OK)
	{
		MessageBox("����Ƶʧ�ܣ�");
	}
// 	CString str;
// 	GetDlgItem(IDC_EDIT1)->GetWindowText(str);
// 	char ip[128];
// 	int port;
// 	char usr[32];
// 	char pwd[32];
// 	if (sscanf(str.GetBuffer(), "%[^:]:%d/%[^:]:%s", ip, &port, usr, pwd) != 4)
// 	{
// 		return;
// 	}
// 	m_hFos = FosSdk_Create(ip, "", usr, pwd, port, port, FOSIPC_H264, FOSCNTYPE_IP);
// 	int usrRight = 0;
// 	FOSCMD_RESULT rst = FosSdk_Login(m_hFos, &usrRight, 500);
// 	if (rst == FOSCMDRET_OK)
// 	{
// 		rst = FosSdk_OpenVideo(m_hFos, FOSSTREAM_MAIN, 5000);
// 	}
// 	if (m_hThread)
// 	{
// 		m_hThreadRun = false;
// 		if (WaitForSingleObject(m_hThread, 5000) == WAIT_TIMEOUT)
// 		{
// 			TerminateThread(m_hThread, 0);
// 			CloseHandle(m_hThread);
// 			m_hThread = NULL;
// 		}
// 	}
// 	if (rst == FOSCMDRET_OK)
// 	{
// 		m_hThreadRun = true;
// 		m_hThread = CreateThread(NULL, NULL, ThreadRun, this, NULL, NULL);
// 	}
}


void CsdkDemoDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_UP, 500);
}


void CsdkDemoDlg::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_LEFT, 500);
}


void CsdkDemoDlg::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_DOWN, 500);
}


void CsdkDemoDlg::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_RIGHT, 500);
}


void CsdkDemoDlg::OnBnClickedButton7()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_LEFT_DOWN, 500);
}


void CsdkDemoDlg::OnBnClickedButton5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_RIGHT_UP, 500);
}


void CsdkDemoDlg::OnBnClickedButton8()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_RIGHT_DOWN, 500);
}


void CsdkDemoDlg::OnBnClickedButton14()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_STOP, 500);
}


void CsdkDemoDlg::OnBnClickedButton15()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FosSdk_PtzCmd(m_hFos, FOSPTZ_CENTER, 500);
}


void CsdkDemoDlg::OnBnClickedButton16()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_hThread)
	{
		m_hThreadRun = false;
		if (WaitForSingleObject(m_hThread, 5000) == WAIT_TIMEOUT)
		{
			TerminateThread(m_hThread, 0);
			CloseHandle(m_hThread);
			m_hThread = NULL;
		}
	}
	if (m_hAudioThread)
	{
		m_hThreadRun = false;
		if (WaitForSingleObject(m_hAudioThread, 5000) == WAIT_TIMEOUT)
		{
			TerminateThread(m_hAudioThread, 0);
			CloseHandle(m_hAudioThread);
			m_hAudioThread = NULL;
		}
	}
	if (m_hFos)
	{
		SetMediaSpeed(0);
		EnumChildWindows(GetSafeHwnd(), ChildWndProc, FALSE);
		::EnableWindow(GetDlgItem(IDC_BUTTON22)->GetSafeHwnd(), TRUE);
		::EnableWindow(GetDlgItem(IDC_EDIT1)->GetSafeHwnd(), TRUE);
		::EnableWindow(GetDlgItem(IDC_BUTTON24)->GetSafeHwnd(), TRUE);
		::EnableWindow(GetDlgItem(IDC_RICHEDIT23)->GetSafeHwnd(), TRUE);
		InvalidateRect(NULL);
		FosSdk_Release(m_hFos);
		m_bLogin = false;
		m_hFos = NULL;
	}
	
}


void CsdkDemoDlg::OnNMReleasedcaptureSlider1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	if (!m_hFos || !m_bLogin)
	{
		return;
	}


	HWND hWndSlider = GetDlgItem(IDC_SLIDER1)->GetSafeHwnd(); 
	LONG value= (LONG)SendMessageW(hWndSlider, TBM_GETPOS, 0, 0);

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_BRIGHTNESS, value, 500);
}

void CsdkDemoDlg::OnNMReleasedcaptureSlider2(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	HWND hWndSlider = GetDlgItem(IDC_SLIDER2)->GetSafeHwnd(); 
	LONG value= (LONG)SendMessageW(hWndSlider, TBM_GETPOS, 0, 0);

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_CONTRAST, value, 500);
}


void CsdkDemoDlg::OnNMReleasedcaptureSlider3(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	HWND hWndSlider = GetDlgItem(IDC_SLIDER3)->GetSafeHwnd(); 
	LONG value= (LONG)SendMessageW(hWndSlider, TBM_GETPOS, 0, 0);

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_HUE, value, 500);
}


void CsdkDemoDlg::OnNMReleasedcaptureSlider4(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	HWND hWndSlider = GetDlgItem(IDC_SLIDER4)->GetSafeHwnd(); 
	LONG value= (LONG)SendMessageW(hWndSlider, TBM_GETPOS, 0, 0);

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_SATURATION, value, 500);
}


void CsdkDemoDlg::OnNMReleasedcaptureSlider5(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	HWND hWndSlider = GetDlgItem(IDC_SLIDER5)->GetSafeHwnd(); 
	LONG value= (LONG)SendMessageW(hWndSlider, TBM_GETPOS, 0, 0);

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_SHARPNESS, value, 500);
}


void CsdkDemoDlg::OnCancel()
{
	// TODO: �ڴ�����ר�ô����/����û���
	OnBnClickedButton16();
	CloseRecDev(m_hAudioIn);
	ClosePlayDev(m_hAudioOut);
	m_d3d.ReleaseSth();

	CDialogEx::OnCancel();
}


void CsdkDemoDlg::OnBnClickedButton17()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	FOSIMAGE img;
	if ( FOSCMDRET_OK == FosSdk_GetImageSetting(m_hFos, &img, 500) )
	{
		HWND hWndSlider = GetDlgItem(IDC_SLIDER1)->GetSafeHwnd();
		SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)img.brightness);
		hWndSlider = GetDlgItem(IDC_SLIDER2)->GetSafeHwnd();
		SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)img.contrast);
		hWndSlider = GetDlgItem(IDC_SLIDER3)->GetSafeHwnd();
		SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)img.hue);
		hWndSlider = GetDlgItem(IDC_SLIDER4)->GetSafeHwnd();
		SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)img.saturation);
		hWndSlider = GetDlgItem(IDC_SLIDER5)->GetSafeHwnd();
		SendMessageW(hWndSlider,TBM_SETPOS, (WPARAM)1,(LPARAM)img.sharpness);
	}
}


void CsdkDemoDlg::OnBnClickedButton18()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hFos || !m_bLogin)
	{
		return;
	}

	FosSdk_ImageCmd(m_hFos, FOSIMAGE_DEFALUT, 0, 500);	
}


void CsdkDemoDlg::OnBnClickedButton12()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if (!m_hFos || !m_bLogin)
	{
		return;
	}


	FosSdk_OpenAudio(m_hFos, FOSSTREAM_MAIN, 500);
}


void CsdkDemoDlg::OnBnClickedButton13()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if (!m_hFos || !m_bLogin)
	{
		return;
	}
	FOSCMD_RESULT ret = FosSdk_OpenTalk(m_hFos, 500);
	if ( FOSCMDRET_OK == ret )
	{
		RestartRecDev(m_hAudioIn);
	}
	else if ( FOSCMDRET_EXCEEDMAXUSR == ret )
	{
		MessageBox("�Խ��ѱ������û�ռ�ã�����");
	}
}


void CsdkDemoDlg::OnBnClickedButton19()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 	if (m_hThread)
// 	{
// 		m_hThreadRun = false;
// 		if (WaitForSingleObject(m_hThread, 5000) == WAIT_TIMEOUT)
// 		{
// 			TerminateThread(m_hThread, 0);
// 			CloseHandle(m_hThread);
// 			m_hThread = NULL;
// 		}
// 		m_hThread = NULL;
// 	}
// 	if (!m_hFos || !m_bLogin)
// 	{
// 		return;
// 	}


	FOSCMD_RESULT ret = FosSdk_CloseVideo(m_hFos, 500);
	if (ret != FOSCMDRET_OK)
	{
		MessageBox("�ر���Ƶʧ�ܣ�");
	}
}


void CsdkDemoDlg::OnBnClickedButton20()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if (!m_hFos || !m_bLogin)
	{
		return;
	}


	FosSdk_CloseAudio(m_hFos, 500);
}


void CsdkDemoDlg::OnBnClickedButton21()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if (!m_hFos || !m_bLogin)
	{
		return;
	}


	FOSCMD_RESULT ret = FosSdk_CloseTalk(m_hFos, 500);
	if (ret == FOSCMDRET_OK)
	{
		StopRecDev(m_hAudioIn);
	}
}


void CsdkDemoDlg::OnBnClickedButton22()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString str;
	GetDlgItem(IDC_EDIT1)->GetWindowText(str);
	char ip[128];
	int port;
	char usr[32];
	char pwd[32];
	char uid[32];
	FOSIPC_CONNECTTION_TYPE connectType = FOSCNTYPE_IP;
	if (sscanf(str.GetBuffer(), "%[^:]:%d/%[^:]:%s", ip, &port, usr, pwd) == 4)
	{
		connectType = FOSCNTYPE_IP;
	}
	else if (sscanf(str.GetBuffer(), "%[^/]/%[^:]:%s", uid , usr, pwd) == 3)
	{
		connectType = FOSCNTYPE_P2P;	
	}
	else
	{
		return;
	}
	//
	//EZH9AK4ETXAZGHPMSRDJ
	//DFJTA1RY8WUF8G6PSZYS
	m_hFos = FosSdk_Create(ip, uid, usr, pwd, port, port, FOSIPC_H264, connectType);
	//m_hFos = FosSdk_Create2("","", uid, usr, "", port, port,port,port,"", FOSIPC_H264, connectType);
	int usrRight = 0;
	FOSCMD_RESULT rst = FosSdk_Login(m_hFos, &usrRight, 1000);
	if (rst != FOSCMDRET_OK)
	{
		switch(rst)
		{
		case FOSCMDRET_FAILD:
			AfxMessageBox("��½ʧ��");
			break;
		case FOSCMDRET_TIMEOUT:
			AfxMessageBox("��ʱ");
			break;
		case FOSUSRRET_USRNAMEORPWD_ERR:
			AfxMessageBox("�û��������벻ƥ��");
			break;
		case FOSCMDRET_ACCESSDENY:
			AfxMessageBox("�ܾ�����");
			break;
		case FOSCMDRET_EXCEEDMAXUSR:
			AfxMessageBox("��������û���");
			break;
		case FOSCMDRET_USRNOTEXIST:
			AfxMessageBox("�û�������");
			break;
		}
		FosSdk_Release(m_hFos);
		m_hFos = NULL;
		return;
	}

	m_bLogin = true;
	if (m_hThread)
	{
		m_hThreadRun = false;
		if (WaitForSingleObject(m_hThread, 5000) == WAIT_TIMEOUT)
		{
			TerminateThread(m_hThread, 0);
			CloseHandle(m_hThread);
			m_hThread = NULL;
		}
	}
	if (m_hAudioThread)
	{
		m_hAudioThreadRun = false;
		if (WaitForSingleObject(m_hAudioThread, 5000) == WAIT_TIMEOUT)
		{
			TerminateThread(m_hAudioThread, 0);
			CloseHandle(m_hAudioThread);
			m_hAudioThread = NULL;
		}
	}
	
	if (rst == FOSCMDRET_OK)
	{
		m_hThreadRun = true;

		m_hThread = CreateThread(NULL, NULL, ThreadRun, this, NULL, NULL);

		m_hAudioThreadRun = true;


		m_hAudioThread = CreateThread(NULL, NULL, AudioThreadRun, this, NULL, NULL);
		EnumChildWindows(GetSafeHwnd(), ChildWndProc, TRUE);
		GetDlgItem(IDC_BUTTON22)->EnableWindow(FALSE);
	}
	OnBnClickedButton11();
}


void CsdkDemoDlg::OnBnClickedButton23()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_hFos == NULL)
	{
		AfxMessageBox("���ȴ�����");
	}
	char raw[1024];
	int rawLen = 1024;
	CString cgi;
	GetDlgItem(IDC_EDIT2)->GetWindowText(cgi);
	if ( FOSCMDRET_OK == FosSdk_CallCGIRaw(m_hFos, cgi.GetBuffer(), raw, &rawLen, 500) )
	{
		GetDlgItem(IDC_RICHEDIT21)->SetWindowText(raw);
	}

}


void CsdkDemoDlg::OnBnClickedButton10()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int len = 0;
	FosSdk_CallCGIRaw(m_hFos, "cmd=ptzStartCruise&mapName=Vertical", NULL, &len, 500);
}


void CsdkDemoDlg::OnBnClickedButton9()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int len = 0;
	FosSdk_CallCGIRaw(m_hFos, "cmd=ptzStartCruise&mapName=Horizontal", NULL, &len, 500);
}


char* net_num2ip(unsigned long& num)
{
	struct in_addr inaddr;  
	inaddr.s_addr = num;
	return inet_ntoa(inaddr);  
}

void CsdkDemoDlg::OnBnClickedButton24()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FOSDISCOVERY_NODE node[50];
	int size = 50;
	FosSdk_Discovery(node, &size, 500);
	if (size > 0)
	{
		CString str;
		str.Format("��������IPC�豸������%d\n",size);
		for (int i=0; i<size;i++)
		{
			unsigned long ip = node[i].ip;
			CString n = net_num2ip(ip);
			if (node[i].uid[0] == 0)
			{
				n += "   mac(";
				n += node[i].mac;
				n += ")\r\n";
				str += n;
			}
			else{
				n += "  (";
				n += node[i].uid;
				n += ")  mac(";
				n += node[i].mac;
				n += ")\r\n";
				str += n;
			}
			
		}
		GetDlgItem(IDC_RICHEDIT23)->SetWindowText(str);
	}
}



void CsdkDemoDlg::OnBnClickedButtonStartrecord()
{
	int ret = 0;
	ret = FosSdk_StartRecord(m_hFos, FOSRDTYPE_AVI,"./test1018.avi");
	if (0 == ret)
	{
		AfxMessageBox("¼�����ɹ�!\n");
	}
	if (1 == ret)
	{
		AfxMessageBox("¼����ʧ��!\n");
	}

	//FosSdk_StartRecord(m_hFos,FOSCNTYPE_PS,"pstest.mpg");

}


void CsdkDemoDlg::OnBnClickedButtonStoprecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	ret = FosSdk_StopRecord(m_hFos);
	if (0 == ret)
	{
		AfxMessageBox("¼��رճɹ�!\n");
	}
	if (1 == ret)
	{
		AfxMessageBox("¼��ر�ʧ��!\n");
	}
}


void CsdkDemoDlg::OnBnClickedButton25()
{
	// TODO: �ڴ����ӿؼ�֪ͨ���������
	int outLen = 0;
	char buffer[512*1024] = {0};
	FOS_GetSnapFileNewMsg fileInfo = {0};
	fileInfo.snapPicId = 1388605945;
	fileInfo.snapPicIdxOfArray = 16;
	int ret = FosSdk_SnapFileNew(m_hFos, 3000, buffer, 512*1024, &outLen, &fileInfo);
	printf("len = %d\n", outLen);
	char m_SnapefilePath[31] = "d:/test/";
	if (m_SnapefilePath)
	{
		char *tempStr = buffer;
		FOS_NEWSNAPPARAMINFO* snapinfo = (FOS_NEWSNAPPARAMINFO*)tempStr;
		tempStr = tempStr+sizeof(FOS_NEWSNAPPARAMINFO);
		for (int i = 0;i < snapinfo->snapPicNum; i++)
		{
			FOS_NEWSNAPPICINFO  *picInfo = (FOS_NEWSNAPPICINFO*)tempStr;
			char dirTemp[256] = {0};
			sprintf(dirTemp, "%s%s",m_SnapefilePath, picInfo->snapPicName);
			FILE *fp = fopen(dirTemp,"ab+");
			if (fp)
			{
				fwrite(picInfo->data, picInfo->snapPicSize , 1, fp);
			}
			if (fp)
			{
				fclose(fp);
			}
			tempStr = tempStr + picInfo->snapPicSize + sizeof(FOS_NEWSNAPPICINFO);
		}		
	}
	

	/*
	char *buffer=new char[1024*512];
	int bufferSize = 1024*512;
	//FOSCMD_RESULT ret = FosSdk_DecSnapScale(m_hFos,buffer,&bufferSize,320,240,FOSDECTYPE_MJPEG);
	FOSCMD_RESULT ret = FosSdk_NetSnapScale(m_hFos,500,buffer,&bufferSize,640,480,FOSDECTYPE_MJPEG);
	if (ret == FOSCMDRET_OK)
	{
		FILE *pf=fopen("c://snap1.jpeg","w+b");
		if (NULL != pf)
		{
			fwrite(buffer,1,bufferSize,pf);
			fclose(pf);
		}
	}
	ret = FosSdk_DecSnapPic(m_hFos,"c://snap.jpeg");
	ret = FosSdk_NetSnapPicture(m_hFos,5000,"c://netsnap.jpeg");

	int dataSize = 0;
	bufferSize = 1024*512;
	{
		FILE *pf=fopen("c://netsnap.jpeg","rb");
		if (NULL != pf)
		{
			dataSize = fread(buffer,1,bufferSize,pf);
			fclose(pf);
		}
	}
	ret = FosSdk_LocalScalePicture(NULL, dataSize, 640, 480, FOSDECTYPE_MJPEG, buffer, &bufferSize);
	if (ret == FOSCMDRET_OK)
	{
		FILE *pf=fopen("c://localScalePicture.jpeg","w+b");
		if (NULL != pf)
		{
			fwrite(buffer,1,bufferSize,pf);
			fclose(pf);
		}
	}

	delete []buffer;
	*/
}


void CsdkDemoDlg::OnBnClickedBtnopenpb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_videoPlayMode == VIDEO_PLAYMODE_LIVEVIEW)
	{
		OnBnClickedButton19();
		Sleep(200);
	}
	m_videoPlayMode = VIDEO_PLAYMODE_PLAYBACK;
	FOSCMD_RESULT ret = FosSdk_OpenPBVideo(m_hFos,0,"20150131/20150131_223344/schedule_20150131_223344.avi",500);
	if (ret != FOSCMDRET_OK)
	{
		MessageBox("�򿪻ط���Ƶʧ�ܣ�");
	}
}

void CsdkDemoDlg::OnBnClickedBtnclosepb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	FOSCMD_RESULT ret = FosSdk_ClosePBVideo(m_hFos, 500);
	if (ret != FOSCMDRET_OK)
	{
		MessageBox("�رջط���Ƶʧ�ܣ�");
	}
}


void CsdkDemoDlg::OnBnClickedBtnseekforward()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FosSdk_SeekPBVideo(m_hFos,8000,500);
}


void CsdkDemoDlg::OnBnClickedBtnseekback()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FosSdk_SeekPBVideo(m_hFos,10,500);
}


void CsdkDemoDlg::OnBnClickedBtnpbpause()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FosSdk_PausePBVideo(m_hFos,500);
}


void CsdkDemoDlg::OnBnClickedBtnpbresume()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	FosSdk_ResumePBVideo(m_hFos,500);
}
