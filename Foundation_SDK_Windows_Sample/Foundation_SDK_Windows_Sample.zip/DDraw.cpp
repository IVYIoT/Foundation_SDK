#include "StdAfx.h"
#include "DDraw.h"

CDDraw::CDDraw(void)
: m_height(0)
, m_widht(0)
{
	lpDD = NULL;
	lpDDSBack = NULL;
	lpDDSFront = NULL;
	lpClipper = NULL;
}

CDDraw::~CDDraw(void)
{
	SafeRelease(lpDDSBack);
	SafeRelease(lpClipper);
	SafeRelease(lpDDSFront);
	SafeRelease(lpDD);
}

// �ָ���ʧ��DDraw����
HRESULT CDDraw::RestoreDDraw(void)
{
	HRESULT ddrval = DD_OK; 
	if(lpDDSFront)
	{
		ddrval = lpDDSFront->Restore();
		if(ddrval==DD_OK)
		{
			if(lpDDSBack)
			{
				ddrval = lpDDSBack->Restore();
			}
		}
	}
	return ddrval;
}

HRESULT CDDraw::RestoreAllSurfaces()
{
	HRESULT ddrval = DD_FALSE; 
	if(lpDD)
	{
		ddrval = lpDD->RestoreAllSurfaces();
	}
	return ddrval;
}

//********************************************
//���ܣ�����
//������Ŀ����棬��ɫֵ
void CDDraw::Clrscr(LPDIRECTDRAWSURFACE7 surf,WORD color )
{
	DDBLTFX ddbltfx;
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=color;
	surf->Blt(NULL,NULL,NULL,DDBLT_COLORFILL,&ddbltfx);
}

void CDDraw::DrawRect(DWORD color, LPRECT rt, LPDIRECTDRAWSURFACE7 lpDDSO){
	DDBLTFX ddbltfx; 
	ddbltfx.dwSize = sizeof(ddbltfx); 
	ddbltfx.dwFillColor = color;
	lpDDSO->Blt(rt, NULL, NULL, DDBLT_COLORFILL| DDBLT_WAIT, &ddbltfx); 
}

void CDDraw::DrawRect(DWORD color, int sx, int sy, int ex, int ey, LPDIRECTDRAWSURFACE7 lpDDSO){
	RECT rt;
	rt.left = sx;
	rt.top = sy;
	rt.right = ex;
	rt.bottom = ey;
	DrawRect(color, &rt, lpDDSO);
}

bool CDDraw::InitDDraw7(HWND hWnd, int width, int height)
{
	DWORD dwFlags;
	HRESULT ddrval;
	DDSURFACEDESC2 ddsd;//����ṹ
	DDSCAPS2             ddscaps;
	ddrval = DirectDrawCreateEx(NULL,(void **)&lpDD,IID_IDirectDraw7,NULL);//����DD7����
	if (ddrval != DD_OK)
	{
		return (false);
	}
	//����Э������Ϊȫ��ģʽ
	dwFlags = DDSCL_NORMAL;;
	lpDD->SetCooperativeLevel(hWnd, dwFlags);	

	// ����������	
	ZeroMemory( &ddsd , sizeof(ddsd) );
	ddsd.dwSize = sizeof( ddsd );
	ddsd.dwFlags = DDSD_CAPS;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
	ddrval=lpDD->CreateSurface( &ddsd, &lpDDSFront, NULL );
	if(ddrval != DD_OK)
	{
		return(false);
	}

	//���������
	/*ZeroMemory( &ddscaps , sizeof(ddscaps) );
	ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;    
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth = width;
	ddsd.dwHeight = height;
	lpDD->CreateSurface( &ddsd, &lpDDSBack, NULL );
	if(ddrval != DD_OK)
	{
		return(false);
	}

	//
	m_hWnd = hWnd;
	m_height = height;
	m_widht = width;
	DrawRect(0xFFFF0000, 0, 0, width, height, lpDDSBack);*/

	m_hWnd = hWnd;
	return true;
}

bool CDDraw::IsDDrawCreate()
{
	return lpDD != NULL;
}

LPDIRECTDRAWSURFACE7 CDDraw::CreatEmptySurface(int w , int h)
{
	DDSURFACEDESC2	        ddsd;
	LPDIRECTDRAWSURFACE7   lpDDSO;
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS|DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY /*| DDSCAPS_SYSTEMMEMORY | DDSCAPS_VIDEOMEMORY*/; 
	ddsd.dwWidth = w; 
	ddsd.dwHeight = h;

	if (FAILED(lpDD->CreateSurface(&ddsd,&lpDDSO,NULL)))
	{
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY /*| DDSCAPS_VIDEOMEMORY*/; 
		if (!FAILED(lpDD->CreateSurface(&ddsd,&lpDDSO,NULL)))
		{
			return lpDDSO;
		}
		return NULL;
	}
	return lpDDSO;
}

LPDIRECTDRAWSURFACE7 CDDraw::CreatOverlaySurface(int w , int h)
{
	DDSURFACEDESC2	        ddsd;
	LPDIRECTDRAWSURFACE7   lpDDSO;
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);

	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_VIDEOMEMORY | DDSCAPS_OFFSCREENPLAIN ;
	ddsd.dwWidth = w; 
	ddsd.dwHeight = h;

	int i = 0;
	HRESULT   hRet;
	do 
	{
		ddsd.ddpfPixelFormat = ddpfOverlayFormats[i];
		hRet = lpDD->CreateSurface(&ddsd, &lpDDSO, NULL);
	} while (hRet != DD_OK && (++i < PF_TABLE_SIZE));

	if (hRet != DD_OK)
	{
		return NULL;
	}
	return lpDDSO;
}

void CDDraw::ReleaseDDraw(void)
{
	if (lpDD != NULL)
	{

		if (lpDDSBack != NULL)
		{
			lpDDSBack->Release();
			lpDDSBack = NULL;
		}
		if (lpDDSFront != NULL)
		{
			lpDDSFront->Release();
			lpDDSFront = NULL;
		}
		if (lpClipper)
		{
			lpClipper->Release();
			lpClipper = NULL;
		}

		lpDD->Release();
		lpDD = NULL;		
	}
}

bool CDDraw::CreateClipper(HWND hWnd){
	//����Clipper�ü���
	lpDD->CreateClipper(0, &lpClipper, NULL);
	lpClipper->SetHWnd(0, hWnd);
	HRESULT ddrval = lpDDSFront->SetClipper(lpClipper);
	if(ddrval != DD_OK)
	{
		return(false);
	}
	return true;
}

int CDDraw::SetDDSPointColor(LPDIRECTDRAWSURFACE7	lpDDSO, DWORD color){
	HRESULT ddrval;
	DDSURFACEDESC2 LockedSurface;
	ZeroMemory(&LockedSurface, sizeof(DDSURFACEDESC2));
	LockedSurface.dwSize   =   sizeof(LockedSurface);
	LPDWORD LockedSurfaceMemory;

	ddrval = lpDDSO->Lock(NULL, &LockedSurface, DDLOCK_WAIT |  DDLOCK_SURFACEMEMORYPTR, NULL);  
	if(ddrval != DD_OK)
	{
		return 1;
	}

	LockedSurfaceMemory = (LPDWORD)LockedSurface.lpSurface;//�õ�����ָ��

	*(LockedSurfaceMemory)=color;
	ddrval = lpDDSO->Unlock(NULL);
	if(ddrval != DD_OK){
		return 2;
	}
	return 0;
}

void CDDraw::DrawText(LPDIRECTDRAWSURFACE7 lpDDSo,int x, int y, LPCTSTR str, COLORREF textcolor, int fontheight, int fontwidth)
{		
	HDC hdc;
	HFONT font;
	font = CreateFont(fontheight, fontwidth, 0, 0, FW_NORMAL, FALSE, FALSE,FALSE,ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_SWISS, "Garamond");

	lpDDSo->GetDC(&hdc);
	SelectObject(hdc , font);   
	//SetBkMode(hdc, TRANSPARENT);
	SetBkColor(hdc, RGB(0,0,0));
	SetTextColor(hdc, textcolor); 
	TextOut(hdc, x, y, str, strlen(str));
	//DeleteObject(font);
	if (!DeleteObject(font))
	{
		//MYDEBUG_ERROR("DeleteObject() error, error code:%d\n", GetLastError());
	}
	lpDDSo->ReleaseDC(hdc);	
}

LPDIRECTDRAWSURFACE7 CDDraw::MyLoadBitmap(HBITMAP hbm,//λͼ�ļ���
										  int W,//���͸�
										  int H)
{
	HDC						hMemDC;
	HDC						hSODC;
	DDSURFACEDESC2	        ddsd;
	LPDIRECTDRAWSURFACE7   lpDDSO;

	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS|DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY/* | DDSCAPS_VIDEOMEMORY*/; 
	ddsd.dwWidth = W; 
	ddsd.dwHeight = H;

	if (FAILED(lpDD->CreateSurface(&ddsd,&lpDDSO,NULL)))
	{
		return NULL;
	}

	hMemDC=CreateCompatibleDC(NULL);
	if (hbm == NULL)
	{
		return NULL;
	}
	SelectObject(hMemDC,hbm);

	lpDDSO->GetDC(&hSODC);
	BOOL b = BitBlt(hSODC,0,0,W,H,hMemDC,0,0,SRCCOPY);//��λͼ���Ƶ�����ҳ��

	DeleteDC(hMemDC);
	lpDDSO->ReleaseDC(hSODC);

	MySetColorKey(lpDDSO);
	return lpDDSO;
}

void CDDraw::MySetColorKey(LPDIRECTDRAWSURFACE7 lpDDSO)
{
	DDCOLORKEY ddck;
	ddck.dwColorSpaceHighValue = 0;
	ddck.dwColorSpaceLowValue = 0;//���ùؼ�ɫ
	lpDDSO->SetColorKey(DDCKEY_SRCBLT, &ddck);
}

HRESULT CDDraw::PlayYUV(BYTE* y, BYTE* u, BYTE* v, LPDIRECTDRAWSURFACE7 lpDDSView, int w, int h, int dataStrip)
{
	if (lpDDSView == NULL) return DD_FALSE;
	DDSURFACEDESC2 LockedSurface;
	ZeroMemory(&LockedSurface, sizeof(DDSURFACEDESC2));
	LockedSurface.dwSize   =   sizeof(LockedSurface);

	HRESULT hRet = lpDDSView->Lock(NULL, &LockedSurface, DDLOCK_WAIT, NULL);  
	if (FAILED(hRet))
		return hRet;
	if (h != LockedSurface.dwHeight || w != LockedSurface.dwWidth)
	{
		lpDDSView->Unlock(NULL);
		return DD_FALSE;
	}

	LPBYTE lpSurf = (LPBYTE)LockedSurface.lpSurface;
	if(lpSurf) {
		int i;
		// fill Y data
		for(i = 0; i < h; i++)
		{
			memcpy(lpSurf, y, w);
			y += dataStrip;
			lpSurf += LockedSurface.lPitch;
		}

		// fill V data
		for(i = 0; i < h / 2; i++)
		{
			memcpy(lpSurf, v, w / 2);
			v += dataStrip / 2;
			lpSurf += LockedSurface.lPitch / 2;
		}

		// fill U data
		for(i = 0; i < h / 2; i++)
		{
			memcpy(lpSurf, u, w / 2);
			u += dataStrip / 2;
			lpSurf += LockedSurface.lPitch / 2;
		}
	}

	lpDDSView->Unlock(NULL);
	return DD_OK;
}

void CDDraw::Flip(LPDIRECTDRAWSURFACE7 lpDDSView)
{
	RECT dst;
	GetWindowRect(m_hWnd, &dst);
	HRESULT hr = lpDDSFront->Blt(&dst, lpDDSView, NULL, DDBLT_WAIT, NULL);
	//HRESULT hr = lpDDSFront->Blt(NULL, lpDDSView, NULL, DDBLT_WAIT, NULL);
	if(hr != DD_OK) {
		if (hr == DDERR_SURFACELOST){
			lpDD->RestoreAllSurfaces();
		}
	}
}

void CDDraw::FlipFast(LPDIRECTDRAWSURFACE7 lpDDSView)
{
	RECT src;
	GetWindowRect(m_hWnd, &src);
	HRESULT hr = lpDDSFront->Blt(NULL, lpDDSView, &src, DDBLT_WAIT, NULL);
	//HRESULT hr = lpDDSFront->Blt(NULL, lpDDSView, NULL, DDBLT_WAIT, NULL);
	if(hr != DD_OK) {
		if (hr == DDERR_SURFACELOST){
			lpDD->RestoreAllSurfaces();
		}
	}
}

void CDDraw::FlipRect(LPDIRECTDRAWSURFACE7 lpDDSView, RECT* dst, RECT* src)
{
	HRESULT hr = lpDDSFront->Blt(dst, lpDDSView, src, DDBLT_WAIT, NULL);
	if(hr != DD_OK) {
		if (hr == DDERR_SURFACELOST){
			lpDD->RestoreAllSurfaces();
		}
	}
}