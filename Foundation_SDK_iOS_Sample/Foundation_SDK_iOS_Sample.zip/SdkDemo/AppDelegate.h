//
//  AppDelegate.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/18.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

