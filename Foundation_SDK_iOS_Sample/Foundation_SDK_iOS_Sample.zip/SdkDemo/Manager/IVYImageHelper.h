//
//  IVYImageHelper.h
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IVYImageHelper : NSObject

+ (UIImage *)displayImage:(CVImageBufferRef)imageBuffer;

+ (UIImage *)imageFromAVPicture:(char*)data width:(int)width height:(int)height;

@end

NS_ASSUME_NONNULL_END
