//
//  GlobalData.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "GlobalData.h"

@implementation GlobalData

+ (GlobalData *)shared {
    static GlobalData *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[GlobalData alloc] init];
    });
    return shared;
}

- (instancetype)init {
    if (self = [super init]) {
        [self initializer];
    }
    return self;
}

- (void)initializer {
    NSMutableArray *mutableArray = [NSMutableArray new];
    
    {
        NSString *deviceUID = @"";
        NSString *username = @"";
        NSString *password = @"";
        Camera *obj = [[Camera alloc] initWithDeviceUID:deviceUID username:username password:password];
        obj.deviceType = IVYDeviceIVY;
        
        [mutableArray addObject:obj];
        
        [obj loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
            
        }];
    }
    
    {
        NSString *deviceUID = kDeviceUID;
        NSString *username = kUsername;
        NSString *password = kPassword;
        Camera *obj = [[Camera alloc] initWithDeviceUID:deviceUID username:username password:password];
        obj.deviceType = IVYDeviceFOS;
        
        [mutableArray addObject:obj];
        
        [obj loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
            
        }];
    }
    
    _dataSource = [mutableArray copy];
}

@end
