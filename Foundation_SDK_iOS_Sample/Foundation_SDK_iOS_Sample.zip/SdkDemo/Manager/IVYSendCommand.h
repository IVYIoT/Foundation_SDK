//
//  IVYSendCommand.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^IVYCGIResponse)(NSDictionary *response, IVYIO_RESULT cgiResult);

@interface IVYSendCommand : NSObject

+ (IVYSendCommand *)shared;

/// 执行CGI命令
/// @param handle 句柄
/// @param cgiCommand CGI命令
/// @param parameters 参数
/// @param iTimeout 超时时间
/// @param resultBlock 结果回掉
- (void)sendCommand:(IVYHANDLE)handle cgiCommand:(int)cgiCommand parameters:(NSDictionary *)parameters iTimeout:(int)iTimeout onCompletion:(IVYCGIResponse)resultBlock;

@end

NS_ASSUME_NONNULL_END
