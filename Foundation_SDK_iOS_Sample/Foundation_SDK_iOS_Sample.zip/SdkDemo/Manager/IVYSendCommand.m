//
//  IVYSendCommand.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYSendCommand.h"

static int const kSizeOfResponse = 5 * 1024;

static dispatch_queue_t ivy_cgi_queue() {
    static dispatch_queue_t queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        queue = dispatch_queue_create("io.ivyiot.IVYSendCommand.Queue", DISPATCH_QUEUE_CONCURRENT);
    });
    return queue;
}


static NSDictionary * Inner_SendCommand(IVYIO_HANDLE handle, int cmd, NSDictionary *params, int iTimeout, IVYIO_RESULT *cmdResult, int *iSizeOfResponse) {
    NSData *data = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    
    unsigned char *cmdData = (unsigned char *)[data bytes];
    int iSizeOfCmdData = (int)data.length;
    
    unsigned char response[kSizeOfResponse] = { 0 };
    *iSizeOfResponse = kSizeOfResponse;
    *cmdResult = IVYIO_SendCommand(handle, cmd, cmdData, iSizeOfCmdData, response, iSizeOfResponse, iTimeout);
    
    if (IVYIO_RESULT_OK != *cmdResult || iSizeOfResponse <= 0) {
        return nil;
    }
    
    NSData *responseData = [NSData dataWithBytes:response length:*iSizeOfResponse];
    NSError *error = nil;
    NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&error];
    
    if (nil != error || nil == responseDict) {
        return nil;
    }
    
    return responseDict;
}

static NSDictionary * IVYSdk_SendCommand(IVYIO_HANDLE handle, int cmd, NSDictionary *params, int iTimeout, IVYIO_RESULT *cmdResult) {
    int iSizeOfResponse = 0;
    
    CFAbsoluteTime st = CFAbsoluteTimeGetCurrent();
    NSDictionary *response = Inner_SendCommand(handle, cmd, params, iTimeout, cmdResult, &iSizeOfResponse);
    CFAbsoluteTime interval = CFAbsoluteTimeGetCurrent() - st;
    
    if (*cmdResult == IVYIO_RESULT_OK) {
        *cmdResult = [response[@"ret"] intValue];
    }
    
    IVYLog(@"... IvySdk_SendCommand handle:%@ cmd:%@ cmdResult:%@ params:%@ interval:%@ iTimeout:%@ iSizeOfResponse:%@ responseDict:%@", @(handle), @(cmd), @(*cmdResult), params, @(interval), @(iTimeout), @(iSizeOfResponse), response);
    
    return response;
}

@implementation IVYSendCommand

+ (IVYSendCommand *)shared {
    static IVYSendCommand *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[IVYSendCommand alloc] init];
    });
    return manager;
}

- (void)sendCommand:(IVYHANDLE)handle cgiCommand:(int)cgiCommand parameters:(NSDictionary *)parameters iTimeout:(int)iTimeout onCompletion:(IVYCGIResponse)resultBlock {
    dispatch_async(ivy_cgi_queue(), ^{
        IVYIO_RESULT cmdResult;
        NSDictionary *response = IVYSdk_SendCommand(handle, cgiCommand, parameters, iTimeout, &cmdResult);
        
        if (resultBlock) {
            dispatch_async(dispatch_get_main_queue(), ^{
                resultBlock(response, cmdResult);
            });
        }
    });
}

@end
