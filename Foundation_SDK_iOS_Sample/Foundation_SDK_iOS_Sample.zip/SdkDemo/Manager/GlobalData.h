//
//  GlobalData.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"
#import "Camera.h"

NS_ASSUME_NONNULL_BEGIN

@interface GlobalData : NSObject

+ (GlobalData *)shared;

@property (nonatomic, strong) NSArray<Camera *> *dataSource;

@end

NS_ASSUME_NONNULL_END
