//
//  IVYNavigationController.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYNavigationController.h"

@interface IVYNavigationController ()

@end

@implementation IVYNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
