//
//  IVYViewController.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

@interface IVYViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
