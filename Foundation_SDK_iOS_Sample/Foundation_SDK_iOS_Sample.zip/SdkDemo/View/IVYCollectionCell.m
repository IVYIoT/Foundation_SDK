//
//  IVYCollectionCell.m
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYCollectionCell.h"
#import "UIImage+IVY.h"
#import "IVYConstant.h"
#import "UIButton+IVY.h"
#import "Masonry.h"

@interface IVYCollectionCell ()

@property (nonatomic, strong) UIButton *button;

@end

@implementation IVYCollectionCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initializer];
    }
    return self;
}

- (void)initializer {
    [self addSubview:self.button];
    [self.button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
}

- (void)setTitle:(NSString *)title {
    [self.button setTitle:title forState:UIControlStateNormal];
}

- (void)buttonTapped:(UIButton *)sender {
    if ([_delegate respondsToSelector:@selector(ivyCollectionCell:didTapAtIndexPath:)]) {
        [_delegate ivyCollectionCell:self didTapAtIndexPath:self.indexPath];
    }
}

- (UIButton *)button {
    if (!_button) {
        _button = [UIButton ivy_button];
        [_button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}

@end
