//
//  IVYControl.m
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYControl.h"
#import "IVYCollectionCell.h"
#import "Masonry.h"

static NSString * const kCellID = @"CellID";
static NSInteger const kItemsInLine = 4;
static CGFloat const kSpacing = 4.f;

@interface IVYControl () <UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, IVYCollectionCellDelegate>

@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;

@property (nonatomic, strong) UICollectionView *collectionView;

@end

@implementation IVYControl

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initializer];
    }
    return self;
}

- (void)initializer {
    self.collectionView.backgroundColor = [UIColor whiteColor];
    
    [self addSubview:self.collectionView];
    
    UIEdgeInsets padding = UIEdgeInsetsMake(10, 10, 0, 10);
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.insets(padding);
    }];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellID forIndexPath:indexPath];
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    
    IVYCModel *model = self.dataSource[indexPath.row];
    
    IVYCollectionCell *thisCell = (IVYCollectionCell *)cell;
    thisCell.delegate = self;
    thisCell.indexPath = indexPath;
    thisCell.title = model.title;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    [collectionView reloadData];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat itemWidth = (CGRectGetWidth(collectionView.frame) - (kItemsInLine + 1) * kSpacing - 20) / kItemsInLine;
    CGSize itemSize = CGSizeMake(itemWidth, itemWidth * 0.618);
    return itemSize;
}

#pragma mark - IVYCollectionCellDelegate
- (void)ivyCollectionCell:(IVYCollectionCell *)cell didTapAtIndexPath:(NSIndexPath *)indexPath {
    IVYCModel *model = self.dataSource[indexPath.row];

    if ([_delegate respondsToSelector:@selector(ivyControl:didTapItemTag:)]) {
        [_delegate ivyControl:self didTapItemTag:model.tag];
    }
}

#pragma mark - Getter && Setter
- (UICollectionViewFlowLayout *)flowLayout {
    if (!_flowLayout) {
        _flowLayout = [UICollectionViewFlowLayout new];
        _flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        _flowLayout.minimumLineSpacing = kSpacing * 4;
        _flowLayout.minimumInteritemSpacing = kSpacing;
    }
    return _flowLayout;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:self.flowLayout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[IVYCollectionCell class] forCellWithReuseIdentifier:kCellID];
    }
    return _collectionView;
}

@end
