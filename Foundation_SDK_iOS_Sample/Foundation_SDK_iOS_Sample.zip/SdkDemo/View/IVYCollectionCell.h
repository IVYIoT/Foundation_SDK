//
//  IVYCollectionCell.h
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class IVYCollectionCell;

@protocol IVYCollectionCellDelegate <NSObject>

- (void)ivyCollectionCell:(IVYCollectionCell *)cell didTapAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface IVYCollectionCell : UICollectionViewCell

@property (nonatomic, weak) id<IVYCollectionCellDelegate> delegate;

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) NSString *title;

@end

NS_ASSUME_NONNULL_END
