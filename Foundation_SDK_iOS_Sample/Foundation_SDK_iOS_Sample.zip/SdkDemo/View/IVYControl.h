//
//  IVYControl.h
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IVYCModel.h"
NS_ASSUME_NONNULL_BEGIN

@class IVYControl;

@protocol IVYControlDelegate <NSObject>

- (void)ivyControl:(IVYControl *)ivyControl didTapItemTag:(NSInteger)tag;

@end

@interface IVYControl : UIView

@property (nonatomic, weak) id<IVYControlDelegate> delegate;

@property (nonatomic, strong) NSArray<IVYCModel *> *dataSource;

@end

NS_ASSUME_NONNULL_END
