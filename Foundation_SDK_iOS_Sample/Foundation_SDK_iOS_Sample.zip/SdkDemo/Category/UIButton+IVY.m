//
//  UIButton+IVY.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "UIButton+IVY.h"
#import "IVYConstant.h"
#import "UIImage+IVY.h"

@implementation UIButton (IVY)

+ (UIButton *)ivy_button {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.layer.cornerRadius = 8;
    button.layer.masksToBounds = YES;
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button setTitleColor:RGBCOLOR(81, 91, 88) forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(242, 242, 243)] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(232, 232, 233)] forState:UIControlStateSelected];
    [button setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(232, 180, 180)] forState:UIControlStateHighlighted];
    [button setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(202, 202, 206)] forState:UIControlStateDisabled];
    return button;
}

@end
