//
//  UIImage+IVY.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "UIImage+IVY.h"

@implementation UIImage (IVY)

+ (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0, 0.0, 1.0, 1.0);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, [UIScreen mainScreen].scale);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
