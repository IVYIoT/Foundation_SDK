//
//  NSData+IVY.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "NSData+IVY.h"
#include <CommonCrypto/CommonDigest.h>

@implementation NSData (IVY)

- (NSData *)encryptByAES128WithKey:(NSString *)key options:(uint32_t)options {
    
    char ptrKey[kCCKeySizeAES128 + 1];
    bzero(ptrKey, sizeof(ptrKey));
    [key getCString:ptrKey maxLength:sizeof(ptrKey) encoding:NSUTF8StringEncoding];
    
    size_t dataInLength = self.length;
    size_t bufferSize = dataInLength + kCCKeySizeAES128;
    void *dataOut = malloc(bufferSize);
    
    size_t numBytesEncrypted = 0;
    
    CCCryptorStatus status = CCCrypt(kCCEncrypt,
                                     kCCAlgorithmAES128,
                                     options,
                                     ptrKey,
                                     kCCKeySizeAES128,
                                     NULL,
                                     [self bytes],
                                     dataInLength,
                                     dataOut,
                                     bufferSize,
                                     &numBytesEncrypted
                                     );
    
    if (kCCSuccess == status) {
        return [NSData dataWithBytesNoCopy:dataOut length:numBytesEncrypted];
    } else {
        free(dataOut);
        dataOut = NULL;
        return nil;
    }
}

- (NSString *)hexString {
    Byte *bytes = (Byte *)[self bytes];
    NSMutableString *mutableStr = [NSMutableString new];
    for (NSInteger i = 0; i != [self length]; ++ i) {
        [mutableStr appendFormat:@"%02x", bytes[i]&0xff];
    }
    return [[mutableStr copy] uppercaseString];
}


@end
