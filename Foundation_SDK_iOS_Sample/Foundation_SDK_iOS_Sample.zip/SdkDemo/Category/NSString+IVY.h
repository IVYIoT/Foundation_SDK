//
//  NSString+IVY.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

@interface NSString (IVY)

- (NSString *)base64EncodedToString;

- (NSString *)base64Encoding;

- (NSString *)stringForMD5;

/// 获取设备出厂默认密码类型
- (IVYResetPwdTypes)passwordTypeByUID;

/// 根据设备UID获取对应出厂默认密码
- (NSString *)resetPasswordByDeviceUID;

@end

NS_ASSUME_NONNULL_END
