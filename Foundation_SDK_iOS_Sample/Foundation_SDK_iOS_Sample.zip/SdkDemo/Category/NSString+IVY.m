//
//  NSString+IVY.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "NSString+IVY.h"
#import <CommonCrypto/CommonHMAC.h>
#import "IVYConstant.h"
#import "iCryptoApi.h"

@implementation NSString (IVY)

- (NSString *)base64EncodedToString {
    NSData *data = [[NSData alloc] initWithBase64EncodedString:self options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSString *temp = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return temp;
}

- (NSString *)base64Encoding {
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSString *temp = [data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return temp;
}

- (NSString *)stringForMD5 {
    const char *original_str = [self UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(original_str, (CC_LONG)strlen(original_str), result);
    NSMutableString *hash = [NSMutableString string];
    for (int i = 0; i < 16; i++){
        [hash appendFormat:@"%02x", result[i]];
    }
    
    return [hash lowercaseString];
}

- (IVYResetPwdTypes)passwordTypeByUID {
    IVYResetPwdTypes type;
    
    NSString *regexStr1 = @"^[0-9A-Za-z]{22}+[89AaBb][0-9A-Za-z]$"; // 有感密码
    NSString *regexStr2 = @"^[0-9A-Za-z]{22}+[CcDdEeFf][0-9A-Za-z]$"; // 无感密码
    
    if ([self regexCheck:regexStr1]) {
        type = IVYResetPwdSense;
    } else if ([self regexCheck:regexStr2]) {
        type = IVYResetPwdNoSense;
    } else {
        type = IVYResetPwdEmpty;
    }
    return type;
}

- (NSString *)resetPasswordByDeviceUID {
    NSString *pwd;
    IVYResetPwdTypes type = [self passwordTypeByUID];
    switch (type) {
        case IVYResetPwdEmpty: {
            pwd = kResetPassword;
        }
            break;
            
        case IVYResetPwdSense:
        case IVYResetPwdNoSense: {
            char password[20] = {};
            GeneratePassword(self.UTF8String, password);
            pwd = [NSString stringWithUTF8String:password];
        }
            break;
    }
    return pwd;
}

- (BOOL)regexCheck:(NSString *)regexStr {
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:regexStr options:0 error:&error];
    if (regex == nil) { return NO; }
    
    NSTextCheckingResult *firstMatch = [regex firstMatchInString:self options:0 range:NSMakeRange(0, [self length])];
    return (firstMatch) ? YES : NO;
}

@end
