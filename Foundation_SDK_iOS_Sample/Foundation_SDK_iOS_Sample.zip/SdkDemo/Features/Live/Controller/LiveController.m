//
//  LiveController.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/20.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "LiveController.h"
#import "IVYConstant.h"
#import "FDSDCardController.h"
#import "IDSDCardController.h"
#import "HardwareDecoder.h"
#import "IVYImageHelper.h"
#import "IVYControl.h"
#import "Masonry.h"

static int const kTimeOutMS = 30000;

typedef NS_ENUM(NSInteger, LCICTag) {
    LCICTagSDCard,
};

@interface LiveController () <HardwareDecoderDelegate, IVYControlDelegate>

@property (nonatomic, strong) Camera *camera;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, assign) BOOL running;

@property (nonatomic, strong) dispatch_queue_t queue;

@property (nonatomic, strong) HardwareDecoder *decoder;

@property (nonatomic, assign) IVYStreamDataType type;

@property (nonatomic, strong) IVYControl *ivyControl;

@end

@implementation LiveController

#pragma mark - Lifecycle
- (instancetype)initWithCamera:(Camera *)camera {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _camera = camera;
        _type = IVYStreamDataRaw;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"Live";
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.ivyControl];
    
    [self layoutPageSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self livePlay];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    _running = NO;
    
    [UIApplication sharedApplication].idleTimerDisabled = NO;
}

- (void)layoutPageSubviews {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.equalTo(self.view.mas_width).multipliedBy(9 / 16.f);
    }];
    
    [self.ivyControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom);
        make.left.right.equalTo(self.view);
        make.bottom.offset(-44);
    }];
}

#pragma mark - Private Methods
- (void)livePlay {
    _running = YES;
    
    dispatch_async(self.queue, ^{
        [self openVideo];
    });
    
    dispatch_async(self.queue, ^{
        [self getStreamData];
    });
}

- (IVYIO_RESULT)openVideo {
    IVYHANDLE handle = self.camera.handle;
    
    IVYIO_OPEN_VIDEO_ARGS_TYPE0 type;
    type.openVideoArgsType = 0;
    type.streamType = IVYIO_MAIN_VIDEO_STREAM;
    
    IVYIO_RESULT cmdResult = IVYIO_OpenVideo(handle, &type, kTimeOutMS, 1);
    IVYLog(@"... handle:%@ IVYIO_OpenVideo cmdResult:%@", @(handle), @(cmdResult));
    
    return cmdResult;
}

- (void)getStreamData {
    IVYHANDLE handle = self.camera.handle;
    int iOutLen, mediaSpeed = 0;
    int iDecodeFmt = IVYIO_DEC_TYPE_RGB24;
    IVYIO_FRAME *frame = NULL;
    IVYIO_RESULT cmdResult = IVYIO_RESULT_UNKNOWN;
    
    while (_running) {
        switch (_type) {
            case IVYStreamDataRaw:
                cmdResult = IVYIO_GetRawStreamData(handle, IVYIO_STREAM_VIDEO, (unsigned char **)&frame, &iOutLen, &mediaSpeed, 0);
                break;
                
            case IVYStreamDataDecoded:
                cmdResult = IVYIO_GetStreamData(handle, IVYIO_STREAM_VIDEO, (unsigned char **)&frame, &iOutLen, &mediaSpeed, iDecodeFmt, 0);
                break;
        }
        
        if (IVYIO_RESULT_OK != cmdResult || iOutLen == 0 || IVYIO_STREAM_VIDEO != frame->type) {
            usleep(20 * 1000);
            continue;
        }
        
        switch (_type) {
            case IVYStreamDataRaw: {                
                [self.decoder didReciveFrame:(uint8_t *)frame->data frameSize:frame->len];
            }
                break;
                
            case IVYStreamDataDecoded: {
                UIImage *image = [IVYImageHelper imageFromAVPicture:(char *)frame->data width:frame->media.video.w height:frame->media.video.h];
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.imageView.image = image;
                });
            }
                break;
        }
        
        usleep(10 * 1000);
    }
    
    cmdResult = IVYIO_CloseVideo(handle, kTimeOutMS, 1);
    IVYLog(@"... handle:%@ IVYIO_CloseVideo cmdResult:%@", @(handle), @(cmdResult));
}

#pragma mark - HardwareDecoderDelegate
- (void)hardwareDecoder:(HardwareDecoder *)decoder didDecodeFrame:(CVImageBufferRef)imageBuffer {
    UIImage *image = [IVYImageHelper displayImage:imageBuffer];
    dispatch_async(dispatch_get_main_queue(), ^{
        self.imageView.image = image;
    });
}

- (void)hardwareDecoder:(HardwareDecoder *)decoder decoderErrorType:(HardwareDecoderErrorType)errorType errorOSStatus:(OSStatus)status {
    IVYLog(@"### IvyPlayer HardwareDecoder Error errorType:%@ errorOSStatus:%@", @(errorType), @(status));
    _type = IVYStreamDataDecoded;
}

#pragma mark - IVYControlDelegate
- (void)ivyControl:(IVYControl *)ivyControl didTapItemTag:(NSInteger)tag {
    LCICTag thisTag = (LCICTag)tag;
    
    switch (thisTag) {
        case LCICTagSDCard: {
            if (IVYDeviceFOS == self.deviceType) {
                FDSDCardController *vc = [[FDSDCardController alloc] initWithCamera:self.camera];
                [self.navigationController pushViewController:vc animated:YES];
            } else if (IVYDeviceIVY == self.deviceType) {
                IDSDCardController *vc = [[IDSDCardController alloc] initWithCamera:self.camera];
                [self.navigationController pushViewController:vc animated:YES];
            }
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - Getter && Setter
- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.1];
    }
    return _imageView;
}

- (dispatch_queue_t)queue {
    if (!_queue) {
        _queue = dispatch_queue_create("io.ivyiot.Live.Queue", DISPATCH_QUEUE_CONCURRENT);
    }
    return _queue;
}

- (HardwareDecoder *)decoder {
    if (!_decoder) {
        _decoder = [HardwareDecoder new];
        _decoder.delegate = self;
    }
    return _decoder;
}

- (IVYControl *)ivyControl {
    if (!_ivyControl) {
        _ivyControl = [IVYControl new];
        _ivyControl.delegate = self;
        
        NSMutableArray *temp = [NSMutableArray new];
        {
            IVYCModel *obj = [[IVYCModel alloc] initWithTitle:@"SDCard" tag:LCICTagSDCard];
            [temp addObject:obj];
        }
        
        _ivyControl.dataSource = temp.copy;
    }
    return _ivyControl;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
