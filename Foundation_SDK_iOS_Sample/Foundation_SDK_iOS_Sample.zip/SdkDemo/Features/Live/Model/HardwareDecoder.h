//
//  HardwareDecoder.h
//  Foscam
//
//  Created by softwareteam2 on 2017/7/20.
//  Copyright © 2017年 Foscam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VideoToolbox/VideoToolbox.h>

/**
 硬解码错误

 - HardwareDecoderCreateError: 创建解码器失败
 - HardwareDecoderDecodeError: 解码失败
 */
typedef NS_ENUM(NSInteger, HardwareDecoderErrorType) {
    HardwareDecoderCreateError,
    HardwareDecoderDecodeError,
};

@class HardwareDecoder;

@protocol HardwareDecoderDelegate <NSObject>

@required
/**
 硬解码结果

 @param decoder 当前对象
 @param imageBuffer 解码后的数据
 */
- (void)hardwareDecoder:(HardwareDecoder *)decoder didDecodeFrame:(CVImageBufferRef)imageBuffer;

/**
 硬解码错误

 @param decoder 当前对象
 @param errorType 错误类型
 @param status 错误状态码
 */
- (void)hardwareDecoder:(HardwareDecoder *)decoder decoderErrorType:(HardwareDecoderErrorType)errorType errorOSStatus:(OSStatus)status;

@end

@interface HardwareDecoder : NSObject

/**
 代理
 */
@property (nonatomic, weak) id<HardwareDecoderDelegate> delegate;

/**
 收到一帧数据

 @param frame 帧数据
 @param frameSize 帧大小
 */
- (void)didReciveFrame:(uint8_t *)frame frameSize:(uint32_t)frameSize;

/**
 停止解码器
 */
- (void)stop;

@end
