//
//  HardwareDecoder.m
//  Foscam
//
//  Created by softwareteam2 on 2017/7/20.
//  Copyright © 2017年 Foscam. All rights reserved.
//

#import "HardwareDecoder.h"
#import "IVYConstant.h"

static NSString * const naluTypesStrings[] =
{
    @"0: Unspecified (non-VCL)",
    @"1: Coded slice of a non-IDR picture (VCL)",    // P frame
    @"2: Coded slice data partition A (VCL)",
    @"3: Coded slice data partition B (VCL)",
    @"4: Coded slice data partition C (VCL)",
    @"5: Coded slice of an IDR picture (VCL)",      // I frame
    @"6: Supplemental enhancement information (SEI) (non-VCL)",
    @"7: Sequence parameter set (non-VCL)",         // SPS parameter
    @"8: Picture parameter set (non-VCL)",          // PPS parameter
    @"9: Access unit delimiter (non-VCL)",
    @"10: End of sequence (non-VCL)",
    @"11: End of stream (non-VCL)",
    @"12: Filler data (non-VCL)",
    @"13: Sequence parameter set extension (non-VCL)",
    @"14: Prefix NAL unit (non-VCL)",
    @"15: Subset sequence parameter set (non-VCL)",
    @"16: Reserved (non-VCL)",
    @"17: Reserved (non-VCL)",
    @"18: Reserved (non-VCL)",
    @"19: Coded slice of an auxiliary coded picture without partitioning (non-VCL)",
    @"20: Coded slice extension (non-VCL)",
    @"21: Coded slice extension for depth view components (non-VCL)",
    @"22: Reserved (non-VCL)",
    @"23: Reserved (non-VCL)",
    @"24: STAP-A Single-time aggregation packet (non-VCL)",
    @"25: STAP-B Single-time aggregation packet (non-VCL)",
    @"26: MTAP16 Multi-time aggregation packet (non-VCL)",
    @"27: MTAP24 Multi-time aggregation packet (non-VCL)",
    @"28: FU-A Fragmentation unit (non-VCL)",
    @"29: FU-B Fragmentation unit (non-VCL)",
    @"30: Unspecified (non-VCL)",
    @"31: Unspecified (non-VCL)",
};

static void decompressionOutputCallback(void * decompressionOutputRefCon,
                                        void * sourceFrameRefCon,
                                        OSStatus status,
                                        VTDecodeInfoFlags infoFlags,
                                        CVImageBufferRef imageBuffer,
                                        CMTime presentationTimeStamp,
                                        CMTime presentationDuration);

@interface HardwareDecoder ()

@property (nonatomic, assign) CMFormatDescriptionRef formatDesc;

@property (nonatomic, assign) VTDecompressionSessionRef decompressionSession;

@end

@implementation HardwareDecoder

#pragma mark - Lifecycle
- (instancetype)init {
    if (self = [super init]) {
        _formatDesc = nil;
        _decompressionSession = nil;
    }
    return self;
}

#pragma mark - Public Methods
- (void)didReciveFrame:(uint8_t *)frame frameSize:(uint32_t)frameSize {
    
    int spsStart = 0, spsSize = 0;
    int ppsStart = 0, ppsSize = 0;
    int dataStart = 0, dataSize = 0;
    BOOL isIDR = NO;
    OSStatus status = 0;
    
    // 解析码流数据
    [self praseFrame:frame frameSize:frameSize spsStart:&spsStart spsSize:&spsSize ppsStart:&ppsStart ppsSize:&ppsSize dataBegin:&dataStart dataSize:&dataSize isIDR:&isIDR];
    
    // 创建视频描述、解码器
    if (isIDR) {
        // 创建视频描述
        CMFormatDescriptionRef formatDesc = [self createVideoFormatDescription:frame spsStart:spsStart spsSize:spsSize ppsStart:ppsStart ppsSize:ppsSize];
        
        if ((nil != formatDesc) && !CMFormatDescriptionEqual(formatDesc, _formatDesc)) {
            // 释放当前解码器
            [self releaseDecompressionSession];
            
            // 释放当前描述
            [self releaseVideoFormatDescription];
            // 记录当前视频描述
            _formatDesc = formatDesc;
            
            // 创建解码器
            _decompressionSession = [self createDecompressionSession:formatDesc status:&status];
        }
    }
    
    // 解码器异常
    if (NULL == _formatDesc || NULL == _decompressionSession) {
        IVYLog(@"### HardwareDecoder 1 视频描述、解码器异常 Error status:%@", @(status));
        [self decoderErrorType:HardwareDecoderCreateError errorOSStatus:status]; // 解码数据失败，回调
        return ;
    }
    
    // 解码数据
    uint8_t *data = &frame[dataStart];
    [self decodeFrameData:data dataSize:dataSize];
}

- (void)stop {
    [self releaseVideoFormatDescription];
    [self releaseDecompressionSession];
}

#pragma mark - Private Methods
- (void)praseFrame:(uint8_t *)frame frameSize:(uint32_t)frameSize spsStart:(int *)spsStart spsSize:(int *)spsSize ppsStart:(int *)ppsStart ppsSize:(int *)ppsSize dataBegin:(int *)dataBegin dataSize:(int *)dataSize isIDR:(BOOL *)isIDR {
    
    int max = MIN(frameSize, MAX(0, 256));
    int lastPostion = -1;
    for (int i = 0; i != max; ++ i) {
        if (frame[i] == 0x00 && frame[i+1] == 0x00 && frame[i+2] == 0x00 && frame[i+3] == 0x01) {
            int nalu_type = (frame[i + 4] & 0x1F);
            
            if (lastPostion == *spsStart) {
                *spsSize = i - *spsStart;
            } else if (lastPostion == *ppsStart) {
                *ppsSize = i - *ppsStart;
            }
            
            switch (nalu_type) {
                case 1: {
                    *dataBegin = i;
                }
                    break;
                case 5: {
                    *dataBegin = i;
                    *isIDR = YES;
                }
                    break;
                case 7: {
                    *spsStart = i;
                }
                    break;
                case 8: {
                    *ppsStart = i;
                }
                    break;
                
                default:
                    break;
            }
            
            lastPostion = i;
        }
    }
    
    *dataSize = frameSize - *dataBegin;
    
}

- (CMFormatDescriptionRef)createVideoFormatDescription:(uint8_t *)frame spsStart:(int)spsStart spsSize:(int)spsSize ppsStart:(int)ppsStart ppsSize:(int)ppsSize {
    
    uint8_t sps[128] = {0};
    uint8_t pps[128] = {0};
    
    if (spsSize < 4 || ppsSize < 4) {
        return nil;
    }
    
    memcpy(sps, &frame[spsStart + 4], spsSize - 4);
    memcpy(pps, &frame[ppsStart + 4], ppsSize - 4);
    
    uint8_t*  parameterSetPointers[2] = {sps, pps};
    size_t parameterSetSizes[2] = {spsSize-4, ppsSize-4};
    
    CMFormatDescriptionRef formatDesc;
    OSStatus status = CMVideoFormatDescriptionCreateFromH264ParameterSets(kCFAllocatorDefault, 2, (const uint8_t *const*)parameterSetPointers, parameterSetSizes, 4, &formatDesc);
    
    if (status != noErr) {
        return nil;
    }
    
    return formatDesc;
}

- (VTDecompressionSessionRef)createDecompressionSession:(CMVideoFormatDescriptionRef)formatDesc status:(OSStatus *)status {
    VTDecompressionSessionRef decompressionSession;
    
    // 设置回调
    VTDecompressionOutputCallbackRecord callBackRecord;
    callBackRecord.decompressionOutputCallback = decompressionOutputCallback;
    callBackRecord.decompressionOutputRefCon = (__bridge void *)(self);
    
    // 设置解码后像素属性
    NSDictionary *destinationImageBufferAttributes = @{(id)kCVPixelBufferOpenGLESCompatibilityKey : @(NO),
                                                       (id)kCVPixelBufferPixelFormatTypeKey : @(kCVPixelFormatType_32BGRA)};
    
    // 创建解码器
    *status = VTDecompressionSessionCreate(kCFAllocatorDefault,
                                           formatDesc,
                                           NULL,
                                           (__bridge CFDictionaryRef)(destinationImageBufferAttributes),
                                           &callBackRecord,
                                           &decompressionSession);
    if (*status != noErr) {
        return nil;
    } else {
        return decompressionSession;
    }
}

- (void)decodeFrameData:(uint8_t *)frameData dataSize:(uint32_t)dataSize {
    uint8_t *data = malloc(dataSize);
    memcpy(data, frameData, dataSize);
    
    uint32_t dataLength32 = htonl(dataSize - 4);
    memcpy (data, &dataLength32, sizeof(uint32_t));
    
    CMBlockBufferRef blockBuffer = NULL;
    OSStatus status = CMBlockBufferCreateWithMemoryBlock(NULL,
                                                         data,  // memoryBlock to hold buffered data
                                                         dataSize,  // block length of the mem block in bytes.
                                                         kCFAllocatorNull,
                                                         NULL,
                                                         0, // offsetToData
                                                         dataSize,   // dataLength of relevant bytes, starting at offsetToData
                                                         0,
                                                         &blockBuffer);
    
    CMSampleBufferRef sampleBuffer = NULL;
    const size_t sampleSize = dataSize;
    status = CMSampleBufferCreate(kCFAllocatorDefault, blockBuffer, true, NULL, NULL, _formatDesc, 1, 0, NULL, 1, &sampleSize, &sampleBuffer);
    
    // either send the samplebuffer to a VTDecompressionSession or to an AVSampleBufferDisplayLayer
    VTDecodeFrameFlags flags = kVTDecodeFrame_EnableAsynchronousDecompression;
    VTDecodeInfoFlags flagOut = 0;
    status = VTDecompressionSessionDecodeFrame(_decompressionSession, sampleBuffer, flags, (__bridge void *)([NSDate date]), &flagOut);
    
    if (status != noErr) {
        IVYLog(@"### HardwareDecoder 2 VTDecompressionSessionDecodeFrame Error status:%@", @(status));
        [self decoderErrorType:HardwareDecoderDecodeError errorOSStatus:status]; // 解码数据失败，回调
    }
    
    if (data) {
        free(data);
        data = NULL;
    }
    
    CFRelease(blockBuffer);
    CFRelease(sampleBuffer);
}

- (void)decoderErrorType:(HardwareDecoderErrorType)errorType errorOSStatus:(OSStatus)status {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.delegate hardwareDecoder:self decoderErrorType:errorType errorOSStatus:status];
    });
}

- (void)releaseDecompressionSession {
    if (nil != _decompressionSession) {
        VTDecompressionSessionInvalidate(_decompressionSession);
        CFRelease(_decompressionSession);
        _decompressionSession = NULL;
    }
}

- (void)releaseVideoFormatDescription {
    if (nil != _formatDesc) {
        CFRelease(_formatDesc);
        _formatDesc = NULL;
    }
}

#pragma mark - Memory
- (void)dealloc {
    [self releaseVideoFormatDescription];
    [self releaseDecompressionSession];
    IVYLog(@"... %@: dealloc", NSStringFromClass([self class]));
}

@end

void decompressionOutputCallback(void * decompressionOutputRefCon,
                                 void * sourceFrameRefCon,
                                 OSStatus status,
                                 VTDecodeInfoFlags infoFlags,
                                 CVImageBufferRef imageBuffer,
                                 CMTime presentationTimeStamp,
                                 CMTime presentationDuration) {

    HardwareDecoder *decoder = (__bridge HardwareDecoder *)decompressionOutputRefCon;
    [decoder.delegate hardwareDecoder:decoder didDecodeFrame:imageBuffer];
}
