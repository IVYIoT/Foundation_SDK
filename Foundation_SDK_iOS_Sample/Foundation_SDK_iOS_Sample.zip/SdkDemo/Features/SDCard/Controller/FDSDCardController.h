//
//  FDSDCardController.h
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYViewController.h"
#import "Camera.h"

NS_ASSUME_NONNULL_BEGIN

@interface FDSDCardController : IVYViewController

- (instancetype)initWithCamera:(Camera *)camera;

@end

NS_ASSUME_NONNULL_END
