//
//  IDSDCardController.m
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IDSDCardController.h"
#import "HardwareDecoder.h"
#import "IVYImageHelper.h"
#import "IVYRecordInfo.h"
#import "IVYConstant.h"
#import "Masonry.h"

static int const kTimeOutMS = 30000;

static NSString * const kCellID = @"CellID";

@interface IDSDCardController () <UITableViewDataSource, UITableViewDelegate, HardwareDecoderDelegate>

@property (nonatomic, strong) Camera *camera;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray<IVYRecordInfo *> *dataSoucre;

@property (nonatomic, assign) BOOL running;

@property (nonatomic, assign) BOOL eventRunning;

@property (nonatomic, assign) IVYStreamDataType type;

@property (nonatomic, strong) HardwareDecoder *decoder;

@end

@implementation IDSDCardController

#pragma mark - Lifecycle
- (instancetype)initWithCamera:(Camera *)camera {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _camera = camera;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"SD Card(IVY)";
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.tableView];
    
    [self layoutPageSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self getRecordList];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    _eventRunning = NO;
    _running = NO;
}

- (void)layoutPageSubviews {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.equalTo(self.view.mas_width).multipliedBy(9 / 16.f);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom);
        make.left.right.bottom.equalTo(self.view);
    }];
}

#pragma mark - Private Methods
- (void)getRecordList {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *now = [NSDate new];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:now];
    
    components.hour = 0;
    components.minute = 0;
    components.second = 0;
    
    NSDate *date = [calendar dateFromComponents:components];
    NSUInteger st = (unsigned int)[date timeIntervalSince1970];
    NSUInteger et = st + 24 * 3600 - 1;
    
    IVYHANDLE handle = self.camera.handle;
    NSInteger recordType = 511;
    __weak typeof(self) weakSelf = self;
    
    IVYLog(@"... startTime:%@ endTime:%@ recordType:%@", @(st), @(et), @(recordType));
    [self getSDCardRecordList:handle startTime:st endTime:et recordType:recordType onCompletion:^(id  _Nullable object, IVYIO_RESULT cmdResult) {
        if (IVYIO_RESULT_OK == cmdResult) {
            NSArray *records = (NSArray *)object;
            
            weakSelf.dataSoucre = records;
            [weakSelf.tableView reloadData];
        } else {
            IVYLog(@"... Error");
        }
    }];
}

- (void)getSDCardRecordList:(IVYHANDLE)handle startTime:(NSUInteger)startTime endTime:(NSUInteger)endTime recordType:(NSInteger)recordType onCompletion:(IVYCGIBlock)resultBlock {
        
    unsigned int st = (unsigned int)startTime;
    unsigned int et = (unsigned int)endTime;
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        IVYIO_RESULT cmdResult = IVYIO_RESULT_UNKNOWN;
        
        IVYIO_GET_RECORD_LIST_ARGS_TYPE0 searchRecordPara;
        memset(&searchRecordPara, 0, sizeof(IVYIO_GET_RECORD_LIST_ARGS_TYPE0));
        searchRecordPara.getRecordListArgsType = 0;
        searchRecordPara.sTime = (long long)st;
        searchRecordPara.eTime = (long long)et;
        searchRecordPara.type = (int)recordType;
        searchRecordPara.cnt = 40;
        
        int startNo = 0;
        int totalCnt = 0;
        
        NSMutableArray *mutableArray = [NSMutableArray new];
        
        do {
            searchRecordPara.startNo = startNo;
            
            IVYIO_RECORD_LIST_ARGS_TYPE0 recordList;
            memset(&recordList, 0, sizeof(IVYIO_RECORD_LIST_ARGS_TYPE0));
            
            cmdResult = IVYIO_GetPlaybackRecordList(handle, (IVYIO_GET_RECORD_LIST_ARGS_TYPE0 *)&searchRecordPara, (IVYIO_RECORD_LIST_ARGS_TYPE0 *)&recordList, 30000, 0);
            
            IVYLog(@"... IVYIO_GetPlaybackRecordList cmdResult:%@ recordList totalCnt:%@ curCnt:%@", @(cmdResult), @(recordList.totalCnt), @(recordList.curCnt));
            
            if (IVYIO_RESULT_OK != cmdResult) {
                break;
            }
            
            totalCnt = recordList.totalCnt;
            int curCnt = recordList.curCnt;
            startNo += curCnt;
            
            for (int i = 0; i != curCnt; ++ i) {
                IVYRecordInfo *obj = [[IVYRecordInfo alloc] instanceWithStruct:&recordList.list[i]];
                [mutableArray addObject:obj];
            }
            
        } while (startNo < totalCnt);
        
        if (cmdResult == IVYIO_RESULT_OK) {
            dispatch_async(dispatch_get_main_queue(), ^{
                resultBlock([mutableArray copy], cmdResult);
            });
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                resultBlock(nil, cmdResult);
            });
        }
    });
}

- (void)playBack:(IVYRecordInfo *)info {
    _running = YES;
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self openPlayBack:info];
    });
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getStreamData];
    });

    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getAudioData];
    });
}

- (void)openPlayBack:(IVYRecordInfo *)info {
    IVYHANDLE handle = self.camera.handle;
    
    IVYIO_OPEN_PLAY_BACK_ARGS_TYPE0 openVideoPara;
    memset(&openVideoPara, 0, sizeof(IVYIO_OPEN_PLAY_BACK_ARGS_TYPE0));
    openVideoPara.openPlaybackArgsType = 0;
    openVideoPara.sTime = info.st;
    openVideoPara.eTime = info.et;
    openVideoPara.streamType = 0;
    
    IVYIO_RESULT cmdResult = IVYIO_OpenPlayback(handle, (IVYIO_OPEN_PLAY_BACK_ARGS_TYPE0 *)&openVideoPara, 30000, 1);
    
    IVYLog(@"... IVYIO_OpenPlayback st:%@ cmdResult:%@", info.stStr, @(cmdResult));
}

- (void)getStreamData {
    IVYIO_FRAME *frame = NULL;
    IVYHANDLE handle = self.camera.handle;
    int iOutLen, mediaSpeed = 0;
    int iDecodeFmt = IVYIO_DEC_TYPE_RGB24;

    while (_running) {

        IVYIO_RESULT cmdResult = IVYIO_RESULT_UNKNOWN;
        switch (_type) {
            case IVYStreamDataRaw: {
                cmdResult = IVYIO_GetPlaybackRawStreamData(handle, IVYIO_STREAM_VIDEO, (unsigned char **)&frame, &iOutLen, &mediaSpeed, 0);
            }
                break;

            case IVYStreamDataDecoded: {
                cmdResult = IVYIO_GetPlaybackStreamData(handle, IVYIO_STREAM_VIDEO, (unsigned char **)&frame, &iOutLen, &mediaSpeed, iDecodeFmt, 0);
            }
                break;
        }

        if (IVYIO_RESULT_OK != cmdResult || iOutLen == 0 || IVYIO_STREAM_VIDEO != frame->type) {
            usleep(20 * 1000);
            continue;
        }
        
        IVYLog(@"... cmdResult:%@ pts:%@", @(cmdResult), @(frame->pts));
        
        switch (_type) {
            case IVYStreamDataRaw: {
                [self.decoder didReciveFrame:(uint8_t *)frame->data frameSize:frame->len];
            }
                break;
                
            case IVYStreamDataDecoded: {
                UIImage *image = [IVYImageHelper imageFromAVPicture:(char *)frame->data width:frame->media.video.w height:frame->media.video.h];
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.imageView.image = image;
                });
            }
                break;
        }
        
        if (frame->iFrameTag == FRAME_TAG_PLAYBACK_E_FRAME) {
            _running = NO; // 播放完毕
            break;
        }
        
        usleep(33 * 1000);
    }
    
    IVYIO_CLOSE_PLAY_BACK_ARGS_TYPE0 closeVideoPara;
    memset(&closeVideoPara, 0, sizeof(IVYIO_CLOSE_PLAY_BACK_ARGS_TYPE0));
    closeVideoPara.openPlaybackArgsType = 0;
    
    IVYIO_RESULT cmdResult = IVYIO_ClosePlayback(handle, (IVYIO_OPEN_PLAY_BACK_ARGS_TYPE0 *)&closeVideoPara, kTimeOutMS, 1);
    IVYLog(@"... IVYIO_ClosePlayback cmdResult:%@", @(cmdResult));
}

- (void)getAudioData {
    IVYIO_FRAME* frame;
    int iOutLen, mediaSpeed = 0;
    IVYIO_RESULT cmdResult = IVYIO_RESULT_UNKNOWN;
    
    IVYHANDLE handle = self.camera.handle;
    
    while (_running) {
        cmdResult = IVYIO_GetPlaybackStreamData(handle, IVYIO_STREAM_AUDIO, (unsigned char **)&frame, &iOutLen, &mediaSpeed, 0, 0);
        if (IVYIO_RESULT_OK != cmdResult || iOutLen == 0 || IVYIO_STREAM_AUDIO != frame->type) {
            usleep(20 * 1000);
            continue;
        }
        
        // TODO: Play Audio
        usleep(10 * 1000);
    }
    
    IVYLog(@"... getAudioData End");
}

#pragma mark - HardwareDecoderDelegate
- (void)hardwareDecoder:(HardwareDecoder *)decoder didDecodeFrame:(CVImageBufferRef)imageBuffer {
    UIImage *image = [IVYImageHelper displayImage:imageBuffer];
    dispatch_async(dispatch_get_main_queue(), ^{
        self.imageView.image = image;
    });
}

- (void)hardwareDecoder:(HardwareDecoder *)decoder decoderErrorType:(HardwareDecoderErrorType)errorType errorOSStatus:(OSStatus)status {
    IVYLog(@"### IvyPlayer HardwareDecoder Error errorType:%@ errorOSStatus:%@", @(errorType), @(status));
    _type = IVYStreamDataDecoded;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataSoucre count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:kCellID];
        cell.backgroundColor = RGBCOLOR(250, 250, 250);
        cell.textLabel.textColor = RGBCOLOR(81, 88, 91);
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    IVYRecordInfo *obj = self.dataSoucre[indexPath.row];
    NSString *text = [NSString stringWithFormat:@"%@ - %@", obj.stStr, obj.etStr];

    cell.textLabel.text = text;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    IVYRecordInfo *obj = self.dataSoucre[indexPath.row];
    
    [self playBack:obj];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50.f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 44.f;
}

#pragma mark - Getter && Setter
- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.1];
    }
    return _imageView;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

- (HardwareDecoder *)decoder {
    if (!_decoder) {
        _decoder = [HardwareDecoder new];
        _decoder.delegate = self;
    }
    return _decoder;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
