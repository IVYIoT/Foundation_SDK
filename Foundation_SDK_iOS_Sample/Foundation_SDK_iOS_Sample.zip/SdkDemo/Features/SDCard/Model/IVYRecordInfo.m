//
//  IVYRecordInfo.m
//  SdkDemo
//
//  Created by JackChan on 27/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYRecordInfo.h"

static NSDateFormatter * formatter() {
    static NSDateFormatter *formatter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        formatter = [NSDateFormatter new];
        [formatter setDateFormat:@"HH:mm:ss"];
    });
    return formatter;
}

@implementation IVYRecordInfo

- (instancetype)instanceWithStruct:(IVYIO_RECORD_INFO_TYPE0 *)st {
    self.channel = (NSInteger)st->channel;
    self.st = st->sTime;
    self.et = st->eTime;
    self.recordType = st->recordType;
    
    return self;
}

@end



@implementation IVYRecordInfo (IVY)

- (NSString *)stStr {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:self.st];
    NSString *str = [formatter() stringFromDate:date];
    return str;
}

- (NSString *)etStr {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:self.et];
    NSString *str = [formatter() stringFromDate:date];
    return str;
}

@end
