//
//  IVYRecordInfo.h
//  SdkDemo
//
//  Created by JackChan on 27/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

@interface IVYRecordInfo : NSObject

@property (nonatomic, assign) NSInteger channel;

@property (nonatomic, assign) unsigned long long st;

@property (nonatomic, assign) unsigned long long et;

@property (nonatomic, assign) unsigned int recordType;

- (instancetype)instanceWithStruct:(IVYIO_RECORD_INFO_TYPE0 *)st;

@end


@interface IVYRecordInfo (IVY)

@property (nonatomic, strong, readonly) NSString *stStr;

@property (nonatomic, strong, readonly) NSString *etStr;

@end

NS_ASSUME_NONNULL_END
