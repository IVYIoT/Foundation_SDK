//
//  HomeController.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "HomeController.h"
#import "DeviceController.h"
#import "UIButton+IVY.h"
#import "Masonry.h"

@interface HomeController ()

@property (nonatomic, strong) UIButton *button1;

@property (nonatomic, strong) UIButton *button2;

@end

@implementation HomeController

#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"Home";
    
    [self.view addSubview:self.button1];
    [self.view addSubview:self.button2];
    [self layoutPageSubviews];
}

- (void)layoutPageSubviews {
    [self.button1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(160);
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(120, 48));
    }];
    
    [self.button2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.button1.mas_bottom).offset(40);
        make.size.centerX.equalTo(self.button1);
    }];
}

#pragma mark - Event Response
- (void)buttonTapped:(UIButton *)sender {
    IVYDeviceType type = (IVYDeviceType)sender.tag;
    DeviceController *vc = [DeviceController new];
    vc.deviceType = type;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Getter && Setter
- (UIButton *)button1 {
    if (!_button1) {
        _button1 = [UIButton ivy_button];
        _button1.tag = IVYDeviceFOS;
        [_button1 setTitle:@"Foscam 设备" forState:UIControlStateNormal];
        [_button1 addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button1;
}

- (UIButton *)button2 {
    if (!_button2) {
        _button2 = [UIButton ivy_button];
        _button2.tag = IVYDeviceIVY;
        [_button2 setTitle:@"ivyiot 设备" forState:UIControlStateNormal];
        [_button2 addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button2;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
