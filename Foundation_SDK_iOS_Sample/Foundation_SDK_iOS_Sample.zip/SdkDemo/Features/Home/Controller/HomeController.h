//
//  HomeController.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeController : IVYViewController

@end

NS_ASSUME_NONNULL_END
