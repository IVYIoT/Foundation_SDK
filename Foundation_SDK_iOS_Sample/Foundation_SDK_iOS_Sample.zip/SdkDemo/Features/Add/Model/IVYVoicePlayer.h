//
//  IVYVoicePlayer.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

@class IVYVoicePlayer;

@protocol IVYVoicePlayerDelegate <NSObject>

@optional

/// 声波配网结束
/// @param player 当前对象
/// @param flag 结果
- (void)ivyVoicePlayerDidFinishPlaying:(IVYVoicePlayer *)player successfully:(BOOL)flag;

/// 声波配网异常
/// @param player 当前对象
/// @param error 异常
- (void)ivyVoicePlayerDecodeErrorDidOccur:(IVYVoicePlayer *)player error:(NSError * __nullable)error;

@end



@interface IVYVoicePlayer : NSObject

/// 初始化方法
/// @param SSID Wi-Fi SSID
/// @param password Wi-Fi 密码
/// @param deviceUID 设备UID
/// @param type 设备类型
/// @note IVYDeviceFOS类型，须传入deviceUID，否则报错；IVYDeviceIVY类型可不传；
- (instancetype)initWithSSID:(nonnull NSString *)SSID password:(nonnull NSString *)password deviceUID:(nullable NSString *)deviceUID type:(IVYDeviceType)type;

/// 播放
- (void)play;

/// 停止播放
- (void)stop;

/// 代理
@property (nonatomic, weak) id<IVYVoicePlayerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
