//
//  IVYVoicePlayer.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYVoicePlayer.h"
#import "NSData+IVY.h"
#import "NSString+IVY.h"
#import "voiceLib.h"
#import <AudioToolbox/AudioToolbox.h>

#define MAXPACKLENGTH 32
#define MAX_LEN_PACKAGE 32

#define VOICEENCRYPTTEA "13@!@#jyf2sh*zx_"
#define VOICEENCRYPTCAESAR ""
#define VOICEENCRYPTXOR "@*402kfjKD@*}:?>"
#define VOICEENCRYPTAES "84flkd93dksfl@13"

static void upper(char *data, int len) {
    for (int i = 0; i < len; i++)
        data[i] = toupper(data[i]);
}

@interface IVYVoicePlayer ()

@property (nonatomic, copy) NSString *SSID;

@property (nonatomic, copy) NSString *password;

@property (nonatomic, copy) NSString *deviceUID;

@property (nonatomic, assign) IVYDeviceType type;

@property (nonatomic, assign) void *player;

@property (nonatomic, assign) BOOL running;

@property (nonatomic, assign) void *voicePlayer;

@end

@implementation IVYVoicePlayer

#pragma mark - Lifecycle
- (instancetype)initWithSSID:(nonnull NSString *)SSID password:(nonnull NSString *)password deviceUID:(nullable NSString *)deviceUID type:(IVYDeviceType)type {
    if (self = [super init]) {
        _SSID = SSID;
        _password = password;
        _deviceUID = deviceUID;
        _type = type;
        IVYLog(@"... SSID:%@, password:%@ deviceUID:%@ type:%@", SSID, password, deviceUID, @(type));
    }
    return self;
}

#pragma mark - Public Methods
- (void)play {
    self.running = YES;
    NSString *content = [NSString stringWithFormat:@"[S:%@][P:%@]", _SSID, _password];
    switch (_type) {
        case IVYDeviceIVY: {
            [self playIvyVoice:content];
        }
            break;
            
        case IVYDeviceFOS: {
            [self playFosVoice:content];
        }
            break;
            
        default: {
            NSString *desc = [NSString stringWithFormat:@"Unkown type:%@", @(_type)];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self decodeErrorDidOccur:desc];
            });
        }
            break;
    }
}

- (void)stop {
    self.running = NO;
    
    if (self.player != NULL) {
        VOICE_Stop(self.player);
    }
}

#pragma mark - Private Methods
- (void)playIvyVoice:(NSString *)content {
    char *voiceData = (char *)[content UTF8String];
    int cryptoType = (content.length == strlen(voiceData)) ? CRYPTO_TYPE_CAESAR : CRYPTO_TYPE_XOR;
    
    char *key = "";
    switch (cryptoType) {
        case CRYPTO_TYPE_TEA:
            key = VOICEENCRYPTTEA;
            break;
        case CRYPTO_TYPE_CAESAR:
            key = VOICEENCRYPTCAESAR;
            break;
        case CRYPTO_TYPE_XOR:
            key = VOICEENCRYPTXOR;
            break;
        case CRYPTO_TYPE_AES:
            key = VOICEENCRYPTAES;
            break;
        default:
            break;
    }
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        char szEncrypted[2048] = {0};
        char szEncodeString[512] = {0};
        int lenOfEncrypted = (int)VOICE_EncryptData(cryptoType, voiceData, (int)strlen(voiceData), szEncrypted + 1, sizeof(szEncrypted) - 1, key, (int)strlen(key));
        
        if (CRYPTO_TYPE_TEA == cryptoType) {
            szEncrypted[0] = '1';
        } else if (CRYPTO_TYPE_CAESAR == cryptoType) {
            szEncrypted[0] = '2';
        } else if (CRYPTO_TYPE_XOR == cryptoType) {
            szEncrypted[0] = '3';
        } else if (CRYPTO_TYPE_AES == cryptoType) {
            upper(szEncrypted + 1, lenOfEncrypted);
            szEncrypted[0] = '4';
        }
                
        int count = lenOfEncrypted / MAX_LEN_PACKAGE ? lenOfEncrypted / MAX_LEN_PACKAGE : 1;
        
        IVYLog(@"... content:%s key:%s cryptoType:%@ lenOfEncrypted:%@ count:%@", voiceData, key, @(cryptoType), @(lenOfEncrypted), @(count));
        
        BOOL bflag = YES;
        
        self.player = VOICE_Create(44100, 8000);
        
        for (int i = 0; i < count; i++) {
            char buffer[256] = {0};
            if (i == count - 1)
                memcpy(buffer, szEncrypted + i * MAX_LEN_PACKAGE, MAX_LEN_PACKAGE + 1);
            else
                memcpy(buffer, szEncrypted + i * MAX_LEN_PACKAGE, MAX_LEN_PACKAGE);
            
            char toEncodeBuffer[256] = {0};
            sprintf(toEncodeBuffer, "%d%d%s", count, i, buffer);
            
            memset(szEncodeString, 0, sizeof(szEncodeString));
            int iLenOfEncode = VOICE_EncodeData(toEncodeBuffer, (int)strlen(toEncodeBuffer), szEncodeString, sizeof(szEncodeString));
            
            if (!(iLenOfEncode > 0)) { continue ; }
            
            if (!self.running) {
                bflag = NO;
                break;
            }
            
            VOICE_Play(self.player, szEncodeString, 1, 0);
        }
        
        [self stop];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self didFinishPlaying:YES];
        });
    });
}

- (void)playFosVoice:(NSString *)content {
    if (nil == _deviceUID || _deviceUID.length == 0) {
        NSString *desc = [NSString stringWithFormat:@"deviceUID is NULL:%@", _deviceUID];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self decodeErrorDidOccur:desc];
        });
        return ;
    }
    
    NSString *md5 = [_deviceUID stringForMD5];
    NSString *key = [md5 substringWithRange:NSMakeRange((md5.length - 16)/2, 16)];
    
    NSString *encryptData = [self encryptData:content key:key];
    
    int packCount = (int)(encryptData.length - 1) / MAXPACKLENGTH + 1;
    IVYLog(@"... content:%@ key:%@ encryptData:%@ packCount:%@", content, key, encryptData, @(packCount));
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        BOOL bflag = YES;
        
        int packIndex = 0;
        while (packIndex < packCount) {
            int subStrStart = MAXPACKLENGTH * packIndex;
            int subStrEnd = (packCount == packIndex + 1) ? (int)encryptData.length : MAXPACKLENGTH * (packIndex + 1);
            NSString *subString = [encryptData substringWithRange:NSMakeRange(subStrStart, subStrEnd-subStrStart)];
            NSString *currTagText = [[NSString stringWithFormat:@"%d%d%@", packCount, packIndex, subString] uppercaseString];
            char szEncodeString[512] = {0};
            char *toEncodeBuffer = (char *)[currTagText UTF8String];
            int iEncodeLen = VOICE_EncodeData(toEncodeBuffer, (int)strlen(toEncodeBuffer), szEncodeString, sizeof(szEncodeString));
            
            if (iEncodeLen <= 0) {
                bflag = NO;
                NSString *desc = [NSString stringWithFormat:@"VOICE_EncodeData Error iEncodeLen:%@ currentStr:%@", @(iEncodeLen), currTagText];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self decodeErrorDidOccur:desc];
                });
                break;
            }
            
            if (!self.running) {
                bflag = NO;
                break;
            }
            
            self.player = VOICE_Create(44100, 8000);
            VOICE_Play(self.player, szEncodeString, 1, 0);
            
            if (packIndex++ < packCount) {
                int time = 10;
                BOOL interrupt = NO;
                
                while (--time) {
                    usleep(1000 * 1000);
                    if (!self.running) {
                        interrupt = YES;
                        break;
                    }
                }
                
                if (interrupt) {
                    bflag = NO;
                    break;
                }
            }
        }
        
        [self stop];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self didFinishPlaying:bflag];
        });
    });
}

- (NSString *)encryptData:(NSString *)string key:(NSString *)key {
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSData *encryptData = [data encryptByAES128WithKey:key options:kCCOptionPKCS7Padding];
    NSString *hexString = [encryptData hexString];
    
    return hexString;
}

- (void)didFinishPlaying:(BOOL)flag {
    if ([_delegate respondsToSelector:@selector(ivyVoicePlayerDidFinishPlaying:successfully:)]) {
        [_delegate ivyVoicePlayerDidFinishPlaying:self successfully:flag];
    }
    
    self.running = NO;
}

- (void)decodeErrorDidOccur:(NSString *)desc {
    NSError *error = [NSError errorWithDomain:@"io.ivyiot.IVYVoicePlayer" code:-1 userInfo:@{@"description": desc}];
    
    if ([_delegate respondsToSelector:@selector(ivyVoicePlayerDecodeErrorDidOccur:error:)]) {
        [_delegate ivyVoicePlayerDecodeErrorDidOccur:self error:error];
    }
    
    self.running = NO;
}

- (void)dealloc {
    IVYLog(@"... %@ dealloc", NSStringFromClass([self class]));
}

@end
