//
//  WiFiConfigController.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "WiFiConfigController.h"
#import "AddDeviceController.h"
#import "IVYVoicePlayer.h"
#import "IVYDevLan.h"
#import "UIButton+IVY.h"
#import "Masonry.h"

static NSString * const kCellID = @"CellID";
static NSInteger const kMaxOfDiscovery = 50;

@interface WiFiConfigController () <UITableViewDataSource, UITableViewDelegate, IVYVoicePlayerDelegate>

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) UIButton *button;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray<IVYDevLan *> *dataSoucre;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, assign) CGSize imageSize;

@property (nonatomic, strong) IVYVoicePlayer *voicePlayer;

@end

@implementation WiFiConfigController

#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"WiFi Configuration";
    
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.button];
    [self.view addSubview:self.tableView];
    
    [self layoutPageSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self startTimer];
    
    NSString *SSID = kSSID;
    NSString *password = kWiFiPassword;
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSString *qrCodeString = [self qrCodeString:SSID password:password];
        UIImage *image = [self qrCodeImageFromString:qrCodeString];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = image;
        });
    });
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [_voicePlayer stop];
    [self stopTimer];
}

- (void)layoutPageSubviews {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(80);
        make.left.offset(5);
        make.right.offset(-5);
        make.height.equalTo(self.imageView.mas_width);
    }];
    
    [self.button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).offset(15);
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(120, 48));
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.button.mas_bottom).offset(15);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
    }];
    
    [self.imageView layoutIfNeeded];
    self.imageSize = self.imageView.bounds.size;
}

#pragma mark - Private Methods
- (void)startTimer {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(handleTimer) userInfo:nil repeats:YES];
}

- (void)stopTimer {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
}

- (NSString *)qrCodeString:(NSString *)SSID password:(NSString *)password {
    NSInteger authModel = 0;
    
    if (password && ![password isEqualToString:@""]) {
        authModel = 255;
    }
    
    NSString *qrCodeString = [NSString stringWithFormat:@"<S>%@</S><P>%@</P><T>%@</T>", SSID, password, @(authModel)];
    
    return qrCodeString;
}

- (UIImage *)qrCodeImageFromString:(NSString *)qrString {
    
    NSData *data = [qrString dataUsingEncoding:NSUTF8StringEncoding];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    [filter setValue:data forKey:@"inputMessage"];
    [filter setValue:@"L" forKey:@"inputCorrectionLevel"];
    
    CIImage *ciimage = filter.outputImage;
    CGFloat scaleX = self.imageSize.width / ciimage.extent.size.width;
    CGFloat scaleY = self.imageSize.height / ciimage.extent.size.height;
    
    CIImage *resizeImage = [ciimage imageByApplyingTransform:CGAffineTransformMakeScale(scaleX, scaleY)];
    UIImage *image = [[UIImage alloc] initWithCIImage:resizeImage scale:[[UIScreen mainScreen] scale] orientation:UIImageOrientationDown];
    
    return image;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataSoucre count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:kCellID];
        cell.backgroundColor = RGBCOLOR(250, 250, 250);
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    IVYDevLan *model = self.dataSoucre[indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"UID:%@", model.uid];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Mac:%@\tIP:%@", model.mac, model.ip];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    IVYDevLan *model = self.dataSoucre[indexPath.row];
    IVYLog(@"... deviceUID:%@", model.uid);
    
    AddDeviceController *vc = [[AddDeviceController alloc] initWithDevLan:model];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60.f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 44.f;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Device In Lan";
}

#pragma mark - IVYVoicePlayerDelegate
- (void)ivyVoicePlayerDidFinishPlaying:(IVYVoicePlayer *)player successfully:(BOOL)flag {
    self.button.enabled = YES;
    IVYLog(@"... did Finish Playing flag:%@", @(flag));
}

- (void)ivyVoicePlayerDecodeErrorDidOccur:(IVYVoicePlayer *)player error:(NSError * __nullable)error {
    self.button.enabled = YES;
    IVYLog(@"... decodeErrorDidOccur:%@", error);
}


#pragma mark - Event Response
- (void)buttonTapped:(UIButton *)sender {
    sender.enabled = NO;
    
    NSString *SSID = kSSID;
    NSString *password = kWiFiPassword;
    NSString *deviceUID = kDeviceUID;
    
    IVYDeviceType type = self.deviceType;
    _voicePlayer = [[IVYVoicePlayer alloc] initWithSSID:SSID password:password deviceUID:deviceUID type:type];
    _voicePlayer.delegate = self;
    
    [_voicePlayer play];
}

- (void)handleTimer {
    int size = kMaxOfDiscovery;
    IVYIO_DEV_NODE node[size];
    IVYIO_Discovery(node, &size);
    
    NSMutableArray *temp = [NSMutableArray new];
    for (int i = 0; i != size; ++ i) {
        IVYDevLan *thisModel = [[IVYDevLan alloc] instanceWithIVYIO_DEV_NODE:&node[i]];
        [temp addObject:thisModel];
    }
 
    self.dataSoucre = [temp copy];
    [self.tableView reloadData];
}

#pragma mark - Getter && Setter
- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
    }
    return _imageView;
}

- (UIButton *)button {
    if (!_button) {
        _button = [UIButton ivy_button];
        [_button setTitle:@"Send Voice" forState:UIControlStateNormal];
        [_button addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
