//
//  AddDeviceController.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "AddDeviceController.h"
#import "IVYSendCommand.h"
#import "IVYConstant.h"
#import "Camera.h"
#import "UIButton+IVY.h"
#import "NSString+IVY.h"
#import "Masonry.h"

typedef NS_ENUM(NSInteger, ADCBTags) {
    ADCBLogin,
    ADCBGetDevInfo,
};

@interface AddDeviceController ()

@property (nonatomic, strong) IVYDevLan *model;

@property (nonatomic, strong) Camera *camera;

@property (nonatomic, strong) UILabel *label;

@property (nonatomic, strong) NSMutableString *info;

@property (nonatomic, strong) UIButton *button1;

@property (nonatomic, strong) UIButton *button2;

@end

@implementation AddDeviceController

#pragma mark - Lifecycle
- (instancetype)initWithDevLan:(IVYDevLan *)model {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _model = model;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"Add Device";
    
    [self.view addSubview:self.label];
    [self.view addSubview:self.button1];
    [self.view addSubview:self.button2];
    
    [self layoutPageSubviews];
    
    _info = [[NSMutableString alloc] initWithFormat:@"IP: %@:%@\ndeviceMac: %@\ndeviceUID: %@\n\n", _model.ip, @(_model.port), _model.mac, _model.uid];
    self.label.text = _info.copy;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.button2.enabled = NO;
}

- (void)layoutPageSubviews {
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(100);
        make.left.offset(15);
        make.right.offset(-15);
        make.height.mas_equalTo(400);
    }];
    
    [self.button1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.label.mas_bottom);
        make.centerX.multipliedBy(0.5);
        make.size.mas_equalTo(CGSizeMake(120, 48));
    }];
    
    [self.button2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.top.equalTo(self.button1);
        make.centerX.multipliedBy(1.5);
    }];
}

#pragma mark - Priavte Methods
- (void)login {
    NSString *deviceUID = self.model.uid;
    NSString *username = kResettUsername;
    NSString *password = [deviceUID resetPasswordByDeviceUID];
    
    [_info appendFormat:@"Username: %@\nPassword: %@\n\n", username, password];
    self.label.text = _info.copy;
    
    _camera = [[Camera alloc] initWithDeviceUID:deviceUID username:username password:password];
    
    __weak typeof(self) weakSelf = self;
    [_camera loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
        IVYLog(@"... loginCamera cmdResult:%@ handleState:%@", @(cmdResult), @(handleState));
        
        if (IVYIO_RESULT_OK == cmdResult) {
            weakSelf.button2.enabled = YES;
        }
    }];
}

- (void)getCameraConfigs {
    if (nil == _camera.devInfo) {
        [self getDevInfo];
    }
    
    if (nil == _camera.devAbility) {
        [self getDevAbility];
    }
}

- (void)getDevInfo {
    IVYHANDLE handle = _camera.handle;
    
    int cmd = IVY_CTRL_MSG_GET_DEVINFO;
    NSDictionary *params = @{@"channel" : @(0)};
    
    __weak typeof(self) weakSelf = self;
    [[IVYSendCommand shared] sendCommand:handle cgiCommand:cmd parameters:params iTimeout:30000 onCompletion:^(NSDictionary * _Nonnull response, IVYIO_RESULT cgiResult) {
        IVYLog(@"... cgiResult:%@ response:%@", @(cgiResult), response);
        if (IVYIO_RESULT_OK == cgiResult) {
            IVYDevInfo *devInfo = [[IVYDevInfo alloc] instanceWithDict:response];
            weakSelf.camera.devInfo = devInfo;
            
            [weakSelf.info appendFormat:@"DevInfo:\nFirmware: %@\nHardware: %@\n\n", devInfo.firmwareVersion, devInfo.hardwareVersion];
            weakSelf.label.text = weakSelf.info.copy;
        }
    }];
}

- (void)getDevAbility {
    IVYHANDLE handle = _camera.handle;
    
    int cmd = IVY_CTRL_MSG_GET_DEVABILITY;
    NSDictionary *params = @{@"channel" : @(0)};
    
    __weak typeof(self) weakSelf = self;
    [[IVYSendCommand shared] sendCommand:handle cgiCommand:cmd parameters:params iTimeout:30000 onCompletion:^(NSDictionary * _Nonnull response, IVYIO_RESULT cgiResult) {
        IVYLog(@"... cgiResult:%@ response:%@", @(cgiResult), response);
        if (IVYIO_RESULT_OK == cgiResult) {
            IVYDevAbility *devAbility = [[IVYDevAbility alloc] instanceWithDict:response];
            weakSelf.camera.devAbility = devAbility;
            
            [weakSelf.info appendFormat:@"DevAbility:\nval0: %@\nval1: %@\n", @(devAbility.val0), @(devAbility.val1)];
            [weakSelf.info appendFormat:@"HumanDetect: %@\nAudioDetect: %@\n\n", @(devAbility.isEnableHumanDetect), @(devAbility.isEnableAudioDetect)];
            
            weakSelf.label.text = weakSelf.info.copy;
        }
    }];
}

#pragma mark - Event Response
- (void)buttonTapped:(UIButton *)sender {
    ADCBTags tag = (ADCBTags)sender.tag;
    
    switch (tag) {
        case ADCBLogin:
            [self login];
            break;
            
        case ADCBGetDevInfo:
            [self getCameraConfigs];
            break;
    }
}

#pragma mark - Getter && Setter
- (UILabel *)label {
    if (!_label) {
        _label = [UILabel new];
        _label.numberOfLines = 0;
        _label.textColor = RGBCOLOR(81, 88, 91);
        _label.font = [UIFont systemFontOfSize:15];
    }
    return _label;
}

- (UIButton *)button1 {
    if (!_button1) {
        _button1 = [UIButton ivy_button];
        _button1.tag = ADCBLogin;
        [_button1 setTitle:@"登录设备" forState:UIControlStateNormal];
        [_button1 addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button1;
}

- (UIButton *)button2 {
    if (!_button2) {
        _button2 = [UIButton ivy_button];
        _button2.tag = ADCBGetDevInfo;
        [_button2 setTitle:@"获取信息" forState:UIControlStateNormal];
        [_button2 addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button2;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
