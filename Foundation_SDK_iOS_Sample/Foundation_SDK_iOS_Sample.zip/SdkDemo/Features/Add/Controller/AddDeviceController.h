//
//  AddDeviceController.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/23.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYViewController.h"
#import "IVYDevLan.h"

NS_ASSUME_NONNULL_BEGIN

@interface AddDeviceController : IVYViewController

- (instancetype)initWithDevLan:(IVYDevLan *)model;

@end

NS_ASSUME_NONNULL_END
