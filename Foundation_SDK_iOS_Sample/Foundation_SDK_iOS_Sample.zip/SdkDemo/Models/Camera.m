//
//  Camera.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "Camera.h"

static int const kLoginTimeOut = 30000;

typedef void(^IVYCameraLoginBlock)(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult);

static dispatch_queue_t queue() {
    static dispatch_queue_t queue = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        queue = dispatch_queue_create("io.ivyiot.Camera.Queue", DISPATCH_QUEUE_CONCURRENT);
    });
    return queue;
}

@implementation Camera

- (instancetype)initWithDeviceUID:(NSString *)deviceUID username:(NSString *)username password:(NSString *)password {
    if (self = [super init]) {
        _deviceUID = deviceUID;
        _username = username;
        _password = password;
        _handle = [self createHandle];
    }
    return self;
}

- (IVYHANDLE)createHandle {
    IVYIO_URL url;
    memset(&url, 0, sizeof(url));
    
    char *szUid = (char *)[SAFTYSTRING(self.deviceUID) UTF8String];
    char *szUser = (char *)[SAFTYSTRING(self.username) UTF8String];
    char *szPassword = (char *)[SAFTYSTRING(self.password) UTF8String];
    IVYIO_P2P_MODE mode = IVYIO_P2P_MODE_AUTO;
    
    IVYHANDLE handle = IVYIO_Create(&url, szUid, szUser, szPassword, mode);
    IVYLog(@"... IVYIO_Create handle:%@ szUid:%s szUser:%s szPassword:%s mode:%@", @(handle),szUid, szUser, szPassword, @(mode));
    
    return handle;
}

@end



@implementation Camera (Category)

- (IVYIO_HANDLE_STATE)handleState {
    IVYHANDLE handle = _handle;
    IVYIO_HANDLE_STATE handleState = IVYIO_CheckHandle(handle);
    return handleState;
}

- (void)loginCamera:(void(^)(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult))resultBlock {
    IVYHANDLE handle = _handle;

    dispatch_async(queue(), ^{
        // 获取当前handle状态
        IVYIO_HANDLE_STATE handleState = IVYIO_CheckHandle(handle);
        
        switch (handleState) {
            case IVYIO_HANDLE_STATE_INIT: {
                [self login:handle onCompletion:resultBlock]; // 直接登录设备
            }
                break;
                
            case IVYIO_HANDLE_STATE_OFFLINE:
            case IVYIO_HANDLE_STATE_MAX_USERS:
            case IVYIO_HANDLE_STATE_USR_OR_PWD_ERR:
            case IVYIO_HANDLE_STATE_LOCKED: {
                IVYLog(@"... IVYIO_Logout handleState:%@", @(handleState));
                IVYIO_Logout(handle); // 需先登出设备
                [self login:handle onCompletion:resultBlock]; // 再登录设备
            }
                break;
                
            case IVYIO_HANDLE_STATE_CONNECTTING: {
                [self wait:handle onCompletion:resultBlock]; // 等待登录结果
            }
                break;
                
            default: {
                [self loginResult:handleState cmdResult:IVYIO_RESULT_UNKNOWN onCompletion:resultBlock]; // 其它情况，结果直接回调
            }
                break;
        }
    });
}

- (void)loginResult:(IVYIO_HANDLE_STATE)handleState cmdResult:(IVYIO_RESULT)cmdResult onCompletion:(IVYCameraLoginBlock)resultBlock {
    cmdResult = (handleState == IVYIO_HANDLE_STATE_ONLINE) ? IVYIO_RESULT_OK : cmdResult;
    if (resultBlock) {
        dispatch_async(dispatch_get_main_queue(), ^{
            resultBlock(handleState, cmdResult);
        });
    }
}

- (void)login:(IVYHANDLE)handle onCompletion:(IVYCameraLoginBlock)resultBlock {
    CFAbsoluteTime loginBegin = CFAbsoluteTimeGetCurrent();
    IVYIO_RESULT cmdResult = IVYIO_Login(handle, kLoginTimeOut);
    IVYIO_HANDLE_STATE handleState = IVYIO_CheckHandle(handle);
    IVYLog(@"... IVYIO_Login handle:%@ cmdResult:%@ handleState:%@ loginInterval:%@", @(handle), @(cmdResult), @(handleState), @(CFAbsoluteTimeGetCurrent() - loginBegin));
    if (IVYIO_RESULT_OK == cmdResult && handleState != IVYIO_HANDLE_STATE_ONLINE) {
        handleState = IVYIO_HANDLE_STATE_ONLINE;
    }
    [self loginResult:handleState cmdResult:cmdResult onCompletion:resultBlock];
}

- (void)wait:(IVYHANDLE)handle onCompletion:(IVYCameraLoginBlock)resultBlock {
    IVYIO_HANDLE_STATE handleState = IVYIO_HANDLE_STATE_CONNECTTING;
    
    CFAbsoluteTime endTime = CFAbsoluteTimeGetCurrent() + (kLoginTimeOut / 1000);
    while (CFAbsoluteTimeGetCurrent() < endTime) {
        handleState = IVYIO_CheckHandle(handle);
        if (IVYIO_HANDLE_STATE_CONNECTTING != handleState) {
            break;
        }
        sleep(1);
    }
    
    [self loginResult:handleState cmdResult:IVYIO_RESULT_UNKNOWN onCompletion:resultBlock];
}

@end
