//
//  IVYDevAbility.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IVYDevAbility : NSObject

@property (nonatomic, assign) NSInteger val0;
@property (nonatomic, assign) NSInteger val1;
@property (nonatomic, assign) NSInteger val2;
@property (nonatomic, assign) NSInteger val3;
@property (nonatomic, assign) NSInteger val4;
@property (nonatomic, assign) NSInteger val5;
@property (nonatomic, assign) NSInteger val6;
@property (nonatomic, assign) NSInteger val7;
@property (nonatomic, assign) NSInteger val8;

- (instancetype)instanceWithDict:(NSDictionary *)dict;

@end


@interface IVYDevAbility (Helper)

/// 是否支持sd
@property (nonatomic, assign, readonly) BOOL isEnableSD;

/// 是否支持outdoor
@property (nonatomic, assign, readonly) BOOL isEnableOutdoor;

/// 是否支持PT
@property (nonatomic, assign, readonly) BOOL isEnablePT;

/// 是否支持zoom
@property (nonatomic, assign, readonly) BOOL isEnableZoom;

/// 是否支持RS485
@property (nonatomic, assign, readonly) BOOL isEnableRS485;

/// 是否支持ioAlarm
@property (nonatomic, assign, readonly) BOOL isEnableIOAlarm;

/// 是否支持onvif
@property (nonatomic, assign, readonly) BOOL isEnableOnvif;

/// 是否支持p2p
@property (nonatomic, assign, readonly) BOOL isEnableP2P;

/// 是否支持wps
@property (nonatomic, assign, readonly) BOOL isEnableWPS;

/// 是否支持audio
@property (nonatomic, assign, readonly) BOOL isEnableAudio;

/// 是否支持talk
@property (nonatomic, assign, readonly) BOOL isEnableTalk;

/// 分辨率修改
/// Note: YES:只支持切换码流 NO:切换分辨率
@property (nonatomic, assign, readonly) BOOL isStreamSwitch;

/// 是否支持移动侦测区域设置
@property (nonatomic, assign, readonly) BOOL isSupportMotionArea;

/// 是否支持一键告警
@property (nonatomic, assign, readonly) BOOL isSupportOneKeyCall;

/// 是否支持IR计划
@property (nonatomic, assign, readonly) BOOL isSupportIRCutSchedule;

/// 框外侦测
@property (nonatomic, assign, readonly) BOOL isEnableOutFrameworkDetect;

/// 声音侦测
@property (nonatomic, assign, readonly) BOOL isEnableAudioDetect;

/// 温度侦测
@property (nonatomic, assign, readonly) BOOL isEnableTemperatureDetect;

/// 湿度侦测
@property (nonatomic, assign, readonly) BOOL isEnableHumidityDetect;

/// PIR 侦测
@property (nonatomic, assign, readonly) BOOL isEnablePIRDetect;

/// 是否支持人体侦测
@property (nonatomic, assign, readonly) BOOL isEnableHumanDetect;

/// 是否支持IO报警
@property (nonatomic, assign, readonly) BOOL isEnableIODetect;

/// 是否支持爱华盈通行人检测
@property (nonatomic, assign, readonly) BOOL isSupportAiWinnDetect;

@end

NS_ASSUME_NONNULL_END
