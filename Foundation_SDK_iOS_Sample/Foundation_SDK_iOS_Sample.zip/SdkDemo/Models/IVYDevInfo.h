//
//  IVYDevInfo.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IVYDevInfo : NSObject

/// 设备类型
@property (nonatomic, assign) NSInteger devType;

/// 平台类型
@property (nonatomic, assign) NSInteger platType;

/// sensor类型
@property (nonatomic, assign) NSInteger sensorType;

/// wifi类型
@property (nonatomic, assign) NSInteger wifiType;

/// 语言
@property (nonatomic, assign) NSInteger language;

/// 产品名字
@property (nonatomic, strong) NSString *productName;

/// 设备名
@property (nonatomic, strong) NSString *devName;

/// 应用固件版本号
@property (nonatomic, strong) NSString *firmwareVersion;

/// 系统固件版本号
@property (nonatomic, strong) NSString *hardwareVersion;

/// 序列号
@property (nonatomic, assign) NSInteger serialNo;

/// 设备UID
@property (nonatomic, strong) NSString *uid;

/// MAC 地址
@property (nonatomic, strong) NSString *mac;

/// OEM 码
@property (nonatomic, assign) NSInteger oemCode;

/// 初始化方法
/// @param dict 字典
- (instancetype)instanceWithDict:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
