//
//  IVYDevAbility.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYDevAbility.h"

static NSInteger const kRESERVE0_BIT0_SD = 0;
static NSInteger const kRESERVE0_BIT1_OUTDOOR = 1;
static NSInteger const kRESERVE0_BIT2_PT = 2;
static NSInteger const kRESERVE0_BIT3_ZOOM = 3;
static NSInteger const kRESERVE0_BIT4_RS485 = 4;
static NSInteger const kRESERVE0_BIT5_IOALARM = 5;
static NSInteger const kRESERVE0_BIT6_ONVIF = 6;
static NSInteger const kRESERVE0_BIT7_P2P = 7;
static NSInteger const kRESERVE0_BIT8_WPS = 8;
static NSInteger const kRESERVE0_BIT9_AUDIO = 9;
static NSInteger const kRESERVE0_BIT10_TALK = 10;
static NSInteger const kRESERVE0_BIT11_DUPLEXVOICE = 11;
static NSInteger const kRESERVE0_BIT12_NAA = 12;
static NSInteger const kRESERVE0_BIT13_STREAMMODE = 13;
static NSInteger const kRESERVE0_BIT14_MOTTONAREA = 14;
static NSInteger const kRESERVE0_BIT15_ONEKEYCALL = 15;
static NSInteger const kRESERVE0_BIT16_IRCUTSCHEDULE = 16;

static NSInteger const kRESERVE2_BIT0_OUTFRAMEWORK = 0;
static NSInteger const kRESERVE2_BIT1_AUDIO = 1;
static NSInteger const kRESERVE2_BIT2_Temperature = 2;
static NSInteger const kRESERVE2_BIT3_Humidity = 3;
static NSInteger const kRESERVE2_BIT4_PIR = 4;
static NSInteger const kRESERVE2_BIT5_HUMANDETECT = 5; //reserve2 第5位 人体侦测功能 (1:支持  0:不支持)
static NSInteger const kRESERVE2_BIT6_AIWINNDETECT = 6; //reserve2 第6位 爱华盈通行人检测 (1:支持  0:不支持)

@implementation IVYDevAbility

- (instancetype)instanceWithDict:(NSDictionary *)dict {
    
    if (dict[@"val0"]) self.val0 = [dict[@"val0"] integerValue];
    if (dict[@"val1"]) self.val1 = [dict[@"val1"] integerValue];
    if (dict[@"val2"]) self.val2 = [dict[@"val2"] integerValue];
    if (dict[@"val3"]) self.val3 = [dict[@"val3"] integerValue];
    if (dict[@"val4"]) self.val4 = [dict[@"val4"] integerValue];
    if (dict[@"val5"]) self.val5 = [dict[@"val5"] integerValue];
    if (dict[@"val6"]) self.val6 = [dict[@"val6"] integerValue];
    if (dict[@"val7"]) self.val7 = [dict[@"val7"] integerValue];
    if (dict[@"val8"]) self.val8 = [dict[@"val8"] integerValue];
    
    return self;
}

@end



@implementation IVYDevAbility (Helper)

- (BOOL)isEnableSD {
    return ((self.val0 >> kRESERVE0_BIT0_SD) & 0x01);
}

- (BOOL)isEnableOutdoor {
    return ((self.val0 >> kRESERVE0_BIT1_OUTDOOR) & 0x01);
}

- (BOOL)isEnablePT {
    return ((self.val0 >> kRESERVE0_BIT2_PT) & 0x01);
}

- (BOOL)isEnableZoom {
    return ((self.val0 >> kRESERVE0_BIT3_ZOOM) & 0x01);
}

- (BOOL)isEnableRS485 {
    return ((self.val0 >> kRESERVE0_BIT4_RS485) & 0x01);
}

- (BOOL)isEnableIOAlarm {
    return ((self.val0 >> kRESERVE0_BIT5_IOALARM) & 0x01);
}

- (BOOL)isEnableOnvif {
    return ((self.val0 >> kRESERVE0_BIT6_ONVIF) & 0x01);
}

- (BOOL)isEnableP2P {
    return ((self.val0 >> kRESERVE0_BIT7_P2P) & 0x01);
}

- (BOOL)isEnableWPS {
    return ((self.val0 >> kRESERVE0_BIT8_WPS) & 0x01);
}

- (BOOL)isEnableAudio {
    return ((self.val0 >> kRESERVE0_BIT9_AUDIO) & 0x01);
}

- (BOOL)isEnableTalk {
    return ((self.val0 >> kRESERVE0_BIT10_TALK) & 0x01);
}

- (BOOL)isSupportDuplexVoice {
    return ((self.val0 >> kRESERVE0_BIT11_DUPLEXVOICE) & 0x01);
}

- (BOOL)isSupportNAA {
    return ((self.val0 >> kRESERVE0_BIT12_NAA) & 0x01);
}

- (BOOL)isStreamSwitch {
    return ((self.val0 >> kRESERVE0_BIT13_STREAMMODE) & 0x01);
}

- (BOOL)isSupportMotionArea {
    return ((self.val0 >> kRESERVE0_BIT14_MOTTONAREA) & 0x01);
}

- (BOOL)isSupportOneKeyCall {
    return ((self.val0 >> kRESERVE0_BIT15_ONEKEYCALL) & 0x01);
}

- (BOOL)isSupportIRCutSchedule {
    return ((self.val0 >> kRESERVE0_BIT16_IRCUTSCHEDULE) & 0x01);
}

- (BOOL)isEnableOutFrameworkDetect {
    return ((self.val2 >> kRESERVE2_BIT0_OUTFRAMEWORK) & 0x01);
}

- (BOOL)isEnableAudioDetect {
    return ((self.val2 >> kRESERVE2_BIT1_AUDIO) & 0x01);
}

- (BOOL)isEnableTemperatureDetect {
    return ((self.val2 >> kRESERVE2_BIT2_Temperature) & 0x01);
}

- (BOOL)isEnableHumidityDetect {
    return ((self.val2 >> kRESERVE2_BIT3_Humidity) & 0x01);
}

- (BOOL)isEnablePIRDetect {
    return ((self.val2 >> kRESERVE2_BIT4_PIR) & 0x01);
}

- (BOOL)isEnableHumanDetect {
    return ((self.val2 >> kRESERVE2_BIT5_HUMANDETECT) & 0x01);
}

- (BOOL)isEnableIODetect {
    return self.isEnableIOAlarm;
}

- (BOOL)isSupportAiWinnDetect {
    return ((self.val2 >> kRESERVE2_BIT6_AIWINNDETECT) & 0x01);
}

@end
