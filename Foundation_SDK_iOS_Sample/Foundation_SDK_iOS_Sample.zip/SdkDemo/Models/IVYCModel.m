//
//  IVYCModel.m
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYCModel.h"

@implementation IVYCModel

- (instancetype)initWithTitle:(NSString *)title tag:(NSInteger)tag {
    if (self = [super init]) {
        _title = title;
        _tag = tag;
    }
    return self;
}

@end
