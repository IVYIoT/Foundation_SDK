//
//  IVYDevLan.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/20.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYDevLan.h"
#include <arpa/inet.h>

@implementation IVYDevLan

- (instancetype)instanceWithIVYIO_DEV_NODE:(IVYIO_DEV_NODE *)node {
    
    struct in_addr inaddr;
    inaddr.s_addr = node->uIP;
    self.ip = [[NSString alloc] initWithUTF8String:inet_ntoa(inaddr)];
    
    self.type = node->uType;
    self.mask = node->uMask;
    self.dns = node->uDns;
    self.port = node->usPort;
    self.dhcp_enabled = node->uDHCPEnable;
    
    self.mac = [NSString stringWithCString:node->szMac encoding:NSASCIIStringEncoding];
    self.uid = [NSString stringWithCString:node->szUid encoding:NSASCIIStringEncoding];
    self.name = [NSString stringWithCString:node->szName encoding:NSASCIIStringEncoding];
    
    return self;
}

@end
