//
//  IVYDevInfo.m
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/24.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import "IVYDevInfo.h"
#import "NSString+IVY.h"

@implementation IVYDevInfo

- (instancetype)instanceWithDict:(NSDictionary *)dict {
    
    if (dict[@"devType"]) self.devType = [dict[@"devType"] integerValue];
    if (dict[@"platType"]) self.platType = [dict[@"platType"] integerValue];
    if (dict[@"sensorType"]) self.sensorType = [dict[@"sensorType"] integerValue];
    if (dict[@"wifiType"]) self.wifiType = [dict[@"wifiType"] integerValue];
    if (dict[@"language"]) self.language = [dict[@"language"] integerValue];
    if (dict[@"productName"]) self.productName = dict[@"productName"];
    if (dict[@"devName"]) self.devName = [dict[@"devName"] base64EncodedToString];
    if (dict[@"firmwareVersion"]) self.firmwareVersion = dict[@"firmwareVersion"];
    if (dict[@"hardwareVersion"]) self.hardwareVersion = dict[@"hardwareVersion"];
    if (dict[@"serialNo"]) self.serialNo = [dict[@"serialNo"] integerValue];
    if (dict[@"uid"]) self.uid = dict[@"uid"];
    if (dict[@"mac"]) self.mac = dict[@"mac"];
    if (dict[@"oemCode"]) self.oemCode = [dict[@"oemCode"] integerValue];
    
    return self;
}


@end
