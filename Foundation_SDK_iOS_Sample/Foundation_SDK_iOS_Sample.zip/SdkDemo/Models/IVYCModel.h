//
//  IVYCModel.h
//  SdkDemo
//
//  Created by JackChan on 26/2/2020.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IVYCModel : NSObject

- (instancetype)initWithTitle:(NSString *)title tag:(NSInteger)tag;

@property (nonatomic, strong) NSString *title;

@property (nonatomic, assign) NSInteger tag;


@end

NS_ASSUME_NONNULL_END
