//
//  Camera.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/19.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"
#import "IVYDevInfo.h"
#import "IVYDevAbility.h"

NS_ASSUME_NONNULL_BEGIN

@interface Camera : NSObject

/// 设备句柄
@property (nonatomic, assign) IVYHANDLE handle;

/// 设备UID
@property (nonatomic, strong) NSString *deviceUID;

/// 设备用户名
@property (nonatomic, strong, readonly) NSString *username;

/// 设备密码
@property (nonatomic, strong, readonly) NSString *password;

/// 初始化方法
/// @param deviceUID 设备UID
/// @param username 设备用户名
/// @param password 设备密码
- (instancetype)initWithDeviceUID:(NSString *)deviceUID username:(NSString *)username password:(NSString *)password;

/// 设备类型
@property (nonatomic, assign) IVYDeviceType deviceType;

/// 设备信息
@property (nonatomic, strong) IVYDevInfo *devInfo;

/// 设备能力级
@property (nonatomic, strong) IVYDevAbility *devAbility;

@end



@interface Camera (Category)

/// 设备句柄状态
@property (nonatomic, assign, readonly) IVYIO_HANDLE_STATE handleState;

/// 登陆设备
/// @param resultBlock 结果
- (void)loginCamera:(void(^)(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult))resultBlock;

@end

NS_ASSUME_NONNULL_END
