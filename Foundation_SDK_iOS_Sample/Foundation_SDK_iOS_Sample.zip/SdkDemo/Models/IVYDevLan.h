//
//  IVYDevLan.h
//  SdkDemo
//
//  Created by Jack Chan on 2020/2/20.
//  Copyright © 2020 ivyiot.io. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IVYConstant.h"

NS_ASSUME_NONNULL_BEGIN

@interface IVYDevLan : NSObject

@property (nonatomic, strong) NSString *mac;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *ip;

@property (nonatomic, assign) NSInteger mask;

@property (nonatomic, assign) NSInteger dns;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, assign) NSInteger port;

@property (nonatomic, assign) NSInteger dhcp_enabled;

@property (nonatomic, strong) NSString *uid;

- (instancetype)instanceWithIVYIO_DEV_NODE:(IVYIO_DEV_NODE *)node;

@end

NS_ASSUME_NONNULL_END
